Current Runtime / original archived frame119 scene: finite color comparison.

Offline replay: Python 3.10+, numpy, pillow. No Unity/GPU/hash validation.
  python replay.py fresh-output
fresh-output must not exist. This relocates the existing comparison and MAE
functions; it does not generate a reference or assign production certification.

raw/: actual one119 capture and terminal receipts/current Feature configuration.
reference-119/: unchanged existing 256spp/8bounce finite CPU reference.
baseline-119/: original receipt and material support used by the old comparator.
inputs/: original copied Generated assets, not a standalone Unity project.
code/: unchanged prior comparison and MAE functions.
source/: this observation's adapter, runner, frozen contract and original MAE entry.

All numbers concern filteredD=E_indirect/pi, original Floor/White source ROIs,
640x360 camera / 320x180 GI, single frame119. Unknown is not black. The mean
per-pixel SE is neither an error bound nor an ROI confidence interval. Sampling,
8-level truncation, visibility and other model differences remain.
The ordinary Final output is not compared with the old IndirectOnly output.
120 source receipts succeeded; the original 720-frame sequence remains an
intentional failed prefix. No current three-room/960x540/Player/full-G1 claim.
