using System;
using System.Collections;
using System.IO;
using System.Reflection;
using HybridLumenGI;
using UnityEngine;
using UnityEngine.Rendering;

[DefaultExecutionOrder(1000)]
public sealed class ArchivedColor133Host : MonoBehaviour
{
    public HybridLumenGIValidationSequence sequence;
    public Camera targetCamera;
    public HybridLumenGIRendererFeature feature;
    public RenderPipelineAsset expectedPipeline;
    public string outputDirectory, settingsJson;
    const BindingFlags Private = BindingFlags.Instance | BindingFlags.NonPublic;
    static readonly FieldInfo Logical = typeof(HybridLumenGIValidationSequence).GetField("logicalFrame", Private);
    static readonly FieldInfo Pending = typeof(HybridLumenGIValidationSequence).GetField("pending", Private);
    static readonly FieldInfo Output = typeof(HybridLumenGIValidationSequence).GetField("output", Private);
    static readonly FieldInfo Settings = typeof(HybridLumenGIRendererFeature).GetField("settings", Private);
    [Serializable] public sealed class LegacyRun
    {
        public string status, lastError, expectedBackend, renderPath;
        public int renderedFrames, failures, backendMismatches, firstEngineFrame, firstRenderedGiFrame, capturesWritten;
    }
    [Serializable] sealed class Frame
    {
        public int logicalFrame, engineFrame, giFrame;
        public bool diagnosticFresh;
        public string reportedBackend;
    }
    [Serializable] public sealed class Result
    {
        public string status = "failed", error = "", captureDirectory, framesFile, runFile, actualFeatureJson, captureReceipt;
        public string legacyMeaning = "Intentional 0..119 prefix; original 720 gate remains failed, not completed";
        public string sourceArchive = "ValidationPackageV209/project-archive/Assets/ValidationPackageV201/Generated; original Sequence.ApplyFrame 0..119, five original lights and original stationary door; no source export/rebake";
        public int renderedFrames, receiptCount, requestedLogicalFrame = -1, requestedEngineFrame = -1, sourceWorkFrame = -1;
        public bool referenceDrained, legacyReadbacksDrained, captureSucceeded;
        public double elapsedSeconds;
        public LegacyRun legacy;
    }
    HybridLumenGIValidationCapture.Session capture;
    HybridLumenGIValidationCapture.Ticket ticket;
    object readyPipeline;
    int stableUpdates;
    bool began, stopRequested, stopping, finished, checkpoint;
    double started;
    readonly Result result = new Result();
    void Need(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
    void Error(Exception e) { result.error += (result.error.Length == 0 ? "" : "\n") + e; stopRequested = true; }
    void Start()
    {
        started = Time.realtimeSinceStartupAsDouble; Application.runInBackground = true;
        try {
            Need(sequence != null && targetCamera != null && feature != null && expectedPipeline != null, "Archived references missing.");
            Need(Path.IsPathRooted(outputDirectory) && Directory.Exists(outputDirectory), "Editor output directory missing.");
            Need(!targetCamera.enabled && sequence.enabled && sequence.CaptureStatus == "not-started", "Capture must start cold with disabled automatic camera.");
            Need(Logical != null && Pending != null && Output != null && Settings != null, "Existing private sequence API unavailable.");
            Need(GraphicsSettings.currentRenderPipeline == expectedPipeline, "Active pipeline is not the archived pipeline.");
            var settings = JsonUtility.FromJson<HybridLumenGIRendererFeature.Settings>(settingsJson);
            Need(settings != null && settings.raysPerPixel == 2 && settings.filterIterations == 4 && settings.preferHardwareTracing,
                "Expected only the requested quality/backend overrides.");
            Settings.SetValue(feature, settings);
            result.actualFeatureJson = JsonUtility.ToJson(feature, true);
            File.WriteAllText(Path.Combine(outputDirectory, "actual-feature.json"), result.actualFeatureJson);
            RenderPipelineManager.beginCameraRendering += BeforeCamera;
        } catch (Exception e) { Error(e); }
    }
    void BeforeCamera(ScriptableRenderContext context, Camera camera)
    {
        if (!ReferenceEquals(camera, targetCamera) || !began || stopping || finished) return;
        try {
            int logical = (int)Logical.GetValue(sequence);
            if (logical != 119) return;
            Need(ticket == null, "Logical119 rendered more than once.");
            result.requestedLogicalFrame = logical; result.requestedEngineFrame = Time.frameCount;
            ticket = capture.Request(logical, Time.frameCount);
            result.captureReceipt = ticket.ReceiptPath;
        } catch (Exception e) { Error(e); }
    }
    void Update()
    {
        if (finished) return;
        try {
            if (stopping) { Drain(); return; }
            if (stopRequested) return;
            if (!began) {
                if (Time.realtimeSinceStartupAsDouble - started > 300) throw new TimeoutException("Archived pipeline did not become ready; no GI warmup was submitted.");
                // SupportsRenderRequest creates the pipeline if needed, without submitting a render.
                if (!RenderPipeline.SupportsRenderRequest(targetCamera, new RenderPipeline.StandardRequest())) return;
                object current = RenderPipelineManager.currentPipeline;
                if (current == null || !ReferenceEquals(current, readyPipeline)) { readyPipeline = current; stableUpdates = 0; return; }
                if (++stableUpdates < 2) return;
                Need(GraphicsSettings.currentRenderPipeline == expectedPipeline, "Archived pipeline changed before Begin.");
                capture = HybridLumenGIValidationCapture.Begin(targetCamera, feature, Path.Combine(outputDirectory, "signals"), 1);
                began = true; sequence.BeginCapture();
            }
            if (sequence.RenderedFrames >= 120) stopRequested = true;
            else if (sequence.CaptureStatus != "running") throw new InvalidOperationException("Sequence stopped before 120 receipts: " + sequence.CaptureStatus);
        } catch (Exception e) { Error(e); }
    }
    void LateUpdate()
    {
        if (finished || stopping || !stopRequested) return;
        // Sequence.Update(-500) and its synchronous StandardRequest have returned.
        // OnDisable uses the unmodified Finish(false), including its existing ordinary-HDR shutdown.
        stopping = true;
        try { if (sequence != null) sequence.enabled = false; }
        catch (Exception e) { Error(e); }
        finally {
            if (targetCamera != null) targetCamera.enabled = false;
            RenderPipelineManager.beginCameraRendering -= BeforeCamera;
            capture?.Seal();
        }
        Drain();
    }
    bool LegacyDrained()
    {
        if (sequence == null || Pending == null || Output == null) return !began;
        return ((IList)Pending.GetValue(sequence)).Count == 0 && Output.GetValue(sequence) == null && sequence.ReferenceCaptureDrained;
    }
    void Drain()
    {
        if (finished) return;
        result.referenceDrained = capture == null || capture.IsDrained;
        result.legacyReadbacksDrained = LegacyDrained();
        if (!result.referenceDrained || !result.legacyReadbacksDrained) {
            if (!checkpoint && Time.realtimeSinceStartupAsDouble - started > 300) {
                checkpoint = true; result.error += "\nReadbacks have not terminated; capture/resources remain owned, polling continues.";
                File.WriteAllText(Path.Combine(outputDirectory, "retained-checkpoint.json"), JsonUtility.ToJson(result, true));
            }
            return;
        }
        Finish();
    }
    void Finish()
    {
        if (finished) return; finished = true;
        try {
            result.renderedFrames = sequence != null ? sequence.RenderedFrames : 0;
            result.captureDirectory = sequence != null ? sequence.OutputDirectory : null;
            if (!string.IsNullOrEmpty(result.captureDirectory)) {
                result.runFile = Path.Combine(result.captureDirectory, "run.json");
                result.framesFile = Path.Combine(result.captureDirectory, "frames.jsonl");
                result.legacy = JsonUtility.FromJson<LegacyRun>(File.ReadAllText(result.runFile));
                var lines = File.ReadAllLines(result.framesFile); result.receiptCount = lines.Length;
                int previousEngine = -1, previousGi = -1;
                for (int i = 0; i < lines.Length; i++) {
                    var frame = JsonUtility.FromJson<Frame>(lines[i]);
                    Need(frame.logicalFrame == i && frame.diagnosticFresh && frame.reportedBackend == "reported-hardware", "Unexpected source receipt/backend at " + i);
                    Need(i == 0 || (frame.engineFrame == previousEngine + 1 && frame.giFrame == previousGi + 1), "Source receipt continuity differs.");
                    if (i == 119) Need(frame.engineFrame == result.requestedEngineFrame, "Capture request is not the logical119 source.");
                    previousEngine = frame.engineFrame; previousGi = frame.giFrame;
                }
            }
            result.captureSucceeded = ticket != null && ticket.Succeeded;
            result.sourceWorkFrame = ticket != null ? ticket.Result.workFrame : -1;
            Need(result.renderedFrames == 120 && result.receiptCount == 120, "The original prefix did not render exactly 120 receipts.");
            Need(result.legacy != null && result.legacy.status == "failed" && result.legacy.failures == 0 && result.legacy.backendMismatches == 0,
                "Legacy status must remain intentional failed-prefix with no recorded failure/backend mismatch.");
            Need(result.captureSucceeded && result.requestedLogicalFrame == 119 && result.sourceWorkFrame == 119,
                "Logical119 capture incomplete or wrong work frame: " + ticket?.Failure);
            if (result.error.Length == 0) result.status = "collected";
        } catch (Exception e) { Error(e); }
        finally {
            result.elapsedSeconds = Time.realtimeSinceStartupAsDouble - started;
            capture?.Dispose();
            try { File.WriteAllText(Path.Combine(outputDirectory, "host-result.json"), JsonUtility.ToJson(result, true)); }
            finally {
#if UNITY_EDITOR
                UnityEditor.EditorApplication.isPlaying = false;
#endif
            }
        }
    }
    void OnDestroy() { RenderPipelineManager.beginCameraRendering -= BeforeCamera; }
}
