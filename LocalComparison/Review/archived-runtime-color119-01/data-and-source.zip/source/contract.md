# 当前Runtime／原归档119场景的有限颜色判断

## 必要性与边界

原G1要求颜色／能量符合匹配参考。93已有两个原ROI的限定结果，当前122没有该量的等价结果。本项判断当前产品在**原两个接收域、同一物理量**下是否满足已定颜色目标，而不是仅因93版本旧就重测。Astra同意直接复用完整归档物理场景，无需新增全源证明体系；不把弱比较器写成全部来源自动核验通过。

只用V209归档Generated场景／材质／网格／SDF／charts／相机／灯光及原序列0–119前史。源目录：`I:/Unity test/Comparison/ValidationPackageV209/project-archive/Assets/ValidationPackageV201/Generated`。原图参考：`I:/Unity test/Comparison/ValidationPackageV209-reference-frame0119-01`（256spp／8反弹有限CPU参考），原source及owner网格：`I:/Unity test/Comparison/ValidationPackageV209/capture/20261029-153518-90ad50e68d454b52b48135246a18dfa5`。实际当前Runtime为公开122同源产品，I工程已有安装；本轮不部署产品修改。

仅将原feature质量设为已接受2ray／filter4／DXR偏好；保留其余原序列配置（半GI、cache8、反馈1、黑环境、Additive／Final）。相机640×360／GI320×180、无后处理、无TAA／MSAA。归档为20对象／5实时灯、黑环境、无lightmap、119时门处原静止位置。全体物理输入由原归档资产直接复用，不重新生成或修改材质、灯、几何、事件。旧Host可禁用，以新小适配器控制现有Sequence／Capture；临时观察scene是原归档场景副本。

## 唯一运行

一次Editor Play，原Sequence按一逻辑帧一次显式RenderRequest运行0–119；管线稳定等待不提交任何预热渲染。只对logical119请求一次现有ValidationCapture（包含其固有support），不增加GPU探针或compute，不生成独立参考／source证明包，不跑720全序列。产品原720完成门槛保留未完成状态；120前缀不能冒充完整序列通过。

第119实际渲染返回后正常结束Sequence前缀，所有实际读回终止才恢复及退出。超时只能保留检查点、所有权并继续等待，不以观察超时为终止，不另开进程。无需额外hash／扫描／构建／Player／性能测量。

若原资产导入GUID不匹配、需要重烘／补资源／换源／改事件或修旧夹具才能运行，则按输入不足结束，不延长适用性证明链。新的适配器本身若有明确准备错误，保留原失败，是否更正先由Astra判断；不自动多次重试。

## 采用条件

直接复用现成compare.py和像素MAE helper及原源几何Floor／White ROI；filteredD=E_indirect/pi，未乘接收面rho／AO／合成强度。只比较119同量，不用Final出射冒充D。原比较器有限匹配包含invVP、GI尺寸、合成强度、ROI RGB／AO，不能宣称核对全部灯／几何／前史。

使用已有QualityAcceptance目标：区域均值亮度相对偏差绝对值≤10%、归一化平均RGB色向L1≤0.05、像素Y-MAE／参考区域平均Y≤20%，并看同曝光图有无明显结构／串色。unknown单列不填黑；固定源域不按产品有效性或颜色择点。不改目标或ROI。

参考保留有限采样、8层截断、射线偏移、产品距离截断／缓存／滤波与硬可见性vsPCF等不确定性；参考SE不是误差上界或ROI均值置信区间。通过只关闭**当前Runtime、归档119场景、原两个ROI**的有限依据，不等于当前三室、960×540、普通Player或完整G1。超差先核对量和来源，不自动调参、补采、扩大参考或严格证明。无论结果，Astra复核后结束该项，不发新公开版本。
