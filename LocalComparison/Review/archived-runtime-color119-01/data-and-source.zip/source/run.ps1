$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
$project=[IO.Path]::GetFullPath('I:/Unity test/Project')
$comparison=[IO.Path]::GetFullPath('I:/Unity test/Comparison')
$archive=[IO.Path]::GetFullPath("$comparison/ValidationPackageV209/project-archive/Assets/ValidationPackageV201")
$original=[IO.Path]::GetFullPath("$project/Assets/ValidationPackageV201")
$observer=[IO.Path]::GetFullPath("$project/Assets/HLGIArchivedColor133")
$output=[IO.Path]::GetFullPath("$comparison/ArchivedColor133")
$setup=[IO.Path]::GetFullPath($output+'Setup')
$quality="$project/ProjectSettings/QualitySettings.asset"
$lastScene="$project/Library/LastSceneManagerSetup.txt"
function Idle {
    if(Get-Process Unity,HybridLumenGIPlayer -ErrorAction SilentlyContinue){throw 'A live Unity/Player still owns the project; wait, do not restart.'}
}
Idle
foreach($p in @($original,"$original.meta",$observer,"$observer.meta",$output,$setup,
    'I:/Unity test/Logs/ArchivedColor133.log','I:/Unity test/Logs/ArchivedColor133-upm.log')){
    if(Test-Path -LiteralPath $p){throw "Preserve existing input/output: $p"}
}
# These three direct API entry points identify the installed current implementation.
foreach($relative in @('Runtime/HybridLumenGIRendererFeature.cs','Runtime/HybridLumenGIValidationSequence.cs','Runtime/HybridLumenGIValidationCapture.cs')){
    $wanted=[IO.File]::ReadAllText("$repo/$relative").Replace([string][char]13,'')
    $installed=[IO.File]::ReadAllText("$project/Assets/HybridLumenGI/$relative").Replace([string][char]13,'')
    if($wanted -cne $installed){throw "Installed implementation differs: $relative"}
}
foreach($name in @('ArchivedColor133Editor.cs','ArchivedColor133Host.cs','contract.md')){
    if(!(Test-Path -LiteralPath "$PSScriptRoot/$name" -PathType Leaf)){throw "Observer not ready: $name"}
}
$hadScene=Test-Path -LiteralPath $lastScene -PathType Leaf
New-Item -ItemType Directory -Path $setup | Out-Null
Copy-Item -LiteralPath $quality -Destination $setup
if($hadScene){Copy-Item -LiteralPath $lastScene -Destination $setup}
$originalCreated=$false;$observerCreated=$false
try{
    Idle
    New-Item -ItemType Directory -Path $original | Out-Null;$originalCreated=$true
    # Copy immutable original inputs and their GUIDs; never run the old editor generator.
    Copy-Item -LiteralPath "$archive/Generated","$archive/Generated.meta","$archive/ValidationPackageV2Host.cs","$archive/ValidationPackageV2Host.cs.meta" -Destination $original -Recurse
    # A plain import-identity guard, not a geometry/reference proof or hash sweep.
    $map=@(Get-ChildItem -LiteralPath "$archive/Generated" -Filter '*.meta' -Recurse -File | ForEach-Object {
        $matched=[regex]::Match([IO.File]::ReadAllText($_.FullName),'(?m)^guid: ([0-9a-f]{32})\s*$')
        if(!$matched.Success){throw "Missing serialized asset GUID: $($_.FullName)"}
        $relative=$_.FullName.Substring($archive.Length+1).Replace('\','/')
        @{guid=$matched.Groups[1].Value;path='Assets/ValidationPackageV201/'+$relative.Substring(0,$relative.Length-5)}
    })
    @{assets=$map} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath "$original/import-map.json" -Encoding utf8
    New-Item -ItemType Directory -Path "$observer/Editor" -Force | Out-Null;$observerCreated=$true
    Copy-Item -LiteralPath "$PSScriptRoot/ArchivedColor133Editor.cs" -Destination "$observer/Editor"
    Copy-Item -LiteralPath "$PSScriptRoot/ArchivedColor133Host.cs" -Destination $observer
    Copy-Item -LiteralPath "$PSScriptRoot/contract.md" -Destination $setup
    & 'I:/Unity test/Start-Unity.ps1' -Batch -KeepRunning -ProjectPath $project -LogName ArchivedColor133 `
        -ExecuteMethod ArchivedColor133Editor.Run -ExtraArguments @('-archivedColorOutput',$output)
    $code=$LASTEXITCODE
    @{exitCode=$code;output=$output;archive=$archive;phase='one-archived-static-prefix'} | ConvertTo-Json |
        Set-Content -LiteralPath "$setup/native-exit.json" -Encoding utf8
    if($code -ne 0){throw "Observation exited $code; preserve first failure, no automatic retry."}
    Get-Content -LiteralPath "$output/result.json"
}finally{
    Idle
    Copy-Item -LiteralPath "$setup/QualitySettings.asset" -Destination $quality -Force
    if($hadScene){Copy-Item -LiteralPath "$setup/LastSceneManagerSetup.txt" -Destination $lastScene -Force}
    elseif(Test-Path -LiteralPath $lastScene){Move-Item -LiteralPath $lastScene -Destination "$setup/generated-scene-setup.txt"}
    foreach($item in @(@{path=$original;created=$originalCreated;name='used-original'},@{path=$observer;created=$observerCreated;name='used-observer'})){
        if(!$item.created){continue}
        $source=Get-Item -LiteralPath $item.path
        $destination=[IO.Path]::GetFullPath((Join-Path $setup $item.name))
        if($source.FullName -ine [IO.Path]::GetFullPath($item.path) -or
            [IO.Path]::GetDirectoryName($source.FullName) -ine [IO.Path]::GetFullPath("$project/Assets") -or
            [IO.Path]::GetDirectoryName($destination) -ine $setup -or
            $source.Attributes.HasFlag([IO.FileAttributes]::ReparsePoint) -or
            (Get-ChildItem -LiteralPath $source.FullName -Recurse -Force -Attributes ReparsePoint | Select-Object -First 1) -or
            (Test-Path -LiteralPath $destination) -or (Test-Path -LiteralPath "$destination.meta")){
            throw 'Unexpected owned/archive path; preserve staged resources.'
        }
        Move-Item -LiteralPath $source.FullName -Destination $destination
        if(Test-Path -LiteralPath "$($item.path).meta"){Move-Item -LiteralPath "$($item.path).meta" -Destination "$destination.meta"}
    }
}
