$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
$python='C:/Users/Administrator/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
$raw='I:/Unity test/Comparison/ArchivedColor133'
$r=Get-Content -LiteralPath "$raw/result.json" -Raw | ConvertFrom-Json
if($r.status -ne 'collected' -or !$r.restored){throw 'Only a terminal, restored observation may be interpreted.'}
$destination="$repo/LocalComparison/Review/archived-runtime-color119-01"
& $python "$repo/LocalComparison/Review/current-color-frame119-01/compare.py" --signals "$raw/signals" --output $destination
if($LASTEXITCODE -ne 0){throw 'Existing comparator stopped; retain its first result.'}
& $python "$destination/pixel-mae.py"
if($LASTEXITCODE -ne 0){throw 'Existing MAE helper stopped; retain source and outputs.'}
