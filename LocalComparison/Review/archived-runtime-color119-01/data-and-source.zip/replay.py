"""Relocate the existing comparison/MAE functions; no GPU or new integration."""
import importlib.util
import json
from pathlib import Path
import sys

base=Path(__file__).resolve().parent
out=Path(sys.argv[1]).resolve() if len(sys.argv)==2 else base/'replayed'
if out.exists(): raise SystemExit('Preserve existing output; choose a fresh directory.')
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
compare=module('existing_color',base/'code/current-color-frame119-01/compare.py')
compare.OLD=base/'baseline-119';compare.REFERENCE=base/'reference-119'
sys.argv=['compare.py','--signals',str(base/'raw/signals'),'--output',str(out)]
compare.main()
helper=module('existing_mae',base/'code/stationary-history-01/analyze.py')
helper.REFS={119:base/'reference-119'}
comparison=helper.load(out/'comparison.json')
receipt=helper.load(base/'raw/signals/frame-0119-capture.json')
sample=helper.unique(receipt['samples'],'signalId','filteredD')
data=helper.read_measurements((base/'raw/signals',receipt,sample))
reference=helper.reference_inputs(119);helper.read_reference(reference)
rows={}
for name,region in reference['rois'].items():
    selected=region & data['valid']
    helper.require(int(selected.sum())==comparison['roi'][name]['pairedPixels'],'Comparison domain differs')
    rows[name]={'pairedPixels':int(selected.sum()),'pixelYMAE':helper.measures(data,reference,selected)['pixelYMAE']}
(out/'pixel-mae.json').write_text(json.dumps({'logicalFrame':119,'quantity':comparison['quantity'],'roi':rows,'qualityVerdict':None},indent=2)+'\n',encoding='utf-8')
print(out/'pixel-mae.json')
