$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$project=[IO.Path]::GetFullPath('I:/Unity test/Project')
$comparison=[IO.Path]::GetFullPath('I:/Unity test/Comparison')
$release='I:/Unity test/Comparison/PortableUnified122/HybridLumenGI-Release122-UnityProject'
$releasedAssets="$release/Assets/UnifiedRelease74/Generated"
$workspace=[IO.Path]::GetFullPath("$PSScriptRoot/../..")
$name='AlphaSmoothness131'
$owned=[IO.Path]::GetFullPath("$project/Assets/HLGIAlphaSmoothness131")
$output=[IO.Path]::GetFullPath("$comparison/$name")
$record=[IO.Path]::GetFullPath("$comparison/${name}Setup")
$build=[IO.Path]::GetFullPath("$comparison/Builds/$name")
$executable="$build/HybridLumenGIPlayer.exe"
$quality="$project/ProjectSettings/QualitySettings.asset"
$lastScene="$project/Library/LastSceneManagerSetup.txt"
$buildLog="${name}Build"
function Idle {
    if(Get-Process Unity,HybridLumenGIPlayer -ErrorAction SilentlyContinue){throw 'A Unity or Player process is active. Preserve staged files.'}
}
Idle
foreach($p in @($owned,"$owned.meta",$output,$record,$build,"I:/Unity test/Logs/$buildLog.log","I:/Unity test/Logs/$buildLog-upm.log")){
    if(Test-Path -LiteralPath $p){throw "Preserve existing input/output: $p"}
}
foreach($p in @("$releasedAssets/Pipeline.asset","$releasedAssets/Renderer.asset",$quality,
    "$PSScriptRoot/AlphaSmoothness131Host.cs","$PSScriptRoot/AlphaSmoothness131Editor.cs","$PSScriptRoot/contract.md","$PSScriptRoot/analyze.py")){
    if(!(Test-Path -LiteralPath $p -PathType Leaf)){throw "Missing required input: $p"}
}
foreach($file in @('Runtime/HybridLumenGIRendererFeature.cs','Runtime/HybridLumenGIValidationCapture.cs','Runtime/Resources/HybridLumenGI/HybridLumenGISurface.shader')){
    $actual=[IO.File]::ReadAllText("$project/Assets/HybridLumenGI/$file").Replace([string][char]13,'')
    $expected=[IO.File]::ReadAllText("$workspace/$file").Replace([string][char]13,'')
    if($actual -cne $expected){throw "Installed product source differs from the workspace: $file"}
}
$hadSetup=Test-Path -LiteralPath $lastScene -PathType Leaf
New-Item -ItemType Directory -Path $record | Out-Null
Copy-Item -LiteralPath $quality -Destination $record
if($hadSetup){Copy-Item -LiteralPath $lastScene -Destination $record}
Copy-Item -LiteralPath "$PSScriptRoot/contract.md","$PSScriptRoot/analyze.py" -Destination $record
$created=$false
$player=$null
try{
    New-Item -ItemType Directory -Path $owned | Out-Null
    $created=$true
    New-Item -ItemType Directory -Path "$owned/Editor" | Out-Null
    Copy-Item -LiteralPath "$PSScriptRoot/AlphaSmoothness131Host.cs" -Destination $owned
    Copy-Item -LiteralPath "$PSScriptRoot/AlphaSmoothness131Editor.cs" -Destination "$owned/Editor"
    # Fresh GUIDs for private input copies; do not duplicate the original assets' .meta files.
    Copy-Item -LiteralPath "$releasedAssets/Pipeline.asset" -Destination "$owned/Release122Pipeline.asset"
    Copy-Item -LiteralPath "$releasedAssets/Renderer.asset" -Destination "$owned/Release122Renderer.asset"
    & 'I:/Unity test/Start-Unity.ps1' -Batch -ProjectPath $project -LogName $buildLog -ExecuteMethod AlphaSmoothness131Editor.Build `
        -ExtraArguments @('-buildTarget','StandaloneWindows64','-alphaSmoothnessBuild',$executable,'-alphaSmoothnessBuildReceipt',"$record/build-result.json")
    $buildExit=$LASTEXITCODE
    @{exitCode=$buildExit;project=$project;output=$build;settingsProject=$release} | ConvertTo-Json | Set-Content -LiteralPath "$record/build-exit.json" -Encoding utf8
    if($buildExit -ne 0){throw "Unity build exited $buildExit; preserve its first failure."}
    $report=Get-Content -Raw -LiteralPath "$record/build-result.json" | ConvertFrom-Json
    if($report.status -ne 'Succeeded' -or !$report.restored -or $report.errors -ne 0 -or $report.actualOptions -ne 'None'){
        throw 'Ordinary build did not succeed and restore.'
    }
    Idle
    if(Test-Path -LiteralPath $output){throw 'Player output unexpectedly already exists.'}
    # The Host creates the fresh output directory; keep its log in the existing setup directory.
    $psi=New-Object Diagnostics.ProcessStartInfo
    $psi.FileName=$executable;$psi.WorkingDirectory=$build;$psi.UseShellExecute=$false
    $psi.WindowStyle=[Diagnostics.ProcessWindowStyle]::Hidden;$psi.CreateNoWindow=$true
    $arguments=@('-batchmode','-force-d3d12','-screen-fullscreen','0','-screen-width','960','-screen-height','540',
        '-logFile',"$record/player.log",'-alphaSmoothnessOutput',$output)
    $psi.Arguments=($arguments|ForEach-Object {'"'+$_+'"'}) -join ' '
    $player=[Diagnostics.Process]::Start($psi)
    @{pid=$player.Id;executable=$executable;output=$output;arguments=$arguments} | ConvertTo-Json | Set-Content -LiteralPath "$record/player-start.json" -Encoding utf8
    $player.WaitForExit();$playerExit=$player.ExitCode
    @{exitCode=$playerExit;pid=$player.Id;executable=$executable;output=$output} | ConvertTo-Json | Set-Content -LiteralPath "$record/player-exit.json" -Encoding utf8
    if($playerExit -ne 0){throw "Player exited $playerExit; preserve its first failure."}
    $observed=Get-Content -Raw -LiteralPath "$output/scene-result.json" | ConvertFrom-Json
    if($observed.status -ne 'collected'){throw 'The single Player observation did not complete.'}
}finally{
    # A live process still owns the installed helper and resources: do not restore underneath it.
    if($null -ne $player -and !$player.HasExited){throw "Owned Player $($player.Id) is still active; all staged files retained."}
    Idle
    Copy-Item -LiteralPath "$record/QualitySettings.asset" -Destination $quality -Force
    if($hadSetup){Copy-Item -LiteralPath "$record/LastSceneManagerSetup.txt" -Destination $lastScene -Force}
    elseif(Test-Path -LiteralPath $lastScene){Move-Item -LiteralPath $lastScene -Destination "$record/generated-scene-setup.txt"}
    if($created){
        $source=Get-Item -LiteralPath $owned
        $destination=[IO.Path]::GetFullPath("$record/used-fixture")
        if($source.FullName -ine [IO.Path]::GetFullPath("$project/Assets/HLGIAlphaSmoothness131") -or
            [IO.Path]::GetDirectoryName($record) -ine $comparison -or [IO.Path]::GetDirectoryName($destination) -ine $record -or
            $source.Attributes.HasFlag([IO.FileAttributes]::ReparsePoint) -or
            (Get-ChildItem -LiteralPath $owned -Force -Recurse -Attributes ReparsePoint | Select-Object -First 1)){throw 'Unsafe helper archive path; preserve staged files.'}
        Move-Item -LiteralPath $source.FullName -Destination $destination
        if(Test-Path -LiteralPath "$owned.meta"){Move-Item -LiteralPath "$owned.meta" -Destination "$destination.meta"}
    }
}
