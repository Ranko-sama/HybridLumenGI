using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using HybridLumenGI;
using UnityEngine;
using UnityEngine.Rendering;

public sealed class AlphaSmoothness131Host : MonoBehaviour
{
    public Camera targetCamera;public RenderPipelineAsset expectedPipeline;
    public HybridLumenGIRendererFeature feature;public MeshRenderer[] surfaces;
    [Serializable] public sealed class TextureInput {
        public string format,filter,wrapU,wrapV;public int width,height,mips;public bool srgb;public Color32[] pixels;
    }
    [Serializable] public sealed class SurfaceInput {
        public string name,shader;public string[] keywords;public Vector3[] vertices,normals;public Vector2[] uv;public int[] indices;
        public Matrix4x4 matrix;public Color baseColor,specColor;public float metallic,workflow,cull,alphaClip,alphaToMask,smoothnessChannel,cutoff;
        public bool blockEmpty,blockHasSpecular;public Vector4 blockSpecular;public TextureInput map;
    }
    [Serializable] public sealed class Result {
        public string status="failed",error,device,api,unity,settings,receipt,finalFile="final.rgba32f";
        public string quantity="Same-source native URP depth versus ordinary GI capture depth; DiffuseReflectance output for source-layer identity only";
        public int width=960,height=540,requests,engine=-1,work=-1;public bool captureDrained,finalCompleted;
        public double sourceSeconds,finalCompletionSeconds;public SurfaceInput[] sources;
        public HybridLumenGIValidationSourceState.CameraDescriptor camera;
        public HybridLumenGIRendererFeature.CameraDiagnostics diagnostics;
        public List<string> runtimeErrors=new List<string>();
    }
    readonly Result result=new Result();
    readonly List<Material> runtimeMaterials=new List<Material>();
    RenderTexture target;RenderPipeline.StandardRequest request;HybridLumenGIValidationCapture.Session capture;
    HybridLumenGIValidationCapture.Ticket ticket;string output;double started;int stable,pending;
    object pipeline;bool stopping,finished,checkpoint;byte[] pixels;
    static void Need(bool value,string message){if(!value)throw new InvalidOperationException(message);}
    void Log(string message,string stack,LogType type){if(type==LogType.Error||type==LogType.Exception||type==LogType.Assert)result.runtimeErrors.Add(message);}
    void Start(){
        started=Time.realtimeSinceStartupAsDouble;Application.runInBackground=true;Application.logMessageReceived+=Log;
        try{
            var args=Environment.GetCommandLineArgs();int at=Array.IndexOf(args,"-alphaSmoothnessOutput");
            Need(at>=0&&at+1<args.Length&&Path.IsPathRooted(args[at+1]),"Explicit absolute output required.");
            var candidate=Path.GetFullPath(args[at+1]);Need(!Directory.Exists(candidate)&&!File.Exists(candidate),"Preserve existing output.");Directory.CreateDirectory(candidate);output=candidate;
            Need(surfaces.Length==3&&feature&&expectedPipeline&&targetCamera,"Missing private inputs.");
            Need(SystemInfo.graphicsDeviceType==GraphicsDeviceType.Direct3D12&&SystemInfo.supportsAsyncGPUReadback,"Actual D3D12/readback required.");
            QualitySettings.renderPipeline=expectedPipeline;
            // Match the existing single-sample contract after URP author import.
            foreach(var surface in surfaces.Take(2)){
                var material=new Material(surface.sharedMaterial);material.SetFloat("_AlphaToMask",0);
                runtimeMaterials.Add(material);surface.sharedMaterial=material;
            }
            Need(HybridLumenGIProxy.ActiveProxies.Count==0&&!FindObjectsByType<Light>(FindObjectsSortMode.None).Any(l=>l.isActiveAndEnabled),"Unexpected world or light source.");
            Need(RenderSettings.skybox==null&&RenderSettings.ambientIntensity==0&&RenderSettings.reflectionIntensity==0&&LightmapSettings.lightmaps.Length==0,"Native ambient/baked input is not zero.");
            result.device=SystemInfo.graphicsDeviceName;result.api=SystemInfo.graphicsDeviceType.ToString();result.unity=Application.unityVersion;
            var settings=(HybridLumenGIRendererFeature.Settings)typeof(HybridLumenGIRendererFeature).GetField("settings",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(feature);
            result.settings=JsonUtility.ToJson(settings);
            Need(settings.environmentRadiance==Color.black&&settings.environmentCubemap==null&&settings.indirectIntensity==1&&settings.debugView==HybridLumenGIRendererFeature.DebugView.DiffuseReflectance,"Environment or output differs.");
            result.sources=surfaces.Select(Describe).ToArray();
            target=new RenderTexture(960,540,24,RenderTextureFormat.ARGBFloat,RenderTextureReadWrite.Linear){antiAliasing=1};Need(target.Create(),"Target allocation failed.");
            Need(!targetCamera.enabled,"Explicit camera must remain disabled.");targetCamera.targetTexture=target;targetCamera.aspect=960f/540;
            request=new RenderPipeline.StandardRequest{destination=target};
            capture=HybridLumenGIValidationCapture.Begin(targetCamera,feature,Path.Combine(output,"capture"),1,384L*1024*1024);
        }catch(Exception ex){Fail(ex);}
    }
    static SurfaceInput Describe(MeshRenderer renderer){
        var m=renderer.sharedMaterial;var mesh=renderer.GetComponent<MeshFilter>().sharedMesh;var block=new MaterialPropertyBlock();renderer.GetPropertyBlock(block);
        var texture=m.GetTexture("_BaseMap") as Texture2D;
        return new SurfaceInput{name=renderer.name,shader=m.shader.name,keywords=m.shaderKeywords,matrix=renderer.localToWorldMatrix,
            vertices=mesh.vertices,normals=mesh.normals,uv=mesh.uv,indices=mesh.triangles,baseColor=m.GetColor("_BaseColor"),specColor=m.GetColor("_SpecColor"),
            metallic=m.GetFloat("_Metallic"),workflow=m.GetFloat("_WorkflowMode"),cull=m.GetFloat("_Cull"),alphaClip=m.GetFloat("_AlphaClip"),
            alphaToMask=m.GetFloat("_AlphaToMask"),smoothnessChannel=m.GetFloat("_SmoothnessTextureChannel"),cutoff=m.GetFloat("_Cutoff"),
            blockEmpty=block.isEmpty,blockHasSpecular=block.HasProperty(Shader.PropertyToID("_SpecColor")),blockSpecular=block.GetVector("_SpecColor"),
            map=texture==null?null:new TextureInput{format=texture.format.ToString(),filter=texture.filterMode.ToString(),wrapU=texture.wrapModeU.ToString(),wrapV=texture.wrapModeV.ToString(),
                width=texture.width,height=texture.height,mips=texture.mipmapCount,srgb=texture.isDataSRGB,pixels=texture.GetPixels32()}};
    }
    void Update(){
        if(finished)return;
        try{
            double now=Time.realtimeSinceStartupAsDouble;
            if(stopping){
                if(pending!=0||(capture!=null&&!capture.IsDrained)){
                    if(now-started>=300&&!checkpoint){checkpoint=true;File.WriteAllText(Path.Combine(output,"drain-timeout.txt"),"Readbacks remain nonterminal. Owners retained; no restart is authorized.");}
                    return;
                }
                Finish();return;
            }
            Need(now-started<300,"Preparation timed out.");
            if(!RenderPipeline.SupportsRenderRequest(targetCamera,request))return;
            var current=RenderPipelineManager.currentPipeline;if(current==null||!ReferenceEquals(current,pipeline)){pipeline=current;stable=0;return;}
            if(++stable<2)return;
            ticket=capture.Request(0,Time.frameCount);result.engine=Time.frameCount;result.sourceSeconds=Time.realtimeSinceStartupAsDouble;
            RenderPipeline.SubmitRenderRequest(targetCamera,request);result.requests=1;result.camera=ticket.Camera;result.receipt=ticket.ReceiptPath;
            result.diagnostics=feature.GetDiagnostics().Single(d=>d.camera==targetCamera.name);result.work=result.diagnostics.transportRecordedWorkFrame;
            Need(result.work==0&&result.diagnostics.transportRecordedEngineFrame==result.engine,"Actual source association differs.");
            capture.Seal();pending++;
            try{AsyncGPUReadback.Request(target,0,TextureFormat.RGBAFloat,r=>{
                try{Need(r.done&&!r.hasError,"Final readback failed.");pixels=r.GetData<byte>().ToArray();result.finalCompleted=true;result.finalCompletionSeconds=Time.realtimeSinceStartupAsDouble;}
                catch(Exception ex){Fail(ex);}finally{pending--;}
            });}catch{pending--;throw;}
            stopping=true;
        }catch(Exception ex){Fail(ex);}
    }
    void Fail(Exception ex){if(string.IsNullOrEmpty(result.error)){result.error=ex.ToString();Debug.LogError(result.error);}stopping=true;capture?.Close("Observer failed.");}
    void Finish(){
        if(finished)return;finished=true;
        try{
            if(string.IsNullOrEmpty(result.error)){
                Need(result.requests==1&&ticket!=null&&ticket.Succeeded&&result.finalCompleted&&pixels!=null&&result.runtimeErrors.Count==0,"Single source or renderer reported failure.");
                result.captureDrained=capture.IsDrained;File.WriteAllBytes(Path.Combine(output,result.finalFile),pixels);result.status="collected";
            }
        }catch(Exception ex){result.error=ex.ToString();}
        capture?.Close();Application.logMessageReceived-=Log;
        if(output!=null)File.WriteAllText(Path.Combine(output,"scene-result.json"),JsonUtility.ToJson(result,true));
        if(targetCamera)targetCamera.targetTexture=null;var old=target;var materials=runtimeMaterials.ToArray();
        HybridLumenGIResourceRetirement.Retire(()=>{if(old){old.Release();Destroy(old);}foreach(var m in materials)if(m)Destroy(m);});
        Application.Quit(result.status=="collected"?0:1);
    }
}
