# 单采样普通 Player 的 alpha／smoothness-alpha 联合轮廓

本次只补原Validation的普通URPLit轮廓一致合同。51已证明实际HLSL联合逻辑，124证明regular cutout同帧屏幕覆盖，130证明其他workflow关键字，但不能替代本联合语义：smoothness keyword改变底图alpha是否参与裁剪。Astra同意一次限定Player对照，不展开更多关键字排列。

## 运行前固定输入及独立预期

依据安装URP17.0.4 `SurfaceInput.hlsl::Alpha`：普通分支alpha=BaseMap.a*BaseColor.a，SMOOTHNESS_TEXTURE_ALBEDO_CHANNEL_A分支alpha=BaseColor.a，再按ALPHATEST_ON执行cutoff。

两个front Quad均XY z=0、向-Z、半宽1.2／半高.65，中心(-1.5,0,0)/(1.5,0,0)，UV0..1；另有蓝色不透明backboard中心(0,0,1)、半宽3／半高1.5。普通Lit、Metallic0、Workflow1、opaque／Cull Back／AO1，无发光、法线或detail。regular前景红RGB、smoothness前景绿RGB，二者BaseColor.a=.75、cutoff=.5、AlphaClip1且ALPHATEST_ON。前者smoothness channel0／keyword关闭，后者channel1／keyword开启。后板蓝RGB、alpha1、无clip。

两个front共享8×8 linear RGBA32 checker，Point／Clamp／无mip，RGB白，(x+y)偶数alpha255、奇数0。独立预期：regular应有前景／孔洞，孔洞读蓝后板；smoothness分支应忽略底图alpha、全实绿色前景。必须先确认原生URP真实呈现这种区别，然后要求GI重绘与原生同帧一致；两侧共同漏画或输入keyword未生效不通过。

URP作者导入可把AlphaToMask设为1。沿124既有单采样范围，只在运行时克隆两个front并设AlphaToMask0，其他输入保持；不改原作者资产，不推广默认flag1或A2C。相机固定(0,0,-3)、identity旋转、orthographic size1.8、960×540，单采样、Forward Base、无postprocess／动态分辨率。GI沿122的2ray／filter4／半GI，只设置环境黑／intensity1／DiffuseReflectance显示；所有原生环境／灯／SH／反射／烘焙／发光为零，无Proxy世界。DiffuseReflectance图只用于来源／覆盖判读，不作照明误差参考。

## 固定域与判据

原始full像素域：regular x=77..432，smoothness x=527..882，二者y=175..364，包含内部alpha边界，远离几何外边；不按输出或有效性选点。实际camera矩阵＋原生深度反投影给出XY，对源前景做独立UV映射 u=(x-(cx-1.2))/2.4、v=(y+.65)/1.3；regular应保留floor(8u)+floor(8v)偶数，否则读z=1后板，smoothness应全部z=0。

- 实际源keyword／数值／runtime AlphaToMask0、纹理格式／sampler／像素必须与上述输入一致。
- 域内原生与GI captureDepth均有限且逐像素绝对差≤1e-6；两者各自反投影应与独立预期z=0或1相差≤.0025世界单位。regular必须有两种有效来源，smoothness全部前景，不只比较两侧彼此相等。
- emissionValidity证明域内已知材质、无发光；AO1。按独立前／后来源，捕获RGB应为.96倍红／绿／蓝，最大绝对通道差≤2/255。DiffuseReflectance Final也应读正确来源颜色（同一2/255存储容差），防止漏画／unknown黑冒充一致。
- 一次普通Win64／Mono／DX12 Release/None构建，一次Player source0，Editor不另Play。既有Capture及Final真实回读排空后退出。300秒仍非终止只写retained checkpoint，不强销毁／重启。来源、原生区别、读回或目标不足按事实收束，不改域／阈值或自动增补排列。

通过仅关闭此stockLit、Point无mip、单采样、runtime AlphaToMask0、两个联合输入的普通Player覆盖合同。不推广射线／身份历史、A2C／MSAA、Replace、任意材质组合或全部G1；不改公开122。结果后交Astra采用边界审查并结束。
