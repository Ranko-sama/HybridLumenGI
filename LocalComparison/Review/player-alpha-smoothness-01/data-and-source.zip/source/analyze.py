"""Interpret the one frozen coverage comparison; no GPU, hashes or reference solver."""
import argparse,json
from pathlib import Path
import numpy as np
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def need(ok,why):
    if not ok:raise ValueError(why)
def plane(base,item):
    name=item['data']['file'] if 'data' in item else item['file']
    return np.fromfile(base/name,dtype='<f4').reshape(item['height'],item['width'],4)
def analyze(base):
    r=load(base/'scene-result.json');need(r['status']=='collected' and r['requests']==1 and r['captureDrained'] and r['finalCompleted'] and not r['runtimeErrors'],'Incomplete runtime source')
    need(r['api']=='Direct3D12' and r['unity']=='6000.0.85f1','Platform differs')
    settings=json.loads(r['settings']);need(settings['debugView']==4 and settings['resolutionScale']==.5 and settings['raysPerPixel']==2 and settings['filterIterations']==4 and all(settings['environmentRadiance'][k]==0 for k in 'rgb'),'Configuration differs')
    sources=r['sources'];need(len(sources)==3,'Source set differs')
    colors=[[1,0,0,.75],[0,1,0,.75],[0,0,1,1]]
    for i,s in enumerate(sources):
        kw=set(s['keywords']);need(s['shader']=='Universal Render Pipeline/Lit' and s['metallic']==0 and s['workflow']==1 and s['cull']==2 and s['blockEmpty'] and np.array_equal([s['baseColor'][k] for k in 'rgba'],colors[i]),'Actual material input differs')
        need(('_ALPHATEST_ON' in kw)==(i<2) and ('_SMOOTHNESS_TEXTURE_ALBEDO_CHANNEL_A' in kw)==(i==1) and '_EMISSION' not in kw and s['alphaClip']==(1 if i<2 else 0),'Keyword/numeric input differs')
        if i<2:
            need(s['alphaToMask']==0 and s['cutoff']==.5 and s['smoothnessChannel']==i,'Runtime single-sample/channel input differs')
            t=s['map'];need(t['width']==t['height']==8 and t['mips']==1 and not t['srgb'] and t['format']=='RGBA32' and t['filter']=='Point' and t['wrapU']==t['wrapV']=='Clamp','Actual texture state differs')
            a=np.array([[p[k] for k in 'rgba'] for p in t['pixels']]).reshape(8,8,4);e=np.full((8,8,4),255);y,x=np.indices((8,8));e[:,:,3]=np.where((x+y)%2==0,255,0)
            need(np.array_equal(a,e),'Actual checker pixels differ')
    d=r['diagnostics'];need(not d['hardwareBackend'] and d['publishedInstances']==0 and d['transportRecordedEngineFrame']==r['engine'] and r['work']==0,'Actual source/backend differs')
    folder=base/'capture';c=load(folder/'frame-0000-capture.json');need(c['status']=='complete' and c['workFrame']==r['work'] and c['engineFrame']==r['engine'] and c['composite']['debug']==4,'Capture/source differs')
    samples={p['signalId']:p for p in c['samples']};support={p['role']:p for p in c['support']}
    nd=plane(folder,support['depth']);cd=plane(folder,support['captureDepth']);material=plane(folder,support['material']);emission=plane(folder,support['emissionValidity'])
    final=np.fromfile(base/'final.rgba32f',dtype='<f4').reshape(540,960,4)
    camera=r['camera'];need(camera['matrixOrder']=='row-major' and camera['uvOrigin']=='top-left' and camera['clipDepth']=='zero-to-one','Camera convention differs')
    vp=np.array(camera['projection']).reshape(4,4)@np.array(camera['view']).reshape(4,4);inv=np.linalg.inv(vp);results=[]
    for index,(name,x0,cx) in enumerate([('regular',77,-1.5),('smoothness',527,1.5)]):
        xx,yy=np.meshgrid(np.arange(x0,x0+356),np.arange(175,365));x=xx.ravel();y=yy.ravel();n=nd[y,x,0].astype(float);g=cd[y,x,0].astype(float)
        need(np.isfinite(n).all() and np.isfinite(g).all(),'Nonfinite depth')
        clip=np.c_[(np.c_[x,y]+.5)/[960,540]*2-1,n,np.ones(len(x))];clip[:,1]*=-1
        world=clip@inv.T;world=world[:,:3]/world[:,3:]
        u=(world[:,0]-(cx-1.2))/2.4;v=(world[:,1]+.65)/1.3
        need(np.isfinite(world).all() and np.all((u>0)&(u<1)&(v>0)&(v<1)),'Fixed domain not inside source front projection')
        covered=np.ones(len(x),bool) if index==1 else ((np.floor(8*u).astype(int)+np.floor(8*v).astype(int))%2==0)
        expected_z=np.where(covered,0,1);native_error=abs(world[:,2]-expected_z)
        gclip=clip.copy();gclip[:,2]=g;gworld=gclip@inv.T;gz=gworld[:,2]/gworld[:,3];capture_error=abs(gz-expected_z)
        expected=np.zeros((len(x),3));expected[~covered,2]=.96;expected[covered,index]=.96
        m=material[y,x];e=emission[y,x];f=final[y,x,:3]
        valid=np.isfinite(m).all(1)&np.isfinite(e).all(1)&(abs(e[:,3])>.5)&(abs(e[:,:3]).max(1)<=1e-6)&(abs(m[:,3]-1)<=1/255)
        depth_delta=float(abs(n-g).max());material_error=float(abs(m[:,:3].astype(float)-expected).max());final_error=float(abs(f.astype(float)-expected).max())
        native_front=np.isclose(world[:,2],0,rtol=0,atol=.0025)
        expected_pattern=bool(native_front.all()) if index==1 else bool(np.any(native_front) and np.any(~native_front) and np.array_equal(native_front,covered))
        passed=np.all(valid) and np.isfinite(f).all() and expected_pattern and native_error.max()<=.0025 and capture_error.max()<=.0025 and depth_delta<=1e-6 and material_error<=2/255 and final_error<=2/255
        results.append({'domain':name,'pixels':len(x),'expectedFront':int(covered.sum()),'expectedBack':int((~covered).sum()),'nativeFront':int(native_front.sum()),'nativeBack':int((~native_front).sum()),
            'unknownMaterial':int(np.sum(~valid)),'nativeExpectedPattern':expected_pattern,'nativeWorldZMaxError':float(native_error.max()),'captureWorldZMaxError':float(capture_error.max()),
            'nativeCaptureDepthMaxDelta':depth_delta,'materialMaxError':material_error,'diffuseViewMaxError':final_error,'passed':bool(passed)})
    return {'status':'fixed-player-joint-coverage-observed' if all(s['passed'] for s in results) else 'fixed-coverage-target-not-observed',
        'scope':'One stock Lit Player, single sample, runtime AlphaToMask0, fixed regular/smoothness-alpha inputs; no A2C, ray or identity-history qualification',
        'engine':r['engine'],'work':r['work'],'domains':results}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('capture',type=Path);p.add_argument('output',type=Path);a=p.parse_args();a.output.mkdir(exist_ok=False,parents=True)
    try:r=analyze(a.capture)
    except (ValueError,KeyError,IndexError,OSError) as e:r={'status':'insufficient-input-or-record','error':str(e)}
    (a.output/'result.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(json.dumps(r))
