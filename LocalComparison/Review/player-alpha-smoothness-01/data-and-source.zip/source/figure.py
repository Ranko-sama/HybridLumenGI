import json,sys
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont
base=Path(sys.argv[1]);out=Path(sys.argv[2]);r=json.loads((base/'scene-result.json').read_text());c=json.loads((base/'capture/frame-0000-capture.json').read_text())
support={p['role']:p for p in c['support']}
def plane(role):
    p=support[role];return np.fromfile(base/'capture'/p['file'],dtype='<f4').reshape(p['height'],p['width'],4)
vp=np.array(r['camera']['projection']).reshape(4,4)@np.array(r['camera']['view']).reshape(4,4);inv=np.linalg.inv(vp)
y,x=np.indices((540,960));clip=np.stack(((x+.5)/960*2-1,-((y+.5)/540*2-1),np.zeros_like(x),np.ones_like(x)),axis=-1)
def layers(depth):
    q=clip.copy();q[:,:,2]=depth;h=q@inv.T;world=h[:,:,:3]/h[:,:,3:]
    rgb=np.zeros((540,960,3));front=abs(world[:,:,2])<=.0025;back=abs(world[:,:,2]-1)<=.0025
    rgb[back,2]=.96;rgb[front&(world[:,:,0]<0),0]=.96;rgb[front&(world[:,:,0]>0),1]=.96
    return rgb
arrays=[layers(plane('depth')[:,:,0]),layers(plane('captureDepth')[:,:,0]),plane('material')[:,:,:3]]
canvas=Image.new('RGB',(1460,350),(22,22,27));d=ImageDraw.Draw(canvas);font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',18);small=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',16)
d.text((10,8),'Same source | single sample, runtime AlphaToMask=0 | display flipped vertically | depth colors identify source layers',fill='white',font=font)
for i,a in enumerate(arrays):
    a=np.maximum(a,0);a=a/(1+a);a=np.where(a<=.0031308,12.92*a,1.055*a**(1/2.4)-.055)
    im=Image.fromarray(np.rint(np.clip(np.flipud(a),0,1)*255).astype('uint8')).resize((480,270),Image.Resampling.LANCZOS)
    left=10+480*i;canvas.paste(im,(left,60));d=ImageDraw.Draw(canvas)
    d.text((left+4,35),['Native depth layers (false color)','GI capture depth layers (false color)','Actual captured diffuse reflectance'][i],fill='white',font=small)
    for lo,hi in [(77,432),(527,882)]:d.rectangle((left+lo/2,60+(539-364)/2,left+hi/2,60+(539-175)/2),outline='white',width=1)
d.text((14,332),'Red: regular alpha test, holes expose blue backboard.  Green: smoothness-alpha, solid foreground.  White: frozen interior domains.',fill='white',font=small)
canvas.save(out)
