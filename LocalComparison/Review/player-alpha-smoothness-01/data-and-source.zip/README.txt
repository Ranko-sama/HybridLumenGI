One fixed stock Lit alpha/smoothness-alpha coverage Player observation.

Recompute with Python + NumPy:
  python source/analyze.py capture replay-output
Output must be fresh.

Original runtime source inputs include material keywords/numeric channel/base alpha, actual runtime AlphaToMask0, checker bytes/sampler, source mesh positions/UV/index/matrices and actual camera. The independent checker/solid expectation comes from installed URP17.0.4 Alpha logic, not observed capture or validity.

Selected original Capture support planes are included for the checks. Unchanged complete Capture receipts may list unused plane paths intentionally not bundled. This is a replay of the scoped coverage checks, not a full support-session export.

There was one ordinary BuildOptions.None Win64 Mono DX12 build and one Player source0. Native build/player exit records and executed observer sources are preserved. The Host only clones front materials at runtime to force AlphaToMask0 after URP author import, matching the previously bounded single-sample contract. No product edits or public Release122 rebuild.

The displayed depth panels are false-color layer visualizations, not native lighting. DiffuseReflectance confirms source ownership, not radiance accuracy. Scope does not include A2C/default author flag1, MSAA, Replace, ray traversal, identity history, arbitrary inputs/platforms or full G1. Unknown material counts refer only to the fixed domains, not all filtered pixels.
