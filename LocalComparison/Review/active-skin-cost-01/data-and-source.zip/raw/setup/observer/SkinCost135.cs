// Opt-in, one ordinary K+Space workload. No product resource disposal or extra GPU queries.
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using HybridLumenGI;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

[DefaultExecutionOrder(30000)]
public sealed class SkinCost135 : MonoBehaviour
{
    const int WarmupLimit = 256, ActivePreparation = 32, DrainLimit = 32, FrameLimit = 8192, CompletionLimit = 16384;
    const double WindowSeconds = 35;
    const string ExpectedScene = "Assets/HLGINeutral106/Variant/NeutralThreeRooms.unity";
    const BindingFlags Fields = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
    static readonly FieldInfo TokenId = typeof(HybridLumenGINativeGpuTiming.FrameToken).GetField("Id", Fields),
        TokenOwner = typeof(HybridLumenGINativeGpuTiming.FrameToken).GetField("Owner", Fields),
        TokenEpoch = typeof(HybridLumenGINativeGpuTiming.FrameToken).GetField("Epoch", Fields),
        TokenDevice = typeof(HybridLumenGINativeGpuTiming.FrameToken).GetField("DeviceEpoch", Fields);
    static readonly string[] Names = { "frame", "width", "height", "fullWidth", "fullHeight", "lastHardware", "useNativeGpuTiming",
        "effectiveBudget", "gpuGeneration", "receiverIdentityEnabled", "receiverIdentityDraws", "receiverUnknownRectangles",
        "hardwareMaterialStatus", "hardwareMaterialUnknownRecords", "hardwareMaterialFrameBytes", "gpuSettings", "exactSoftwareGeometry", "epoch" };

    [Serializable] public sealed class Actor
    {
        public bool skinnedDeformation, deformationRunning, doorMoving, sourceIsSkin, sourceReferencesAgree, publicationKnown;
        public float bendDegrees;
        public string status, sourceRendererType, sourceRendererName, publicationPhase;
        public int publishedFrame = -1, pendingFrame = -1, sourceRendererId, sourceMeshId, sourceVertexCount, sdfMeshId, chartMeshId;
        public int jobsGlobal, publishedSnapshotsGlobal, failedCleanupGlobal, publicationEngineFrame = -1, publicationWorkFrame = -1;
        public long reservedBytesGlobal;
    }
    [Serializable] public sealed class Frame
    {
        public int index, stage, engineFrame, giFrame = -1, workFrame = -1, transportEngineFrame = -1;
        public int width, height, fullWidth, fullHeight, generation, gpuGeneration, stateEpoch, tokenEngineFrame = -1, providerIndex = -1;
        public double sourceSeconds, windowElapsed = -1;
        public ulong token, owner, deviceEpoch, timingDeviceEpoch; public long epoch;
        public bool stateAvailable, stateChanged, native, nativeAvailable, tokenValid, hardware, exactSoftware, identity, feedback, ready;
        public int instances, warming, capacityPending, cards, cardPending, globalReady, globalPending, globalUpdated;
        public int meshes, unrepresented, identityDraws, identityUnknown, materialUnknown, patchQuota, captureQuota, brickQuota, patchesScheduled;
        public int pagePending, pageFailed, pageActiveOperations, pageRetiringLeases, groupMembers;
        public bool groupPublished, groupTransitioning;
        public long materialBytes, uploadBytes, pageIoBytesInFlight;
        public double scale;
        public string materialStatus, timingStatus, recordedBackend, stateError;
        public ulong completed, exported, unexported, invalid, cancelled, timedOut, feedbackRejected;
        public int buffered, pending;
        public Actor actor;
        public HybridLumenGIVideoMemory.Snapshot memory;
    }
    [Serializable] public sealed class Sample
    {
        public ulong token, owner, deviceEpoch, frequency, begin0, end0, begin1, end1, begin2, end2;
        public int generation, sourceFrame, readFrame, providerIndex; public long epoch;
        public Sample(HybridLumenGINativeGpuTiming.CompletedSample s, int provider)
        {
            token = s.Token; owner = s.Owner; deviceEpoch = s.DeviceEpoch; frequency = s.Frequency;
            begin0 = s.Begin0; end0 = s.End0; begin1 = s.Begin1; end1 = s.End1; begin2 = s.Begin2; end2 = s.End2;
            generation = s.Generation; sourceFrame = s.SourceFrame; readFrame = s.ReadFrame; epoch = s.Epoch; providerIndex = provider;
        }
    }
    [Serializable] public sealed class Publication
    {
        public int firstObservedEngineFrame, capturedFrame, ageFrames, meshId, vertexCount, stage;
        public double sourceSeconds;
        public string scope = "Capture frame to first CPU observation of the matching Mesh/SDF/charts snapshot; not GPU consumption or BakeMesh duration";
    }
    [Serializable] public sealed class Marker
    {
        public string utc, phase;
        public int engineFrame, sourceIndex;
        public double realtime, plannedSeconds = WindowSeconds, elapsedSeconds;
        public bool activeSkin;
        public Actor actor;
    }
    [Serializable] public sealed class Provider
    {
        public int index, pending, buffered;
        public string status;
        public ulong completed, exported, unexported, invalid, cancelled, timedOut;
    }
    [Serializable] public sealed class Run
    {
        public string status = "failed", error = "", unity, gpu, api, driver, scene, outputDirectory;
        public string scope = "One ordinary saved default color-wall view, K real Skin + Space animation using natural deltaTime; all source frames retained";
        public string sourceClock = "Target camera endCameraRendering realtime; Present is a separate same-run application interval observation";
        public string scopeExclusions = "GI ReceiverCapture/Transport/Composite only; excludes CPU preparation/BakeMesh, some uploads, whole application GPU time, total/instantaneous VRAM and specific GPU geometry-consumption latency";
        public string publicationScope = "PublishedFrame is capture frame; matching sources and TryGetPublication are CPU observations, not GPU fence/transport proof";
        public string cpuCaptureMilliseconds = "unknown", gpuGeometryConsumptionLatency = "unknown", budgetDecision = "not evaluated by observer";
        public int warmupLimit = WarmupLimit, activePreparationFrames = ActivePreparation, drainLimit = DrainLimit;
        public int frameLimit = FrameLimit, completionLimit = CompletionLimit, frames, completions, sourceStart = -1, sourceEnd = -1;
        public int firstEngineFrame = -1, windowSources, windowCompletions, drainFrames, distinctWindowCapturedFrames, windowBendChanges;
        public int vSyncCount, targetFrameRate;
        public int skinActivatedEngineFrame = -1, sdfResolution, updateIntervalFrames, sourceBones, sourceVertices, sourceTriangles;
        public int vertexBudgetPerFrame, maximumWorkers;
        public long deformationMemoryBudgetBytes, deformationUploadBudgetBytesPerFrame;
        public double skinActivatedSeconds = -1, captureBudgetMillisecondsPerFrame;
        public double plannedWindowSeconds = WindowSeconds, windowStartSeconds = -1, windowEndSeconds = -1, windowDuration;
        public bool windowComplete, workloadQualified, timingQualified, memoryQualified, memoryWindowCaptured, screenshotSaved;
        public bool initialMeasureVideoMemory, initialSampleHud, initialInteractionHud;
        public string timingQualification, memoryQualification, screenshot = "";
        public string screenshotStatus = "Unavailable: the released minimal project has no ScreenCapture module; no image judgment or added capture tool";
        public int[] missingNativeSourceFrames, unmatchedOrDuplicateCompletionFrames;
        public string[] scopes = { "ReceiverCapture", "Transport", "Composite" };
        public Vector3 cameraPosition; public Quaternion cameraRotation;
        public HybridLumenGIVideoMemory.Snapshot memoryWindow;
        public Provider[] providers;
        public List<Publication> publications = new List<Publication>();
    }

    HybridLumenGIUnifiedSample sample;
    HybridLumenGIUnifiedSampleInteraction interaction;
    HybridLumenGIRendererFeature feature;
    HybridLumenGIRendererFeature.Settings settings;
    Camera targetCamera;
    HybridLumenGIAssetPageStreamer streamer;
    HybridLumenGIStreamedRepresentation aggregate;
    HybridLumenGIStreamedRepresentation[] details;
    HashSet<HybridLumenGIProxy> visible;
    HybridLumenGIProxy actorProxy;
    HybridLumenGIDeformedMesh deformation;
    HybridLumenGIVideoMemory videoMemory;
    object state; FieldInfo[] fields;
    HybridLumenGINativeGpuTiming timing;
    HybridLumenGIGpuBudgetController controller;
    HybridLumenGIScene scene;
    HybridLumenGISurfaceCache surface;
    HybridLumenGIGlobalSdf global;
    HybridLumenGIHardwareBackend geometry;
    HybridLumenGIReceiverHistory receiver;
    HybridLumenGICacheScheduler scheduler;
    readonly List<HybridLumenGINativeGpuTiming> timings = new List<HybridLumenGINativeGpuTiming>();
    readonly List<HybridLumenGIProxy> published = new List<HybridLumenGIProxy>(4), target = new List<HybridLumenGIProxy>(4);
    readonly List<Frame> frames = new List<Frame>(4096);
    readonly List<Sample> completions = new List<Sample>(4096);
    readonly HashSet<int> windowCaptures = new HashSet<int>();
    readonly Run run = new Run();
    HybridLumenGIUnifiedSample.Ledger startLedger, endLedger;
    string outputArgument, directory, settingsBefore, settingsMeasure, failure;
    Matrix4x4 cameraProjection;
    int phase, readyStreak, preparationCount, drainCount, lastEngine = -1, startupFrame, lastPublished = -1, lastMesh;
    double startupSeconds;
    float? previousWindowBend;
    bool activateNextUpdate, beginWindowNextSource, finishRequested, finishing, finished, subscribed;

    static object Field(object o, string name) => o?.GetType().GetField(name, Fields)?.GetValue(o);
    T Read<T>(int i) => (T)fields[i].GetValue(state);
    static void Require(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
    static string Arg(string[] args, string key) { int i = Array.IndexOf(args, key); return i >= 0 && i + 1 < args.Length ? args[i + 1] : null; }

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void Install()
    {
        var args = Environment.GetCommandLineArgs();
        if (Array.IndexOf(args, "-hlgiActiveSkinCost") < 0 || Array.IndexOf(args, "-skinCostOutput") < 0) return;
        var observer = new GameObject("SkinCost135 temporary observer").AddComponent<SkinCost135>();
        observer.outputArgument = Arg(args, "-skinCostOutput");
    }
    void Start()
    {
        startupFrame = Time.frameCount; startupSeconds = Time.realtimeSinceStartupAsDouble;
        Application.runInBackground = true;
        try {
            Require(!string.IsNullOrWhiteSpace(outputArgument) && Path.IsPathRooted(outputArgument) &&
                !Directory.Exists(outputArgument) && !File.Exists(outputArgument), "Fresh absolute -skinCostOutput required; existing output is preserved.");
            directory = Path.GetFullPath(outputArgument); Directory.CreateDirectory(directory);
            var samples = UnityEngine.Object.FindObjectsByType<HybridLumenGIUnifiedSample>(FindObjectsSortMode.None);
            var inputs = UnityEngine.Object.FindObjectsByType<HybridLumenGIUnifiedSampleInteraction>(FindObjectsSortMode.None);
            Require(samples.Length == 1 && inputs.Length == 1, "Expected one ordinary sample and interaction.");
            sample = samples[0]; interaction = inputs[0];
            Require(sample.isActiveAndEnabled && interaction.isActiveAndEnabled && sample.gameObject.scene.path == ExpectedScene,
                "Expected the saved ordinary122 sample.");
            Require((bool)Field(interaction, "initialized"), "Interaction.Start must complete before observer.Start.");
            targetCamera = Field(sample, "targetCamera") as Camera; feature = Field(sample, "feature") as HybridLumenGIRendererFeature;
            streamer = Field(sample, "streamer") as HybridLumenGIAssetPageStreamer;
            aggregate = Field(sample, "aggregate") as HybridLumenGIStreamedRepresentation;
            details = Field(sample, "details") as HybridLumenGIStreamedRepresentation[];
            visible = Field(sample, "visible") as HashSet<HybridLumenGIProxy>;
            videoMemory = Field(sample, "videoMemory") as HybridLumenGIVideoMemory;
            Require(targetCamera && feature && feature.isActive && streamer && aggregate && details != null && details.Length == 3 &&
                visible != null && videoMemory != null, "Ordinary sample references unavailable.");
            settings = Field(feature, "settings") as HybridLumenGIRendererFeature.Settings;
            Require(settings != null && settings.raysPerPixel == 2 && settings.filterIterations == 4 && settings.resolutionScale == .5f && settings.preferHardwareTracing,
                "Keep the released2ray/filter4/halfGI/DXR preference.");
            Require(!interaction.RoomsEnabled && !interaction.TurnedPassage && !interaction.DoorMoving && !interaction.DeformationRunning &&
                !interaction.SkinnedDeformation, "Start from the untouched ordinary color-wall view and readable paused door.");
            Require(SystemInfo.graphicsDeviceType == GraphicsDeviceType.Direct3D12, "Native timing requires DX12.");
            var data = targetCamera.GetUniversalAdditionalCameraData();
            Require(targetCamera.isActiveAndEnabled && targetCamera.targetTexture == null && !targetCamera.stereoEnabled &&
                data.renderType == CameraRenderType.Base && data.cameraStack.Count == 0, "Keep the ordinary Base backbuffer camera.");
            Require(Screen.width == 960 && Screen.height == 540 && targetCamera.pixelWidth == 960 && targetCamera.pixelHeight == 540,
                "Launch at960x540; this observer does not resize or move the camera.");
            run.initialMeasureVideoMemory = sample.MeasureVideoMemory; run.initialSampleHud = sample.ShowControls;
            run.initialInteractionHud = (bool)Field(interaction, "showControls");
            sample.MeasureVideoMemory = false;
            settingsBefore = JsonUtility.ToJson(settings, true);
            settings.measureGpuCost = true; settings.preferNativeGpuTiming = true; settings.adaptiveGpuBudget = false; settings.targetGpuMilliseconds = 0;
            settingsMeasure = JsonUtility.ToJson(settings);
            run.cameraPosition = targetCamera.transform.position; run.cameraRotation = targetCamera.transform.rotation;
            cameraProjection = targetCamera.projectionMatrix;
            Application.logMessageReceived += Log; RenderPipelineManager.endCameraRendering += Rendered; subscribed = true;
        } catch (Exception e) { Fail(e.ToString()); }
    }
    bool BindCurrent(Frame row)
    {
        var cameras = Field(Field(feature, "pass"), "cameras") as IDictionary;
        object current = null;
        if (cameras != null) foreach (var c in cameras.Values) if (ReferenceEquals(Field(c, "camera"), targetCamera)) {
            Require(current == null, "Ambiguous exact camera state."); current = c;
        }
        if (current == null) { row.stateError = "No state for the rendered camera"; return false; }
        row.stateChanged = !ReferenceEquals(current, state);
        if (row.stateChanged) {
            state = current; readyStreak = 0;
            fields = new FieldInfo[Names.Length];
            for (int i = 0; i < Names.Length; i++) fields[i] = state.GetType().GetField(Names[i], Fields) ?? throw new InvalidOperationException("Missing existing field " + Names[i]);
            timing = (HybridLumenGINativeGpuTiming)Field(state, "nativeGpuTiming");
            controller = (HybridLumenGIGpuBudgetController)Field(state, "gpuBudget");
            scene = (HybridLumenGIScene)Field(state, "scene"); surface = (HybridLumenGISurfaceCache)Field(state, "surfaceCache");
            global = (HybridLumenGIGlobalSdf)Field(state, "globalSdf"); geometry = (HybridLumenGIHardwareBackend)Field(state, "hardware");
            receiver = (HybridLumenGIReceiverHistory)Field(state, "receiverHistory"); scheduler = (HybridLumenGICacheScheduler)Field(state, "scheduler");
            Require(timing != null && controller != null && scene != null && surface != null && global != null && geometry != null &&
                receiver != null && scheduler != null, "Existing product camera services unavailable.");
            if (!timings.Contains(timing)) timings.Add(timing);
        }
        row.providerIndex = timings.IndexOf(timing); return true;
    }
    void ExportCompleted()
    {
        for (int p = 0; p < timings.Count; p++) while (timings[p].TryDequeueCompleted(out var value)) {
            Require(completions.Count < CompletionLimit, "Completion record limit reached; no complete budget qualification possible.");
            completions.Add(new Sample(value, p));
        }
    }
    Actor ReadActor()
    {
        if (!deformation) deformation = Field(interaction, "deformation") as HybridLumenGIDeformedMesh;
        if (!actorProxy) actorProxy = Field(interaction, "deformationProxy") as HybridLumenGIProxy;
        var a = new Actor { skinnedDeformation = interaction.SkinnedDeformation, deformationRunning = interaction.DeformationRunning,
            doorMoving = interaction.DoorMoving, bendDegrees = interaction.BendDegrees,
            publishedFrame = deformation ? deformation.PublishedFrame : -1, pendingFrame = deformation ? deformation.PendingFrame : -1,
            status = deformation ? deformation.Status : "No deformation component yet",
            reservedBytesGlobal = HybridLumenGIDeformedMesh.ReservedBytes, jobsGlobal = HybridLumenGIDeformedMesh.PendingWorkerCount,
            publishedSnapshotsGlobal = HybridLumenGIDeformedMesh.PublishedSnapshotCount, failedCleanupGlobal = HybridLumenGIDeformedMesh.FailedCleanupCount };
        if (!actorProxy) return a;
        var source = actorProxy.SourceRenderer; var mesh = actorProxy.SourceMesh;
        var sdf = actorProxy.MeshSdf; var charts = actorProxy.SurfaceCharts;
        a.sourceIsSkin = source is SkinnedMeshRenderer;
        a.sourceRendererId = source ? source.GetInstanceID() : 0; a.sourceRendererType = source ? source.GetType().Name : "none";
        a.sourceRendererName = source ? source.name : "none";
        a.sourceMeshId = mesh ? mesh.GetInstanceID() : 0; a.sourceVertexCount = mesh ? mesh.vertexCount : 0;
        a.sdfMeshId = sdf && sdf.SourceMesh ? sdf.SourceMesh.GetInstanceID() : 0;
        a.chartMeshId = charts && charts.SourceMesh ? charts.SourceMesh.GetInstanceID() : 0;
        a.sourceReferencesAgree = mesh && sdf && charts && sdf.SourceMesh == mesh && charts.SourceMesh == mesh;
        a.publicationKnown = feature.TryGetPublication(targetCamera, actorProxy, out var publication);
        a.publicationPhase = publication.phase.ToString(); a.publicationEngineFrame = publication.preparedEngineFrame;
        a.publicationWorkFrame = publication.preparedWorkFrame;
        return a;
    }
    void ReadCamera(Frame r)
    {
        var budget = Read<HybridLumenGIGpuBudgetController.Budget>(7); var token = timing.CurrentFrameToken;
        r.giFrame = Read<int>(0); r.width = Read<int>(1); r.height = Read<int>(2); r.fullWidth = Read<int>(3); r.fullHeight = Read<int>(4);
        r.hardware = Read<bool>(5); r.native = Read<bool>(6); r.gpuGeneration = Read<int>(8); r.identity = Read<bool>(9);
        r.identityDraws = Read<int>(10); r.identityUnknown = Read<int>(11); r.materialStatus = Read<string>(12);
        r.materialUnknown = Read<int>(13); r.materialBytes = Read<long>(14); r.exactSoftware = Read<bool>(16); r.stateEpoch = Read<int>(17);
        r.tokenValid = token.IsValid; r.tokenEngineFrame = token.EngineFrame; r.generation = token.Generation;
        r.token = (ulong)TokenId.GetValue(token); r.owner = (ulong)TokenOwner.GetValue(token);
        r.deviceEpoch = (ulong)TokenDevice.GetValue(token); r.epoch = (long)TokenEpoch.GetValue(token);
        r.timingDeviceEpoch = timing.DeviceEpoch; r.nativeAvailable = timing.Available;
        r.feedback = controller.FeedbackActive; r.instances = scene.PublishedCount; r.warming = scene.WarmingCount; r.capacityPending = scene.PendingCapacity;
        r.cards = surface.ReadyCards; r.cardPending = surface.PendingCards; r.globalReady = global.ReadyBrickCount;
        r.globalPending = global.PendingBrickCount; r.globalUpdated = global.UpdatedBrickCount;
        r.meshes = geometry.MeshCount; r.unrepresented = geometry.FallbackCount;
        r.patchQuota = budget.CachePatches; r.captureQuota = budget.SurfaceCaptures; r.brickQuota = budget.GlobalBricks; r.scale = budget.Scale;
        r.patchesScheduled = scheduler.SelectedCount; r.uploadBytes = HybridLumenGIRayTexturePool.UploadBytesUsed;
        r.timingStatus = timing.Status.ToString(); r.completed = timing.CompletedResults; r.exported = timing.ExportedResults;
        r.unexported = timing.UnexportedResults; r.invalid = timing.InvalidCompletedResults; r.cancelled = timing.CancelledSubmissions;
        r.timedOut = timing.TimedOutSubmissions; r.feedbackRejected = timing.RejectedResults; r.buffered = timing.BufferedCompletedRecords; r.pending = timing.PendingCount;
        r.recordedBackend = Field(state, "recordedTransportBackend") as string;
        r.transportEngineFrame = (int)Field(state, "transportRecordedEngineFrame"); r.workFrame = (int)Field(state, "transportRecordedWorkFrame");
        bool known = feature.TryGetHlodPublication(targetCamera, aggregate.Proxy, published, target, out var group);
        r.groupMembers = published.Count; r.groupTransitioning = group.transitioning;
        bool complete = published.Count == details.Length && target.Count == details.Length && aggregate.SourceRenderer && aggregate.SourceRenderer.forceRenderingOff;
        foreach (var detail in details) {
            var renderer = detail.SourceRenderer;
            complete &= detail.HasBoundAssets && published.Contains(detail.Proxy) && target.Contains(detail.Proxy) &&
                detail.Proxy.SourceRenderer == renderer && renderer && renderer.enabled && renderer.gameObject.activeInHierarchy && !renderer.forceRenderingOff;
        }
        bool visibleMatches = visible.Count == published.Count; foreach (var p in published) visibleMatches &= visible.Contains(p);
        r.groupPublished = known && group.preparedEngineFrame == Time.frameCount && group.phase == HybridLumenGIScene.PublicationPhase.Published && complete && visibleMatches;
        var pages = streamer.State;
        if (pages != null) {
            r.pageActiveOperations = pages.ActiveOperations; r.pageIoBytesInFlight = pages.IoBytesInFlight; r.pageRetiringLeases = pages.RetiringLeases;
            foreach (var page in pages.States) {
                if (page.Status == HybridLumenGIAssetPageStreaming.Phase.Failed || page.Status == HybridLumenGIAssetPageStreaming.Phase.ReleaseFailed) r.pageFailed++;
                if ((page.Wanted && page.Status != HybridLumenGIAssetPageStreaming.Phase.Ready) ||
                    page.Status == HybridLumenGIAssetPageStreaming.Phase.LoadingBundle || page.Status == HybridLumenGIAssetPageStreaming.Phase.BundleReady ||
                    page.Status == HybridLumenGIAssetPageStreaming.Phase.LoadingAsset || page.Status == HybridLumenGIAssetPageStreaming.Phase.Releasing) r.pagePending++;
            }
        }
        // Readiness is used only BEFORE activating Skin. It never filters an active source frame.
        r.ready = r.native && r.nativeAvailable && r.tokenValid && r.tokenEngineFrame == r.engineFrame && r.hardware && !r.exactSoftware &&
            r.instances > 0 && r.cards > 0 && r.groupPublished && !r.groupTransitioning && streamer.Available && pages != null &&
            r.pagePending == 0 && r.pageFailed == 0 && r.pageActiveOperations == 0 && r.pageIoBytesInFlight == 0 && r.pageRetiringLeases == 0 &&
            r.warming == 0 && r.capacityPending == 0 && r.cardPending == 0 && (!settings.globalSdfEnabled || r.globalPending == 0) &&
            (!settings.receiverObjectHistory || r.identity && receiver.IsPublished && r.identityDraws > 0 && r.identityUnknown == 0) &&
            r.materialUnknown == 0 && r.uploadBytes == 0;
    }
    void RecordPublication(Frame row)
    {
        var a = row.actor;
        if (!a.sourceIsSkin || !a.sourceReferencesAgree || a.publishedFrame < run.skinActivatedEngineFrame || run.skinActivatedEngineFrame < 0 ||
            (a.publishedFrame == lastPublished && a.sourceMeshId == lastMesh)) return;
        run.publications.Add(new Publication { firstObservedEngineFrame = row.engineFrame, capturedFrame = a.publishedFrame,
            ageFrames = row.engineFrame - a.publishedFrame, meshId = a.sourceMeshId, vertexCount = a.sourceVertexCount,
            sourceSeconds = row.sourceSeconds, stage = row.stage });
        lastPublished = a.publishedFrame; lastMesh = a.sourceMeshId;
        if (row.stage == 2) windowCaptures.Add(a.publishedFrame);
    }
    void Rendered(ScriptableRenderContext context, Camera camera)
    {
        if (!ReferenceEquals(camera, targetCamera) || finishRequested || finishing || finished) return;
        try {
            Require(frames.Count < FrameLimit, "Source record limit reached.");
            if (beginWindowNextSource) { phase = 2; beginWindowNextSource = false; }
            // Add the source record before inspecting availability. No fallback/unknown/missing timing row is discarded.
            var row = new Frame { index = frames.Count, engineFrame = Time.frameCount, stage = phase,
                sourceSeconds = Time.realtimeSinceStartupAsDouble, actor = ReadActor(), memory = videoMemory.Current };
            frames.Add(row);
            Require(lastEngine < 0 || row.engineFrame > lastEngine, "Duplicate/reversed target camera source."); lastEngine = row.engineFrame;
            ExportCompleted(); row.stateAvailable = BindCurrent(row);
            if (row.stateAvailable) ReadCamera(row);
            ExportCompleted();
            Require(!interaction.RoomsEnabled && !interaction.TurnedPassage && !interaction.DoorMoving,
                "The ordinary default view/M-off workload changed.");
            Require(sample.isActiveAndEnabled && interaction.isActiveAndEnabled && feature.isActive && camera.targetTexture == null &&
                camera.transform.position == run.cameraPosition && camera.transform.rotation == run.cameraRotation && camera.projectionMatrix == cameraProjection &&
                camera.pixelWidth == 960 && camera.pixelHeight == 540, "Ordinary camera/feature changed.");
            Require(settings.measureGpuCost && settings.preferNativeGpuTiming && !settings.adaptiveGpuBudget && settings.targetGpuMilliseconds == 0 &&
                (!row.stateAvailable || Read<string>(15) == settingsMeasure), "Measurement-only settings changed.");
            RecordPublication(row);
            if (phase == 0) {
                readyStreak = row.ready ? readyStreak + 1 : 0;
                if (readyStreak >= 16) activateNextUpdate = true;
                else Require(frames.Count < WarmupLimit, "Initial native/near readiness not reached in256 source frames.");
            } else if (phase == 1) {
                Require(row.actor.skinnedDeformation && row.actor.deformationRunning && row.actor.sourceIsSkin, "K+Space did not produce an active Skin source.");
                preparationCount++;
                if (preparationCount == ActivePreparation) {
                    startLedger = sample.CaptureLedger(); sample.MeasureVideoMemory = true;
                    beginWindowNextSource = true;
                }
            } else if (phase == 2) {
                Require(row.actor.skinnedDeformation && row.actor.deformationRunning && row.actor.sourceIsSkin, "Active Skin workload stopped inside the window.");
                if (run.sourceStart < 0) {
                    run.sourceStart = row.engineFrame; run.windowStartSeconds = row.sourceSeconds;
                    WriteMarker("window-start.json", "start", row);
                }
                row.windowElapsed = row.sourceSeconds - run.windowStartSeconds; run.windowSources++;
                if (previousWindowBend.HasValue && row.actor.bendDegrees != previousWindowBend.Value) run.windowBendChanges++;
                previousWindowBend = row.actor.bendDegrees;
                if (row.windowElapsed >= WindowSeconds) {
                    CloseWindow(row); interaction.SetDeformationRunning(false); phase = 3;
                }
            } else {
                drainCount++;
                if (drainCount >= DrainLimit) BeginFinish();
            }
        } catch (Exception e) { Fail(e.ToString()); }
    }
    void WriteMarker(string filename, string phaseName, Frame row)
    {
        var marker = new Marker { utc = DateTime.UtcNow.ToString("o"), phase = phaseName, engineFrame = row.engineFrame,
            sourceIndex = row.index, realtime = row.sourceSeconds, elapsedSeconds = run.windowStartSeconds < 0 ? 0 : row.sourceSeconds - run.windowStartSeconds,
            activeSkin = row.actor.skinnedDeformation && row.actor.deformationRunning && row.actor.sourceIsSkin, actor = row.actor };
        File.WriteAllText(Path.Combine(directory, filename), JsonUtility.ToJson(marker, true));
    }
    void CloseWindow(Frame last)
    {
        if (run.sourceEnd >= 0 || run.sourceStart < 0) return;
        run.sourceEnd = last.engineFrame; run.windowEndSeconds = last.sourceSeconds; run.windowDuration = last.sourceSeconds - run.windowStartSeconds;
        run.windowComplete = run.windowDuration >= WindowSeconds;
        endLedger = sample.CaptureLedger(); run.memoryWindow = endLedger.processVideoMemory; run.memoryWindowCaptured = true;
        sample.MeasureVideoMemory = false;
        WriteMarker("window-end.json", run.windowComplete ? "end" : "failed-partial-end", last);
    }
    void Update()
    {
        if (finished || finishing) return;
        if (finishRequested) { BeginFinish(); return; }
        try {
            if (activateNextUpdate) {
                activateNextUpdate = false;
                run.skinActivatedEngineFrame = Time.frameCount; run.skinActivatedSeconds = Time.realtimeSinceStartupAsDouble;
                interaction.SetSkinnedDeformation(true); interaction.SetDeformationRunning(true);
                Require(interaction.SkinnedDeformation && interaction.DeformationRunning && !interaction.DoorMoving, "Ordinary K+Space activation failed.");
                if (!deformation) deformation = Field(interaction, "deformation") as HybridLumenGIDeformedMesh;
                if (!actorProxy) actorProxy = Field(interaction, "deformationProxy") as HybridLumenGIProxy;
                var skinSource = actorProxy ? actorProxy.SourceRenderer as SkinnedMeshRenderer : null;
                Require(deformation && skinSource && skinSource.sharedMesh, "Actual Skin configuration unavailable.");
                run.sdfResolution = deformation.sdfResolution; run.updateIntervalFrames = deformation.updateIntervalFrames;
                run.sourceBones = skinSource.bones.Length; run.sourceVertices = skinSource.sharedMesh.vertexCount;
                for (int sub = 0; sub < skinSource.sharedMesh.subMeshCount; sub++)
                    run.sourceTriangles += checked((int)skinSource.sharedMesh.GetIndexCount(sub) / 3);
                run.vertexBudgetPerFrame = HybridLumenGIDeformedMesh.VertexBudgetPerFrame; run.maximumWorkers = HybridLumenGIDeformedMesh.MaximumWorkers;
                run.deformationMemoryBudgetBytes = HybridLumenGIDeformedMesh.MemoryBudgetBytes;
                run.deformationUploadBudgetBytesPerFrame = HybridLumenGIDeformedMesh.UploadBudgetBytesPerFrame;
                run.captureBudgetMillisecondsPerFrame = HybridLumenGIDeformedMesh.CaptureBudgetMillisecondsPerFrame;
                phase = 1;
            }
            if (lastEngine < 0 && (Time.frameCount - startupFrame > 120 || Time.realtimeSinceStartupAsDouble - startupSeconds > 300))
                throw new TimeoutException("Ordinary camera produced no first source callback.");
            // Preserve gaps in the source sequence rather than creating a shorter,
            // surviving-source window. Qualification below records incomplete coverage.
            if (frames.Count > 0 && Time.realtimeSinceStartupAsDouble - frames[frames.Count - 1].sourceSeconds > 300)
                throw new TimeoutException("Target camera stopped producing source callbacks.");
        } catch (Exception e) { Fail(e.ToString()); }
    }
    void Log(string text, string stack, LogType type)
    { if (!finished && (type == LogType.Error || type == LogType.Assert || type == LogType.Exception)) Fail("Unity " + type + ": " + text); }
    void Fail(string message) { if (failure == null) failure = message; finishRequested = true; }
    void BeginFinish()
    {
        if (finishing || finished) return;
        finishing = true;
        try {
            ExportCompleted();
            if (run.sourceStart >= 0 && run.sourceEnd < 0 && frames.Count > 0) CloseWindow(frames[frames.Count - 1]);
            if (sample) sample.MeasureVideoMemory = false;
            if (interaction) interaction.SetDeformationRunning(false);
        } catch (Exception e) { if (failure == null) failure = e.ToString(); }
        // Finish after the32nd drain source and ordinary end-of-frame restoration.
        // The optional screenshot module is absent; no replacement capture is added.
        StartCoroutine(FinishAfterFrame());
    }
    IEnumerator FinishAfterFrame()
    {
        yield return new WaitForEndOfFrame();
        Finish();
    }
    static bool Match(Frame f, Sample s) => f.stateAvailable && f.native && f.tokenValid && f.tokenEngineFrame == f.engineFrame &&
        s.sourceFrame == f.engineFrame && s.token == f.token && s.owner == f.owner && s.generation == f.generation &&
        s.epoch == f.epoch && s.deviceEpoch == f.deviceEpoch && s.frequency > 0 && s.readFrame >= s.sourceFrame &&
        s.begin0 <= s.end0 && s.end0 <= s.begin1 && s.begin1 <= s.end1 && s.end1 <= s.begin2 && s.begin2 <= s.end2;
    void QualifyRecordedWindow()
    {
        var byEngine = new Dictionary<int, Frame>(); var seen = new HashSet<int>();
        var bad = new List<int>(); var missing = new List<int>();
        foreach (var f in frames) if (f.stage == 2) byEngine[f.engineFrame] = f;
        foreach (var s in completions) if (s.sourceFrame >= run.sourceStart && s.sourceFrame <= run.sourceEnd && run.sourceStart >= 0) {
            if (!byEngine.TryGetValue(s.sourceFrame, out var f) || !Match(f, s) || !seen.Add(s.sourceFrame)) bad.Add(s.sourceFrame);
        }
        foreach (var f in byEngine.Values) if (!seen.Contains(f.engineFrame)) missing.Add(f.engineFrame);
        run.windowCompletions = seen.Count; run.missingNativeSourceFrames = missing.ToArray(); run.unmatchedOrDuplicateCompletionFrames = bad.ToArray();
        run.timingQualified = run.windowComplete && byEngine.Count == run.windowSources && run.windowSources == run.sourceEnd - run.sourceStart + 1 &&
            missing.Count == 0 && bad.Count == 0;
        run.timingQualification = run.timingQualified ? "Every window source has one identity-matched complete three-scope sample; no readiness/backend filtering" :
            "Incomplete or mismatched source/scope coverage; no zero filling or surviving-source percentiles";
        var m = run.memoryWindow;
        run.memoryQualified = run.windowComplete && run.memoryWindowCaptured && m.valid && m.hasSamples && m.windowFirstFrame == run.sourceStart &&
            m.sampleFrame == run.sourceEnd && m.attemptFrame == run.sourceEnd && m.samples == run.windowSources && m.failedSamples == 0;
        foreach (var f in byEngine.Values) run.memoryQualified &= f.memory.valid && f.memory.hasSamples &&
            f.memory.attemptFrame == f.engineFrame && f.memory.sampleFrame == f.engineFrame && f.memory.windowFirstFrame == run.sourceStart &&
            f.memory.samples == f.engineFrame - run.sourceStart + 1 && f.memory.failedSamples == 0 &&
            f.memory.deviceEpoch == m.deviceEpoch && f.memory.adapterLuid == m.adapterLuid;
        run.memoryQualification = run.memoryQualified ? "One actual process-memory sample per window engine frame, same device/window" :
            "Process-memory window incomplete/invalid; logical byte estimates are not a substitute";
        run.distinctWindowCapturedFrames = windowCaptures.Count;
        run.workloadQualified = run.windowComplete && run.windowBendChanges > 0 && windowCaptures.Count >= 2;
        if (!run.workloadQualified && failure == null) failure = "Window/load insufficient: require the full35 seconds, actual bend changes and multiple distinct captured snapshots observed in the window.";
    }
    void Finish()
    {
        if (finished) return; finished = true;
        if (subscribed) { RenderPipelineManager.endCameraRendering -= Rendered; Application.logMessageReceived -= Log; subscribed = false; }
        try {
            ExportCompleted(); QualifyRecordedWindow();
            run.providers = new Provider[timings.Count];
            for (int i = 0; i < timings.Count; i++) { var t = timings[i]; run.providers[i] = new Provider { index = i, status = t.Status.ToString(),
                pending = t.PendingCount, buffered = t.BufferedCompletedRecords, completed = t.CompletedResults, exported = t.ExportedResults,
                unexported = t.UnexportedResults, invalid = t.InvalidCompletedResults, cancelled = t.CancelledSubmissions, timedOut = t.TimedOutSubmissions }; }
        } catch (Exception e) { if (failure == null) failure = e.ToString(); }
        run.status = failure == null ? "collected" : "failed"; run.error = failure ?? "";
        run.unity = Application.unityVersion; run.gpu = SystemInfo.graphicsDeviceName; run.api = SystemInfo.graphicsDeviceType.ToString();
        run.driver = SystemInfo.graphicsDeviceVersion; run.scene = sample ? sample.gameObject.scene.path : ExpectedScene; run.outputDirectory = directory;
        run.frames = frames.Count; run.completions = completions.Count; run.drainFrames = drainCount;
        run.firstEngineFrame = frames.Count == 0 ? -1 : frames[0].engineFrame;
        run.vSyncCount = QualitySettings.vSyncCount; run.targetFrameRate = Application.targetFrameRate;
        try {
            if (directory != null) {
                File.WriteAllText(Path.Combine(directory, "settings-before.json"), settingsBefore ?? "null");
                File.WriteAllText(Path.Combine(directory, "settings-measure.json"), settingsMeasure ?? "null");
                if (startLedger != null) File.WriteAllText(Path.Combine(directory, "start-ledger.json"), JsonUtility.ToJson(startLedger, true));
                if (endLedger != null) File.WriteAllText(Path.Combine(directory, "end-ledger.json"), JsonUtility.ToJson(endLedger, true));
                using (var w = new StreamWriter(Path.Combine(directory, "frames.jsonl"))) foreach (var f in frames) w.WriteLine(JsonUtility.ToJson(f));
                using (var w = new StreamWriter(Path.Combine(directory, "completions.jsonl"))) foreach (var s in completions) w.WriteLine(JsonUtility.ToJson(s));
                File.WriteAllText(Path.Combine(directory, "run.json"), JsonUtility.ToJson(run, true));
            }
            Debug.Log("SKIN_COST135_" + run.status + " frames=" + frames.Count + " window=" + run.windowSources + " completeScopes=" + run.windowCompletions + " " + run.error);
        } catch (Exception e) { failure = failure ?? e.ToString(); Debug.LogError("SKIN_COST135_WRITE_FAILED " + e); }
        // Remaining pending native submissions are reported, never declared completed or disposed by this observer.
        // Normal product shutdown owns the still-live Skin and all resources.
        Application.Quit(failure == null ? 0 : 1);
    }
    void OnDisable() { if (!finished) Fail("Observer disabled before completion."); }
    void OnDestroy()
    { if (subscribed) { RenderPipelineManager.endCameraRendering -= Rendered; Application.logMessageReceived -= Log; subscribed = false; } }
}
