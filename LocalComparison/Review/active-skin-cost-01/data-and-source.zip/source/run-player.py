"""One drawable ordinary Player and existing same-run PresentMon; no restart/kill."""
import datetime,json,subprocess,time
from pathlib import Path

base=Path('I:/Unity test/Comparison');area=base/'SkinCost135Corrected';setup=area/'setup'
build=base/'Builds/SkinCost135Corrected';run=area/'run'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2);f.write('\n')
report=load(build/'build-result.json');native=load(setup/'build-exit.json')
scene='Assets/HLGINeutral106/Variant/NeutralThreeRooms.unity'
if not(native['exitCode']==0 and report['status']=='Succeeded' and report['errors']==0 and report['configuration']=='Release' and
       report['actualOptions']=='None' and report['target']=='StandaloneWindows64' and report['scenes']==[scene]):
    raise RuntimeError('Only the successful ordinary same-scene corrected build may run')
exe=build/'HybridLumenGIPlayer.exe';dll=build/'HybridLumenGIPlayer_Data/Plugins/x86_64/HybridLumenGIGpuTiming.dll'
for p in [exe,dll,build/'HybridLumenGIPlayer_Data/StreamingAssets/UnifiedNeutral106/UnifiedNeutral106']:
    if not p.is_file() or p.stat().st_size==0:raise FileNotFoundError(p)
for p in [run,area/'player.log',setup/'player-attempt.json',setup/'native-exit.json',area/'present.csv',area/'presentmon.log',setup/'present-attempt.json']:
    if p.exists():raise FileExistsError(p)
command=[str(exe),'-force-d3d12','-screen-fullscreen','0','-screen-width','960','-screen-height','540',
         '-hlgiActiveSkinCost','-skinCostOutput',str(run),'-logFile',str(area/'player.log')]
startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=4
started=now();player=subprocess.Popen(command,cwd=build,startupinfo=startup)
save(setup/'player-attempt.json',{'startedUtc':started,'pid':player.pid,'command':command,'scope':'One ordinary drawable instrumented activeSkin window; no batchmode/nographics','sourceProduct':native['product']})
print(f'SkinCost135 Player PID {player.pid}; log {area / "player.log"}',flush=True)
waiting=time.monotonic();checkpoint=False;marker=None
while player.poll() is None:
    if (run/'window-start.json').exists():
        try:marker=load(run/'window-start.json');break
        except json.JSONDecodeError:pass  # Same live writer, not a new attempt.
    if not checkpoint and time.monotonic()-waiting>=300:
        checkpoint=True;save(setup/'awaiting-window-checkpoint.json',{'time':now(),'pid':player.pid,'alive':player.poll() is None,'action':'Keep waiting on this same process; no restart or termination'})
        print(f'Player {player.pid} is still live; window has not started, continuing same handle.',flush=True)
    time.sleep(.1)
present={'status':'not-started','reason':'Player ended before the active window marker'}
if marker is not None:
    monitor=Path('I:/Unity test/Tools/PresentMon-2.6.0/PresentMon-2.6.0-x64.exe')
    if not(marker.get('phase')=='start' and marker.get('activeSkin') and marker.get('plannedSeconds')==35):
        present={'status':'not-started','reason':'Active window marker does not match the frozen workload'}
    elif not monitor.is_file():
        present={'status':'unavailable','reason':'Existing PresentMon is unavailable; no replacement or retry'}
    else:
        pm_command=[str(monitor),'--process_id',str(player.pid),'--output_file',str(area/'present.csv'),'--session_name','HLGI-Skin135',
                    '--timed','30','--terminate_after_timed','--no_console_stats','--no_track_display','--no_track_input','--no_track_gpu','--v1_metrics']
        present={'status':'running','startedUtc':now(),'command':pm_command,'playerPid':player.pid,'sourceMarker':marker}
        try:
            with (area/'presentmon.log').open('xb') as log:
                monitor_process=subprocess.Popen(pm_command,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
                present['monitorPid']=monitor_process.pid
                print(f'Active Skin window started; PresentMon PID {monitor_process.pid} captures once for30 seconds.',flush=True)
                code=monitor_process.wait()
            present.update(status='completed' if code==0 else 'failed',exitCode=code,finishedUtc=now())
        except OSError as e:present.update(status='unavailable',reason=str(e),finishedUtc=now())
save(setup/'present-attempt.json',present)
exit_code=player.wait()
save(setup/'native-exit.json',{'endedUtc':now(),'exitCode':exit_code,'processId':player.pid,'sourceProduct':native['product'],
                             'output':str(run),'watchdogTerminated':False,'scope':'One normal process exit; no kill/restart'})
print(f'SkinCost135 Player exit={exit_code}; Present={present["status"]}. Raw output {run}',flush=True)
raise SystemExit(exit_code)
