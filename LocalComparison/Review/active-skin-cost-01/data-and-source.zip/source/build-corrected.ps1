$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
$base=[IO.Path]::GetFullPath('I:/Unity test/Comparison')
$project=[IO.Path]::GetFullPath("$base/PortableUnified122/HybridLumenGI-Release122-UnityProject")
$scene='Assets/HLGINeutral106/Variant/NeutralThreeRooms.unity'
$area="$base/SkinCost135Corrected";$setup="$area/setup"
$build="$base/Builds/SkinCost135Corrected"
$owned="$project/Assets/HLGISkinCost135"
$lastScene="$project/Library/LastSceneManagerSetup.txt"
$quality="$project/ProjectSettings/QualitySettings.asset"
function Idle{if(Get-Process Unity,HybridLumenGIPlayer -ErrorAction SilentlyContinue){throw 'A live Unity/Player owns the current slot; preserve resources.'}}
Idle
foreach($p in @($area,$build,$owned,"$owned.meta",'I:/Unity test/Logs/SkinCost135CorrectedBuild.log','I:/Unity test/Logs/SkinCost135CorrectedBuild-upm.log')){
    if(Test-Path -LiteralPath $p){throw "Preserve existing path: $p"}
}
foreach($p in @("$PSScriptRoot/SkinCost135.cs","$project/$scene","$project/Assets/Plugins/x86_64/HybridLumenGIGpuTiming.dll",
    "$project/Assets/StreamingAssets/UnifiedNeutral106/UnifiedNeutral106")){
    if(!(Test-Path -LiteralPath $p -PathType Leaf)){throw "Missing released input/observer: $p"}
}
foreach($name in @('HybridLumenGIRendererFeature.cs','HybridLumenGIDeformedMesh.cs','HybridLumenGIUnifiedSampleInteraction.cs')){
    $expected=[IO.File]::ReadAllText("$repo/Runtime/$name").Replace([string][char]13,'')
    $actual=[IO.File]::ReadAllText("$project/Assets/HybridLumenGI/Runtime/$name").Replace([string][char]13,'')
    if($expected -cne $actual){throw "Installed implementation differs: $name"}
}
New-Item -ItemType Directory -Path $setup | Out-Null
$hadScene=Test-Path -LiteralPath $lastScene -PathType Leaf
if($hadScene){Copy-Item -LiteralPath $lastScene -Destination $setup}
Copy-Item -LiteralPath $quality -Destination $setup
Copy-Item -LiteralPath "$PSScriptRoot/contract.md" -Destination $setup
$created=$false
try{
    Idle
    New-Item -ItemType Directory -Path $owned | Out-Null;$created=$true
    Copy-Item -LiteralPath "$PSScriptRoot/SkinCost135.cs" -Destination $owned
    @{product='7c08327f6fd6758dc5cdda563ec10e42e26b50bb';project=$project;scene=$scene;build=$build;
        source='Same-source Release122 project plus explicit-flag temporary observer; no product edits';mode='Existing K+Space Skinned'} |
        ConvertTo-Json | Set-Content -LiteralPath "$setup/build-attempt.json" -Encoding utf8
    & 'I:/Unity test/Start-Unity.ps1' -Batch -ProjectPath $project -LogName SkinCost135CorrectedBuild `
        -ExecuteMethod HybridLumenGI.Editor.HybridLumenGIPlayerBuild.Build `
        -ExtraArguments @('-nographics','-buildTarget','StandaloneWindows64','-hlgiScene',$scene,'-hlgiOutput',$build)
    $code=$LASTEXITCODE
    @{exitCode=$code;product='7c08327f6fd6758dc5cdda563ec10e42e26b50bb';project=$project;scene=$scene;output=$build} |
        ConvertTo-Json | Set-Content -LiteralPath "$setup/build-exit.json" -Encoding utf8
    if($code -ne 0){throw "The sole build exited $code; preserve the first failure."}
    $report=Get-Content -LiteralPath "$build/build-result.json" -Raw|ConvertFrom-Json
    if($report.status -ne 'Succeeded' -or $report.errors -ne 0 -or $report.actualOptions -ne 'None'){
        throw 'Ordinary measurement build incomplete; do not launch.'
    }
    $report|Select-Object status,errors,warnings,configuration,actualOptions
}finally{
    Idle
    Copy-Item -LiteralPath "$setup/QualitySettings.asset" -Destination $quality -Force
    if($hadScene){Copy-Item -LiteralPath "$setup/LastSceneManagerSetup.txt" -Destination $lastScene -Force}
    elseif(Test-Path -LiteralPath $lastScene){Move-Item -LiteralPath $lastScene -Destination "$setup/generated-scene-setup.txt"}
    if($created){
        $source=Get-Item -LiteralPath $owned;$destination=[IO.Path]::GetFullPath("$setup/observer")
        if($source.FullName -ine [IO.Path]::GetFullPath("$project/Assets/HLGISkinCost135") -or
            [IO.Path]::GetDirectoryName($destination) -ine [IO.Path]::GetFullPath($setup) -or
            $source.Attributes.HasFlag([IO.FileAttributes]::ReparsePoint) -or
            (Get-ChildItem -LiteralPath $source.FullName -Recurse -Force -Attributes ReparsePoint | Select-Object -First 1) -or
            (Test-Path -LiteralPath $destination) -or (Test-Path -LiteralPath "$destination.meta")){
            throw 'Unexpected owned/archive path; preserve staged files.'
        }
        Move-Item -LiteralPath $source.FullName -Destination $destination
        if(Test-Path -LiteralPath "$owned.meta"){Move-Item -LiteralPath "$owned.meta" -Destination "$destination.meta"}
    }
}
