"""Deliver the existing single run; no GPU work, new observation or hash sweep."""
import shutil, zipfile
from pathlib import Path

repo = Path(__file__).resolve().parents[2]
temp = repo / 'Temp/SkinCost135'
area = Path('I:/Unity test/Comparison/SkinCost135Corrected')
failed = Path('I:/Unity test/Comparison/SkinCost135')
target = repo / 'LocalComparison/Review/active-skin-cost-01'
target.mkdir(parents=True, exist_ok=True)
for name, source in [('result.json', temp/'Analysis/result.json'),
                     ('contract.md', temp/'contract.md'), ('analyze.py', temp/'analyze.py')]:
    shutil.copyfile(source, target/name)

readme = '''SkinCost135: one ordinary Release-None Player, current Release122 Runtime.

Offline recalculation (Python3, standard library only; no Unity/GPU/profiler):
  python analyze.py raw fresh-output
The output directory must not exist.

raw/ contains the sole corrected Player's original run, source clocks, native
completion tickets, finite process-memory samples, PresentMon CSV, and process
receipts. Every source in the fixed35-second window participates. The30-second
Present invocation lies inside it; it is not per-source GI/Present pairing.
The reused native-analysis.py supplies only parsing and percentile helpers.

source/ preserves the observer, build/run entries and the original contract
with its explicit correction addendum. failed-build/ retains the FIRST source,
contract and CS0103 ScreenCapture compilation failure. It never ran a Player.
The one correction removed the optional unsupported screenshot call; no image
was delivered and no visual quality judgment is made. It did not add modules
or change the physical workload/budgets. There was one actual Player run.

The warm measured scope is the original default24-vertex/12-triangle/2-bone
K+Space Skin workload, with observation enabled. It is not a larger-model,
observation-off, cold-start, image-quality or fullG3/G4/G5 acceptance result.
CPU snapshot age is capture frame to first CPU observation for each NEW
snapshot, not all rendered-frame ages, exact publication time, BakeMesh CPU
milliseconds or GPU geometry-consumption latency. Initial first-camera wait
and remaining provider pending are retained without cause/complete-drain claims.
The public Release122 Runtime and example sources were not changed.
'''
with zipfile.ZipFile(target/'data-and-source.zip', 'x', zipfile.ZIP_DEFLATED) as z:
    z.writestr('README.txt', readme)
    z.write(temp/'analyze.py', 'analyze.py')
    z.write(repo/'LocalComparison/Review/release83-dxr-cost-01/native-analysis.py', 'native-analysis.py')
    z.write(temp/'Analysis/result.json', 'record/adopted-result.json')
    for f in area.rglob('*'):
        if f.is_file(): z.write(f, 'raw/'+f.relative_to(area).as_posix())
    for f in failed.rglob('*'):
        if f.is_file(): z.write(f, 'failed-build/'+f.relative_to(failed).as_posix())
    for name in ['SkinCost135.cs', 'contract.md', 'build.ps1', 'build-corrected.ps1', 'run-player.py', 'package.py']:
        z.write(temp/name, 'source/'+name)
    for name in ['SkinCost135Build.log', 'SkinCost135CorrectedBuild.log']:
        z.write(Path('I:/Unity test/Logs')/name, 'record/'+name)
    z.write(Path('I:/Unity test/Comparison/Builds/SkinCost135Corrected/build-result.json'), 'record/build-result.json')
print(target)
