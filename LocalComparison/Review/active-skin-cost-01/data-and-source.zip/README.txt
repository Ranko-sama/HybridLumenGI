SkinCost135: one ordinary Release-None Player, current Release122 Runtime.

Offline recalculation (Python3, standard library only; no Unity/GPU/profiler):
  python analyze.py raw fresh-output
The output directory must not exist.

raw/ contains the sole corrected Player's original run, source clocks, native
completion tickets, finite process-memory samples, PresentMon CSV, and process
receipts. Every source in the fixed35-second window participates. The30-second
Present invocation lies inside it; it is not per-source GI/Present pairing.
The reused native-analysis.py supplies only parsing and percentile helpers.

source/ preserves the observer, build/run entries and the original contract
with its explicit correction addendum. failed-build/ retains the FIRST source,
contract and CS0103 ScreenCapture compilation failure. It never ran a Player.
The one correction removed the optional unsupported screenshot call; no image
was delivered and no visual quality judgment is made. It did not add modules
or change the physical workload/budgets. There was one actual Player run.

The warm measured scope is the original default24-vertex/12-triangle/2-bone
K+Space Skin workload, with observation enabled. It is not a larger-model,
observation-off, cold-start, image-quality or fullG3/G4/G5 acceptance result.
CPU snapshot age is capture frame to first CPU observation for each NEW
snapshot, not all rendered-frame ages, exact publication time, BakeMesh CPU
milliseconds or GPU geometry-consumption latency. Initial first-camera wait
and remaining provider pending are retained without cause/complete-drain claims.
The public Release122 Runtime and example sources were not changed.
