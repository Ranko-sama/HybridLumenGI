Resize136: intended unchanged-GI resize contract NOT qualified.

The actual same-RT-reference full resize was1918x1078 ->1919x1079.
The original budget-constrained GI changed820x460 ->819x460, rather than
remaining959x539 as incorrectly assumed before execution. No budget/profile
change, retry or alternative pass threshold was used. The unchanged-GI case
remains insufficient. Actual first/second post-event ages may only describe
this JOINT full+GI resize; they cannot be attributed to full-size recognition.

Offline analysis (Python3+numpy, no Unity/GPU or new observations):
  python analyze.py raw fresh-output
The output directory must not exist. The parser retains intended-case failure
and separately reports existing actual dimensions/age distributions. Its first
result, which stopped on959x539 mismatch, is inrecord/analysis-initial.json.

raw/run/signals contains only the three predeclared95/96/97 requests and their
selected filteredD/geometry/moments/material planes. Other support and ordinary
HDR were deliberately not exported. Filtered validity is not fresh raw proof;
zero-age pixels remain unknown. raw/ also contains source/event clocks, live
reference records, normal native exit and restoration receipts. Original720
protocol is a failed105-source prefix, not a full sequence pass.

source/ andobserver/ preserve the final pre-execution adapter/contract. The
observation-only plane selector reuses134 and keeps original Reserve/ownership/
readback completion. No Runtime transport/temporal computation was changed.
The existing original physical inputs are reused from the archived119/134
deliveries; no duplicate source assets, new reference or project rebuild here.
No fullG3/edge coverage/Player/performance or production release claim.
