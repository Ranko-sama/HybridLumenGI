$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
$project=[IO.Path]::GetFullPath('I:/Unity test/Project')
$runtime="$project/Assets/HybridLumenGI/Runtime"
$comparison=[IO.Path]::GetFullPath('I:/Unity test/Comparison')
$original="$project/Assets/ValidationPackageV201"
$observer="$project/Assets/HLGIResizeHistory136"
$archive="$comparison/ValidationPackageV209/project-archive/Assets/ValidationPackageV201"
$parent="$comparison/ResizeHistory136";$setup="$parent/setup";$output="$parent/run"
$quality="$project/ProjectSettings/QualitySettings.asset"
$lastScene="$project/Library/LastSceneManagerSetup.txt"
$map="$comparison/ArchivedColor133Setup/used-original/import-map.json"
$python='C:/Users/Administrator/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
$names=@('HybridLumenGIValidationSequence.cs','HybridLumenGIValidationCapture.cs')
function Idle { if(Get-Process Unity,HybridLumenGIPlayer -ErrorAction SilentlyContinue){throw 'Live Unity/Player owns resources; preserve and wait.'} }
function Fresh([string]$p){if(Test-Path -LiteralPath $p){throw "Preserve existing input/output: $p"}}
function Text([string]$p){[IO.File]::ReadAllText($p).Replace([string][char]13,'')}
Idle
foreach($p in @($parent,$original,"$original.meta",$observer,"$observer.meta",'I:/Unity test/Logs/ResizeHistory136.log','I:/Unity test/Logs/ResizeHistory136-upm.log')){Fresh $p}
foreach($p in @($map,"$PSScriptRoot/ResizeHistory136Editor.cs","$PSScriptRoot/ResizeHistory136Host.cs")){if(!(Test-Path -LiteralPath $p -PathType Leaf)){throw "Required adapter/input missing: $p"}}
foreach($file in @($names+'HybridLumenGIRendererFeature.cs')){
    if((Text "$runtime/$file") -cne (Text "$repo/Runtime/$file")){throw "Installed implementation differs: $file"}
}
$hadScene=Test-Path -LiteralPath $lastScene -PathType Leaf
New-Item -ItemType Directory -Path "$setup/original" | Out-Null
Copy-Item -LiteralPath $quality -Destination "$setup/original"
if($hadScene){Copy-Item -LiteralPath $lastScene -Destination "$setup/original"}
foreach($name in $names){Copy-Item -LiteralPath "$runtime/$name" -Destination "$setup/original"}
Copy-Item -LiteralPath "$PSScriptRoot/contract.md" -Destination $setup
& $python "$PSScriptRoot/prepare.py" $runtime "$setup/prepared"
if($LASTEXITCODE -ne 0){throw 'Existing observer anchor no longer applies; nothing installed.'}
$createdOriginal=$false;$createdObserver=$false
try {
    New-Item -ItemType Directory -Path $original | Out-Null;$createdOriginal=$true
    Copy-Item -LiteralPath "$archive/Generated","$archive/Generated.meta","$archive/ValidationPackageV2Host.cs","$archive/ValidationPackageV2Host.cs.meta" -Destination $original -Recurse
    Copy-Item -LiteralPath $map -Destination "$original/import-map.json"
    New-Item -ItemType Directory -Path "$observer/Editor" -Force | Out-Null;$createdObserver=$true
    Copy-Item -LiteralPath "$PSScriptRoot/ResizeHistory136Editor.cs" -Destination "$observer/Editor"
    Copy-Item -LiteralPath "$PSScriptRoot/ResizeHistory136Host.cs" -Destination $observer
    foreach($name in $names){Copy-Item -LiteralPath "$setup/prepared/$name" -Destination "$runtime/$name" -Force}
    & 'I:/Unity test/Start-Unity.ps1' -Batch -KeepRunning -ProjectPath $project -LogName ResizeHistory136 -ExecuteMethod ResizeHistory136Editor.Run -ExtraArguments @('-resizeHistoryOutput',$output)
    $code=$LASTEXITCODE
    @{exitCode=$code;sourceProduct='7c08327f6fd6758dc5cdda563ec10e42e26b50bb';sourceArchive=$archive;output=$output} | ConvertTo-Json | Set-Content -LiteralPath "$setup/native-exit.json" -Encoding utf8
    if($code -ne 0){throw "Observation exited $code; preserve first failure, no retry."}
    $r=Get-Content -LiteralPath "$output/result.json" -Raw | ConvertFrom-Json
    if($r.status -ne 'collected' -or !$r.restored){throw 'Incomplete observation; preserve results.'}
    [pscustomobject]@{status=$r.status;restored=$r.restored}
} finally {
    Idle
    foreach($name in $names){
        $present=Text "$runtime/$name"
        if($present -cne (Text "$setup/prepared/$name") -and $present -cne (Text "$setup/original/$name")){throw 'Unexpected observer edit; preserve backups.'}
        Copy-Item -LiteralPath "$setup/original/$name" -Destination "$runtime/$name" -Force
    }
    Copy-Item -LiteralPath "$setup/original/QualitySettings.asset" -Destination $quality -Force
    if($hadScene){Copy-Item -LiteralPath "$setup/original/LastSceneManagerSetup.txt" -Destination $lastScene -Force}
    elseif(Test-Path -LiteralPath $lastScene){Move-Item -LiteralPath $lastScene -Destination "$setup/generated-scene-setup.txt"}
    foreach($item in @(@{path=$original;created=$createdOriginal;name='archived-input'},@{path=$observer;created=$createdObserver;name='observer'})){
        if(!$item.created){continue}
        $source=Get-Item -LiteralPath $item.path;$destination=[IO.Path]::GetFullPath((Join-Path $setup $item.name))
        if($source.FullName -ine [IO.Path]::GetFullPath($item.path) -or [IO.Path]::GetDirectoryName($source.FullName) -ine [IO.Path]::GetFullPath("$project/Assets") -or
            [IO.Path]::GetDirectoryName($destination) -ine [IO.Path]::GetFullPath($setup) -or $source.Attributes.HasFlag([IO.FileAttributes]::ReparsePoint) -or
            (Get-ChildItem -LiteralPath $source.FullName -Recurse -Force -Attributes ReparsePoint | Select-Object -First 1) -or
            (Test-Path -LiteralPath $destination) -or (Test-Path -LiteralPath "$destination.meta")){throw 'Unexpected archive path; preserve resources.'}
        Move-Item -LiteralPath $source.FullName -Destination $destination
        if(Test-Path -LiteralPath "$($item.path).meta"){Move-Item -LiteralPath "$($item.path).meta" -Destination "$destination.meta"}
    }
}
