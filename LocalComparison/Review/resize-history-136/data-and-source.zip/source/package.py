"""Preserve the sole run and the unmet intended contract; do not repeat it."""
import shutil,zipfile,json
from pathlib import Path
repo=Path(__file__).resolve().parents[2];temp=repo/'Temp/ResizeHistory136'
area=Path('I:/Unity test/Comparison/ResizeHistory136')
target=repo/'LocalComparison/Review/resize-history-136';target.mkdir(parents=True,exist_ok=True)
for name,source in [('result.json',temp/'AnalysisActual/result.json'),('contract.md',temp/'contract.md'),('analyze.py',temp/'analyze.py')]:shutil.copyfile(source,target/name)
readme='''Resize136: intended unchanged-GI resize contract NOT qualified.

The actual same-RT-reference full resize was1918x1078 ->1919x1079.
The original budget-constrained GI changed820x460 ->819x460, rather than
remaining959x539 as incorrectly assumed before execution. No budget/profile
change, retry or alternative pass threshold was used. The unchanged-GI case
remains insufficient. Actual first/second post-event ages may only describe
this JOINT full+GI resize; they cannot be attributed to full-size recognition.

Offline analysis (Python3+numpy, no Unity/GPU or new observations):
  python analyze.py raw fresh-output
The output directory must not exist. The parser retains intended-case failure
and separately reports existing actual dimensions/age distributions. Its first
result, which stopped on959x539 mismatch, is inrecord/analysis-initial.json.

raw/run/signals contains only the three predeclared95/96/97 requests and their
selected filteredD/geometry/moments/material planes. Other support and ordinary
HDR were deliberately not exported. Filtered validity is not fresh raw proof;
zero-age pixels remain unknown. raw/ also contains source/event clocks, live
reference records, normal native exit and restoration receipts. Original720
protocol is a failed105-source prefix, not a full sequence pass.

source/ andobserver/ preserve the final pre-execution adapter/contract. The
observation-only plane selector reuses134 and keeps original Reserve/ownership/
readback completion. No Runtime transport/temporal computation was changed.
The existing original physical inputs are reused from the archived119/134
deliveries; no duplicate source assets, new reference or project rebuild here.
No fullG3/edge coverage/Player/performance or production release claim.
'''
with zipfile.ZipFile(target/'data-and-source.zip','x',zipfile.ZIP_DEFLATED) as z:
    z.writestr('README.txt',readme);z.write(temp/'analyze.py','analyze.py')
    for f in (area/'run').rglob('*'):
        if f.is_file():z.write(f,'raw/run/'+f.relative_to(area/'run').as_posix())
    h=json.loads((area/'run/host-result.json').read_text())
    z.write(Path(h['runFile']),'raw/run/legacy/run.json');z.write(Path(h['framesFile']),'raw/run/legacy/frames.jsonl')
    z.write(area/'setup/native-exit.json','raw/setup/native-exit.json')
    for d in ['original','prepared','observer']:
        for f in (area/'setup'/d).rglob('*'):
            if f.is_file():z.write(f,'observer/'+d+'/'+f.relative_to(area/'setup'/d).as_posix())
    z.write(area/'setup/archived-input/import-map.json','record/import-map.json')
    z.write(Path('I:/Unity test/Logs/ResizeHistory136.log'),'record/unity.log')
    z.write(temp/'Analysis/result.json','record/analysis-initial.json')
    for name in ['ResizeHistory136Host.cs','ResizeHistory136Editor.cs','prepare.py','run.ps1','contract.md','package.py']:z.write(temp/name,'source/'+name)
print(target)
