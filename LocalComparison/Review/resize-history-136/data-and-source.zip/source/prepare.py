"""Reuse the existing archived-scene Editor adapter; one export-only Sequence patch."""
import argparse
from pathlib import Path

def once(s, old, new):
    if s.count(old) != 1: raise ValueError('Expected one adapter anchor: '+old[:90])
    return s.replace(old, new)

def editor(here):
    s = (here.parent/'ReflectedColor134/ReflectedColor134Editor.cs').read_text(encoding='utf-8-sig')
    s = s.replace('ReflectedColor134', 'ResizeHistory136').replace('-reflectedColorOutput', '-resizeHistoryOutput')
    s = once(s, 'Archived physical assets; fixed door and camera, original five lights; 2ray/filter4/DXR/IndirectOnly; red-to-blue versus blue-from-start',
             'Archived static0..104 scene; same Camera/RT reference; full1918x1078 to1919x1079 at95 return; unchanged halfGI/2ray/filter4/DXR')
    start = '        string lane = Arg("-reflectedColorLane");'
    end = '        Need(!File.Exists(WorkingScene), "Preserve existing temporary scene.");'
    if s.count(start) != 1 or s.count(end) != 1: raise ValueError('Existing Editor CLI section differs')
    s = s[:s.index(start)] + s[s.index(end):]
    s = once(s, 'edit.FindProperty("width").intValue = 640; edit.FindProperty("height").intValue = 360;',
             'edit.FindProperty("width").intValue = 1918; edit.FindProperty("height").intValue = 1078;')
    s = once(s, '"reflected-color-134"', '"resize-history-136"')
    s = once(s, 'host.outputDirectory = output; host.lane = lane; host.requestedFinalLogical = finalLogical;',
             'host.outputDirectory = output;')
    target = here/'ResizeHistory136Editor.cs'
    if target.exists(): raise ValueError('Preserve existing Editor adapter')
    target.write_text(s, encoding='utf-8')

if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('runtime', type=Path, nargs='?'); p.add_argument('output', type=Path, nargs='?'); a = p.parse_args()
    if a.runtime is None: editor(Path(__file__).resolve().parent)
    else:
        a.output.mkdir(parents=True, exist_ok=False)
        s = (a.runtime/'HybridLumenGIValidationSequence.cs').read_text(encoding='utf-8-sig')
        s = once(s, 'if (!IsCaptureFrame(logicalFrame, captureEvery)) return;',
                 'if (logicalFrame >= 0) return; // Resize136 observer: no unrelated ordinary HDR export.')
        (a.output/'HybridLumenGIValidationSequence.cs').write_text(s, encoding='utf-8')
        # Reuse134's observation-only plane selection and camera-color dependency.
        cap = (a.runtime/'HybridLumenGIValidationCapture.cs').read_text(encoding='utf-8-sig')
        first='                var planes = new List<Plane>();'
        last='                AddPass(graph, ticket, planes.ToArray(), false);'
        if cap.count(first)!=1 or cap.count(last)!=1: raise ValueError('Existing plane-selection anchors differ')
        i=cap.index(first);j=cap.index(last,i)
        cap=cap[:i]+'''                var planes = new List<Plane>();
                planes.Add(Reserve(graph, ticket, support.filteredD, "filteredD", "before-hlgi-composite-after-filter", true, true, false));
                planes.Add(Reserve(graph, ticket, support.geometry, "geometry", "before-hlgi-composite", false, false, false));
                planes.Add(Reserve(graph, ticket, support.material, "material", "before-hlgi-composite", false, false, true));
                planes.Add(Reserve(graph, ticket, support.moments, "moments", "before-hlgi-composite", false, false, false));
'''+cap[j:]
        cap=once(cap,'AddPass(graph, ticket, planes.ToArray(), false);','AddPass(graph, ticket, planes.ToArray(), false, cameraColor);')
        cap=once(cap,'AddPass(graph, ticket, new[] { Reserve(graph, ticket, cameraColor, "cameraAfterHLGI", "after-hlgi-composite-before-transparents", true, false, true) }, true);',
                 'AddPass(graph, ticket, Array.Empty<Plane>(), true, cameraColor);')
        cap=once(cap,'Plane[] planes, bool after)','Plane[] planes, bool after, TextureHandle cameraColor)')
        cap=once(cap,'data.ticket = ticket; data.planes = planes; data.after = after;',
                 'data.ticket = ticket; data.planes = planes; data.after = after;\n                builder.UseTexture(cameraColor, AccessFlags.Read);')
        (a.output/'HybridLumenGIValidationCapture.cs').write_text(cap,encoding='utf-8')
