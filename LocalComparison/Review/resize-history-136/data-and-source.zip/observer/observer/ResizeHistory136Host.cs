using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using HybridLumenGI;
using UnityEngine;
using UnityEngine.Rendering;

[DefaultExecutionOrder(1000)]
public sealed class ResizeHistory136Host : MonoBehaviour
{
    public HybridLumenGIValidationSequence sequence;
    public Camera targetCamera;
    public HybridLumenGIRendererFeature feature;
    public RenderPipelineAsset expectedPipeline;
    public string outputDirectory;

    const int BeforeWidth = 1918, BeforeHeight = 1078, AfterWidth = 1919, AfterHeight = 1079;
    const int EventAfterLogical = 95, FinalLogical = 104;
    const BindingFlags Private = BindingFlags.Instance | BindingFlags.NonPublic;
    static readonly FieldInfo Logical = typeof(HybridLumenGIValidationSequence).GetField("logicalFrame", Private);
    static readonly FieldInfo Pending = typeof(HybridLumenGIValidationSequence).GetField("pending", Private);
    static readonly FieldInfo Output = typeof(HybridLumenGIValidationSequence).GetField("output", Private);
    static readonly FieldInfo Width = typeof(HybridLumenGIValidationSequence).GetField("width", Private);
    static readonly FieldInfo Height = typeof(HybridLumenGIValidationSequence).GetField("height", Private);
    static readonly FieldInfo Request = typeof(HybridLumenGIValidationSequence).GetField("renderRequest", Private);
    static readonly FieldInfo Settings = typeof(HybridLumenGIRendererFeature).GetField("settings", Private);

    [Serializable] public sealed class LegacyRun
    {
        public string status, lastError, expectedBackend, renderPath;
        public int renderedFrames, failures, backendMismatches, firstEngineFrame, firstRenderedGiFrame, capturesWritten;
        public int width, height;
    }
    [Serializable] sealed class LegacyFrame
    {
        public int logicalFrame, engineFrame, giFrame, width, height;
        public bool diagnosticFresh, lightsEnabled;
        public string reportedBackend;
        public Vector3 cameraPosition, doorLocalPosition;
        public Quaternion cameraRotation;
    }
    [Serializable] public sealed class SourceFrame
    {
        public int logicalFrame, engineFrame, workFrame = -1, giFrame = -1, ticketIndex = -1, ordinaryPendingAtRequest = -1;
        public int cameraId, targetId, outputId, width, height, sequenceWidth, sequenceHeight, cameraPixelWidth, cameraPixelHeight;
        public bool sameCamera, sameTarget, sameOutput, sameRenderRequest, sameRequestDestination, targetCreated, settingsUnchanged, returned;
        public Vector3 cameraPosition, doorLocalPosition;
        public Quaternion cameraRotation;
        public Matrix4x4 cameraProjection, cameraView;
        public bool lightsEnabled;
        public double sourceSeconds, returnedSeconds;
        public HybridLumenGIRendererFeature.CameraDiagnostics diagnostics;
    }
    [Serializable] public sealed class CaptureRecord
    {
        public int logicalFrame, engineFrame, workFrame;
        public string receiptPath, failure;
        public bool complete, succeeded;
        public HybridLumenGIValidationCapture.Receipt receipt;
    }
    [Serializable] public sealed class Series
    {
        public string status = "failed";
        public string sourceClock = "Time.realtimeSinceStartupAsDouble in the matching beginCamera callback; not GPU completion";
        public string observation = "Existing ValidationCapture at95/96/97 selects filteredD/geometry/moments at GI size and material at full size; no other support or ordinary HDR. FilteredD validity is not a fresh raw certificate; no history-age verdict here.";
        public List<SourceFrame> frames = new List<SourceFrame>();
        public List<CaptureRecord> tickets = new List<CaptureRecord>();
    }
    [Serializable] public sealed class Result
    {
        public string status = "failed", error = "", captureDirectory, framesFile, runFile, seriesFile;
        public string actualFeatureJson, actualSettingsJson;
        public string legacyMeaning = "105-source prefix of the original720-frame sequence remains failed; no quality verdict";
        public string sourceArchive = "ValidationPackageV209/project-archive/Assets/ValidationPackageV201/Generated; original static0..104, no door/light/pose modification";
        public string observerPatch = "Ordinary Sequence HDR export suppressed; existing134 observation-only plane selector retains filteredD/geometry/moments/material, with original Reserve/ownership/readback completion logic";
        public string captureCapacityMeaning = "3 pending/512MiB observation ownership limit, not a product memory budget";
        public string dimensionMeaning = "Legacy run.width/height describe initial target; per-frame dimensions record the single resize";
        public int renderedFrames, receiptCount, ticketCount, finalLogical = FinalLogical;
        public int eventAfterLogical = EventAfterLogical, eventEngineFrame = -1, eventWorkFrame = -1;
        public int originalCameraId, originalTargetId, eventTargetIdBefore, eventTargetIdAfter;
        public int widthBefore = BeforeWidth, heightBefore = BeforeHeight, widthAfter = AfterWidth, heightAfter = AfterHeight;
        public int ordinaryPendingAtEvent = -1;
        public double eventSeconds = -1, elapsedSeconds;
        public bool eventAttempted, eventSeen, sameTargetAfterEvent, sameRequestAfterEvent, createSucceeded;
        public bool referenceDrained, legacyReadbacksDrained, allCapturesSucceeded;
        public LegacyRun legacy;
    }

    readonly Result result = new Result();
    readonly Series series = new Series();
    readonly List<HybridLumenGIValidationCapture.Ticket> tickets = new List<HybridLumenGIValidationCapture.Ticket>();
    public Result CurrentResult => result;
    HybridLumenGIValidationCapture.Session capture;
    HybridLumenGIRendererFeature.Settings actualSettings;
    Camera originalCamera;
    RenderTexture originalTarget;
    RenderPipeline.StandardRequest originalRequest;
    object readyPipeline;
    int stableUpdates, returnedCount;
    bool began, stopRequested, stopping, finished, checkpoint;
    double started;

    static void Need(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
    void Error(Exception e)
    {
        result.status = "failed";
        result.error += (result.error.Length == 0 ? "" : "\n") + e;
        stopRequested = true;
    }
    void Start()
    {
        started = Time.realtimeSinceStartupAsDouble;
        Application.runInBackground = true;
        try {
            Need(sequence != null && targetCamera != null && feature != null && expectedPipeline != null, "Archived references missing.");
            Need(Path.IsPathRooted(outputDirectory) && Directory.Exists(outputDirectory), "Editor output directory missing.");
            Need(!targetCamera.enabled && sequence.enabled && sequence.CaptureStatus == "not-started", "Expected cold explicit camera capture.");
            Need(Logical != null && Pending != null && Output != null && Width != null && Height != null && Request != null && Settings != null,
                "Existing private Sequence/Feature API unavailable.");
            Need((int)Width.GetValue(sequence) == BeforeWidth && (int)Height.GetValue(sequence) == BeforeHeight, "Initial Sequence dimensions differ.");
            Need(GraphicsSettings.currentRenderPipeline == expectedPipeline && feature.isActive, "Archived pipeline/feature not active.");
            actualSettings = (HybridLumenGIRendererFeature.Settings)Settings.GetValue(feature);
            Need(actualSettings != null, "Settings object missing.");
            // Keep the Settings object retained by the existing renderer pass.
            actualSettings.raysPerPixel = 2; actualSettings.filterIterations = 4;
            actualSettings.resolutionScale = .5f; actualSettings.preferHardwareTracing = true;
            actualSettings.debugView = HybridLumenGIRendererFeature.DebugView.IndirectOnly;
            result.actualFeatureJson = JsonUtility.ToJson(feature, true);
            result.actualSettingsJson = JsonUtility.ToJson(actualSettings, true);
            originalCamera = targetCamera; result.originalCameraId = targetCamera.GetInstanceID();
            File.WriteAllText(Path.Combine(outputDirectory, "actual-feature.json"), result.actualFeatureJson);
            File.WriteAllText(Path.Combine(outputDirectory, "actual-settings.json"), result.actualSettingsJson);
            RenderPipelineManager.beginCameraRendering += BeforeCamera;
        } catch (Exception e) { Error(e); }
    }
    void BeforeCamera(ScriptableRenderContext context, Camera camera)
    {
        if (!ReferenceEquals(camera, targetCamera) || !began || stopping || finished) return;
        try {
            int logical = (int)Logical.GetValue(sequence);
            Need(logical == series.frames.Count && logical <= FinalLogical, "Repeated/skipped source or source beyond104.");
            Need(logical == 0 || Time.frameCount == series.frames[logical - 1].engineFrame + 1, "Source engine frames are not adjacent.");
            var output = (RenderTexture)Output.GetValue(sequence);
            var request = (RenderPipeline.StandardRequest)Request.GetValue(sequence);
            Need(output != null && request != null, "Expected Sequence-owned StandardRequest destination.");
            if (logical == 0) {
                originalTarget = output; originalRequest = request; result.originalTargetId = output.GetInstanceID();
            }
            var row = new SourceFrame {
                logicalFrame = logical, engineFrame = Time.frameCount, sourceSeconds = Time.realtimeSinceStartupAsDouble,
                cameraId = camera.GetInstanceID(), targetId = camera.targetTexture != null ? camera.targetTexture.GetInstanceID() : 0,
                outputId = output.GetInstanceID(), width = output.width, height = output.height,
                sequenceWidth = (int)Width.GetValue(sequence), sequenceHeight = (int)Height.GetValue(sequence),
                cameraPixelWidth = camera.pixelWidth, cameraPixelHeight = camera.pixelHeight,
                sameCamera = ReferenceEquals(camera, originalCamera), sameTarget = ReferenceEquals(camera.targetTexture, originalTarget),
                sameOutput = ReferenceEquals(output, originalTarget), sameRenderRequest = ReferenceEquals(request, originalRequest),
                sameRequestDestination = ReferenceEquals(request.destination, originalTarget),
                targetCreated = output.IsCreated(), cameraPosition = camera.transform.position, cameraRotation = camera.transform.rotation,
                cameraProjection = camera.projectionMatrix, cameraView = camera.worldToCameraMatrix,
                settingsUnchanged = ReferenceEquals(Settings.GetValue(feature), actualSettings) && JsonUtility.ToJson(actualSettings, true) == result.actualSettingsJson
            };
            series.frames.Add(row);
            Need(row.sameCamera && row.sameTarget && row.sameOutput && row.sameRenderRequest && row.sameRequestDestination && row.targetCreated, "Camera/RT/request identity changed.");
            Need(row.settingsUnchanged && GraphicsSettings.currentRenderPipeline == expectedPipeline, "Settings or pipeline changed during observation.");
            int w = logical <= EventAfterLogical ? BeforeWidth : AfterWidth;
            int h = logical <= EventAfterLogical ? BeforeHeight : AfterHeight;
            Need(row.width == w && row.height == h && row.sequenceWidth == w && row.sequenceHeight == h, "Unexpected source dimensions.");
            Need(logical <= EventAfterLogical || result.eventSeen, "The95 returned-source resize did not precede96.");
            if (logical > 0) Need(row.cameraPosition.Equals(series.frames[0].cameraPosition) && row.cameraRotation.Equals(series.frames[0].cameraRotation), "Static camera pose changed.");
            if (logical >= 95 && logical <= 97) {
                row.ordinaryPendingAtRequest = ((IList)Pending.GetValue(sequence)).Count;
                Need(row.ordinaryPendingAtRequest == 0, "Ordinary Sequence HDR requests were not suppressed before the selected capture.");
                row.ticketIndex = tickets.Count;
                tickets.Add(capture.Request(logical, Time.frameCount));
            }
        } catch (Exception e) { Error(e); }
    }
    void ResizeReturned95(SourceFrame row)
    {
        Need(!result.eventAttempted && Time.frameCount == row.engineFrame, "Resize event repeated or delayed to another engine frame.");
        result.eventAttempted = true; result.eventEngineFrame = Time.frameCount; result.eventWorkFrame = row.workFrame;
        result.eventSeconds = Time.realtimeSinceStartupAsDouble;
        result.ordinaryPendingAtEvent = ((IList)Pending.GetValue(sequence)).Count;
        Need(result.ordinaryPendingAtEvent == 0, "Ordinary Sequence readbacks still own the pre-resize target; no delayed resize or retry.");
        var output = (RenderTexture)Output.GetValue(sequence);
        var request = (RenderPipeline.StandardRequest)Request.GetValue(sequence);
        Need(ReferenceEquals(output, originalTarget) && ReferenceEquals(targetCamera.targetTexture, output) &&
            ReferenceEquals(request, originalRequest) && ReferenceEquals(request.destination, output), "Returned source target/request identity changed.");
        result.eventTargetIdBefore = output.GetInstanceID();
        // This is the sole event. No new RT, Camera assignment, MarkDirty or invalidation call.
        output.Release(); output.width = AfterWidth; output.height = AfterHeight;
        Width.SetValue(sequence, AfterWidth); Height.SetValue(sequence, AfterHeight);
        result.createSucceeded = output.Create();
        result.eventTargetIdAfter = output.GetInstanceID();
        result.sameTargetAfterEvent = ReferenceEquals(Output.GetValue(sequence), originalTarget) && ReferenceEquals(targetCamera.targetTexture, originalTarget);
        result.sameRequestAfterEvent = ReferenceEquals(Request.GetValue(sequence), originalRequest) && ReferenceEquals(originalRequest.destination, originalTarget);
        Need(result.createSucceeded && output.IsCreated() && result.sameTargetAfterEvent && result.sameRequestAfterEvent &&
            result.eventTargetIdBefore == result.eventTargetIdAfter, "In-place target recreation failed.");
        result.eventSeen = true;
    }
    void RecordReturnedSource()
    {
        if (returnedCount == series.frames.Count) return;
        Need(series.frames.Count == returnedCount + 1, "More than one source submitted in one Host update.");
        var row = series.frames[returnedCount];
        Need(sequence.RenderedFrames == row.logicalFrame + 1 && Time.frameCount == row.engineFrame, "Source did not return in its recorded engine frame.");
        row.returnedSeconds = Time.realtimeSinceStartupAsDouble;
        var matches = feature.GetDiagnostics().Where(d => d.camera == targetCamera.name).ToArray();
        Need(matches.Length == 1, "Missing or ambiguous camera diagnostics.");
        row.diagnostics = matches[0]; row.giFrame = matches[0].frame; row.workFrame = matches[0].transportRecordedWorkFrame;
        Need(row.diagnostics.hardwareBackend && row.diagnostics.recordedTransportBackend == "DXR" &&
            row.diagnostics.transportRecordedEngineFrame == row.engineFrame && row.workFrame == row.logicalFrame,
            "Source did not record the matching DXR work frame.");
        if (returnedCount > 0) Need(row.giFrame == series.frames[returnedCount - 1].giFrame + 1 &&
            row.workFrame == series.frames[returnedCount - 1].workFrame + 1, "GI/work frame discontinuity.");
        row.returned = true; returnedCount++;
        if (!stopRequested && row.logicalFrame == EventAfterLogical) ResizeReturned95(row);
        if (row.logicalFrame == FinalLogical) stopRequested = true;
    }
    void Update()
    {
        if (finished) return;
        try {
            if (stopping) { Drain(); return; }
            if (!began) {
                if (stopRequested) return;
                if (Time.realtimeSinceStartupAsDouble - started > 300) throw new TimeoutException("Pipeline not ready after300seconds; no source restart.");
                if (!RenderPipeline.SupportsRenderRequest(targetCamera, new RenderPipeline.StandardRequest())) return;
                object current = RenderPipelineManager.currentPipeline;
                if (current == null || !ReferenceEquals(current, readyPipeline)) { readyPipeline = current; stableUpdates = 0; return; }
                if (++stableUpdates < 2) return;
                Need(GraphicsSettings.currentRenderPipeline == expectedPipeline, "Archived pipeline changed before Begin.");
                capture = HybridLumenGIValidationCapture.Begin(targetCamera, feature, Path.Combine(outputDirectory, "signals"), 3, 512L * 1024 * 1024);
                began = true; sequence.BeginCapture();
            }
            RecordReturnedSource();
            if (!stopRequested && sequence.CaptureStatus != "running") throw new InvalidOperationException("Sequence ended early: " + sequence.CaptureStatus);
            if (!stopRequested && Time.realtimeSinceStartupAsDouble - started > 300) throw new TimeoutException("Bounded105-source prefix exceeded300seconds.");
        } catch (Exception e) { Error(e); }
    }
    void LateUpdate()
    {
        if (finished || stopping || !stopRequested) return;
        stopping = true;
        try { if (sequence != null) sequence.enabled = false; }
        catch (Exception e) { Error(e); }
        finally {
            if (targetCamera != null) targetCamera.enabled = false;
            RenderPipelineManager.beginCameraRendering -= BeforeCamera;
            capture?.Seal();
        }
        Drain();
    }
    bool LegacyDrained()
    {
        if (sequence == null || Pending == null || Output == null) return !began;
        return ((IList)Pending.GetValue(sequence)).Count == 0 && Output.GetValue(sequence) == null && sequence.ReferenceCaptureDrained;
    }
    void Drain()
    {
        if (finished) return;
        result.referenceDrained = capture == null || capture.IsDrained;
        result.legacyReadbacksDrained = LegacyDrained();
        if (!result.referenceDrained || !result.legacyReadbacksDrained) {
            if (!checkpoint && Time.realtimeSinceStartupAsDouble - started > 300) {
                checkpoint = true;
                result.error += "\nReadbacks have not terminated; owners remain alive and polling continues.";
                result.renderedFrames = sequence != null ? sequence.RenderedFrames : 0;
                result.elapsedSeconds = Time.realtimeSinceStartupAsDouble - started;
                File.WriteAllText(Path.Combine(outputDirectory, "retained-checkpoint.json"), JsonUtility.ToJson(result, true));
                File.WriteAllText(Path.Combine(outputDirectory, "retained-series.json"), JsonUtility.ToJson(series, true));
            }
            return;
        }
        Finish();
    }
    void Finish()
    {
        if (finished) return; finished = true;
        try {
            result.renderedFrames = sequence != null ? sequence.RenderedFrames : 0;
            result.captureDirectory = sequence != null ? sequence.OutputDirectory : null;
            result.seriesFile = Path.Combine(outputDirectory, "series.json");
            result.ticketCount = tickets.Count; result.allCapturesSucceeded = true;
            foreach (var t in tickets) {
                series.tickets.Add(new CaptureRecord { logicalFrame = t.Result.logicalFrame, engineFrame = t.Result.engineFrame,
                    workFrame = t.Result.workFrame, receiptPath = t.ReceiptPath, failure = t.Failure,
                    complete = t.IsComplete, succeeded = t.Succeeded, receipt = t.Result });
                result.allCapturesSucceeded &= t.Succeeded;
            }
            if (!string.IsNullOrEmpty(result.captureDirectory)) {
                result.runFile = Path.Combine(result.captureDirectory, "run.json"); result.framesFile = Path.Combine(result.captureDirectory, "frames.jsonl");
                result.legacy = JsonUtility.FromJson<LegacyRun>(File.ReadAllText(result.runFile));
                var lines = File.ReadAllLines(result.framesFile); result.receiptCount = lines.Length;
                Need(lines.Length == series.frames.Count, "Host source records and original Sequence receipts differ.");
                for (int i = 0; i < lines.Length; i++) {
                    var f = JsonUtility.FromJson<LegacyFrame>(lines[i]); var row = series.frames[i];
                    row.doorLocalPosition = f.doorLocalPosition; row.lightsEnabled = f.lightsEnabled;
                    Need(f.logicalFrame == i && f.engineFrame == row.engineFrame && f.giFrame == row.giFrame && row.returned &&
                        f.width == row.width && f.height == row.height && f.cameraPosition.Equals(row.cameraPosition) &&
                        f.cameraRotation.Equals(row.cameraRotation) && f.diagnosticFresh && f.reportedBackend == "reported-hardware",
                        "Original source receipt/backend/dimensions differ at" + i);
                    Need(f.lightsEnabled && (i == 0 || f.doorLocalPosition.Equals(series.frames[0].doorLocalPosition)), "Original static door/light stage changed.");
                }
            }
            Need(result.renderedFrames == 105 && result.receiptCount == 105 && returnedCount == 105, "The0..104 source prefix is incomplete.");
            Need(result.eventSeen && result.eventEngineFrame == series.frames[95].engineFrame && result.eventWorkFrame == series.frames[95].workFrame,
                "Resize does not belong to returned95.");
            Need(result.legacy != null && result.legacy.status == "failed" && result.legacy.failures == 0 && result.legacy.backendMismatches == 0,
                "Expected intentional failed720-prefix with no real render/backend failure.");
            Need(tickets.Count == 3 && result.allCapturesSucceeded, "The three95/96/97 selected-plane captures did not complete.");
            for (int i = 0; i < tickets.Count; i++) {
                var t = tickets[i]; var row = series.frames[95 + i];
                Need(t.Result.logicalFrame == row.logicalFrame && t.Result.engineFrame == row.engineFrame && t.Result.workFrame == row.workFrame &&
                    t.Result.cameraInstanceId == result.originalCameraId && t.Result.featureInstanceId == feature.GetInstanceID() &&
                    t.Result.beforeRecorded && t.Result.afterRecorded && t.Result.cameraEnded &&
                    t.Result.readbacksCompleted && t.Result.retainedBytes == 0, "Capture association/drain differs at" + row.logicalFrame);
            }
            if (result.error.Length == 0) result.status = "collected";
        } catch (Exception e) { Error(e); }
        finally {
            result.elapsedSeconds = Time.realtimeSinceStartupAsDouble - started;
            try { capture?.Dispose(); } catch (Exception e) { Error(e); }
            series.status = result.status;
            try {
                File.WriteAllText(Path.Combine(outputDirectory, "series.json"), JsonUtility.ToJson(series, true));
                File.WriteAllText(Path.Combine(outputDirectory, "host-result.json"), JsonUtility.ToJson(result, true));
            } finally {
#if UNITY_EDITOR
                UnityEditor.EditorApplication.isPlaying = false;
#endif
            }
        }
    }
    void OnDestroy() { RenderPipelineManager.beginCameraRendering -= BeforeCamera; }
}
