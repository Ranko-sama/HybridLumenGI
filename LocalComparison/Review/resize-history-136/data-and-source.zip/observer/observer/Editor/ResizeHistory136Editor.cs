#if UNITY_EDITOR
using System;
using System.IO;
using System.Linq;
using System.Reflection;
using HybridLumenGI;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;

[InitializeOnLoad]
public static class ResizeHistory136Editor
{
    const string Root = "Assets/HLGIResizeHistory136", Original = "Assets/ValidationPackageV201";
    const string Generated = Original + "/Generated", SourceScene = Generated + "/Scenes/Run/Validation.unity";
    const string RendererPath = Generated + "/Renderer.asset", PipelinePath = Generated + "/Pipeline.asset";
    const string WorkingScene = Root + "/run.unity", Key = "ResizeHistory136.";
    static readonly FieldInfo Settings = typeof(HybridLumenGIRendererFeature).GetField("settings", BindingFlags.Instance | BindingFlags.NonPublic);
    [Serializable] sealed class ImportAsset { public string guid, path; }
    [Serializable] sealed class ImportMap { public ImportAsset[] assets; }
    [Serializable] sealed class RestoreState
    {
        public SceneSetup[] scenes;
        public string qualityPipeline, originalSettings;
        public bool emptyScene, qualityWasNull;
    }
    [Serializable] sealed class Result
    {
        public string status = "failed", error = "", output, sourceScene = SourceScene, workingScene = WorkingScene;
        public string sourceArchive = "ValidationPackageV209/project-archive/Assets/ValidationPackageV201/Generated";
        public string inputMeaning = "Archived static0..104 scene; same Camera/RT reference; full1918x1078 to1919x1079 at95 return; unchanged halfGI/2ray/filter4/DXR";
        public bool restored, importIdentityMatched;
        public ResizeHistory136Host.Result observation;
    }
    static ResizeHistory136Editor() { EditorApplication.playModeStateChanged += Changed; }
    static void Need(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
    static string Arg(string key) { var a = Environment.GetCommandLineArgs(); int i = Array.IndexOf(a, key); return i >= 0 && i + 1 < a.Length ? a[i + 1] : null; }
    static T[] All<T>(Scene s) where T : Component => s.GetRootGameObjects().SelectMany(o => o.GetComponentsInChildren<T>(true)).ToArray();
    static void Changed(PlayModeStateChange state)
    { if (state == PlayModeStateChange.EnteredEditMode && SessionState.GetBool(Key + "active", false)) EditorApplication.delayCall += Complete; }
    static HybridLumenGIRendererFeature Feature(UniversalRendererData renderer)
    {
        Need(renderer != null, "Archived renderer missing.");
        var features = renderer.rendererFeatures.OfType<HybridLumenGIRendererFeature>().ToArray();
        Need(features.Length == 1 && features[0].isActive && renderer.rendererFeatures.Count == 1, "Archived renderer feature set differs.");
        return features[0];
    }
    static void Restore()
    {
        var state = JsonUtility.FromJson<RestoreState>(SessionState.GetString(Key + "restore", "")); Need(state != null, "Original Editor state missing.");
        // Runtime changes to ScriptableObjects need explicit memory restoration; never save the archived asset.
        if (!string.IsNullOrEmpty(state.originalSettings)) {
            var feature = Feature(AssetDatabase.LoadAssetAtPath<UniversalRendererData>(RendererPath));
            JsonUtility.FromJsonOverwrite(state.originalSettings, Settings.GetValue(feature));
            EditorUtility.ClearDirty(feature);
        }
        QualitySettings.renderPipeline = state.qualityWasNull ? null : AssetDatabase.LoadAssetAtPath<RenderPipelineAsset>(state.qualityPipeline);
        Need(state.qualityWasNull || QualitySettings.renderPipeline != null, "Original Quality pipeline disappeared.");
        if (state.emptyScene) EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        else EditorSceneManager.RestoreSceneManagerSetup(state.scenes);
    }
    static void Complete()
    {
        string output = SessionState.GetString(Key + "output", "");
        var result = new Result { output = output, importIdentityMatched = SessionState.GetBool(Key + "imports", false) };
        try {
            result.observation = JsonUtility.FromJson<ResizeHistory136Host.Result>(File.ReadAllText(Path.Combine(output, "host-result.json")));
            Need(result.observation != null && result.observation.status == "collected", "Prefix/capture failed: " + result.observation?.error);
            result.status = "collected";
        } catch (Exception e) { result.error = e.ToString(); }
        try { Restore(); result.restored = true; } catch (Exception e) { result.status = "failed"; result.error += "\nRestore: " + e; }
        SessionState.SetBool(Key + "active", false);
        File.WriteAllText(Path.Combine(output, "result.json"), JsonUtility.ToJson(result, true));
        EditorApplication.Exit(result.status == "collected" && result.restored ? 0 : 1);
    }
    public static void Run()
    {
        Need(!EditorApplication.isPlayingOrWillChangePlaymode && !SessionState.GetBool(Key + "active", false), "Existing Play session must be preserved.");
        Need(!EditorSettings.enterPlayModeOptionsEnabled ||
            (EditorSettings.enterPlayModeOptions & (EnterPlayModeOptions.DisableDomainReload | EnterPlayModeOptions.DisableSceneReload)) == 0,
            "Existing sequence requires ordinary scene/domain reload.");
        string output = Arg("-resizeHistoryOutput");
        Need(!string.IsNullOrEmpty(output) && Path.IsPathRooted(output) && !Directory.Exists(output) && !File.Exists(output), "Fresh absolute output required.");
        Need(!File.Exists(WorkingScene), "Preserve existing temporary scene.");
        var setup = EditorSceneManager.GetSceneManagerSetup(); bool empty = setup.Length == 0; int unnamed = 0;
        for (int i = 0; i < SceneManager.sceneCount; i++) {
            var s = SceneManager.GetSceneAt(i); Need(!s.isDirty, "Save original scene edits first.");
            if (string.IsNullOrEmpty(s.path)) { Need(s.rootCount == 0, "Original unnamed scene is nonempty."); unnamed++; }
        }
        if (empty || unnamed != 0) { Need(SceneManager.sceneCount == 0 || (SceneManager.sceneCount == 1 && unnamed == 1), "Cannot restore mixed unnamed scenes."); empty = true; }
        var quality = QualitySettings.renderPipeline; string qualityPath = AssetDatabase.GetAssetPath(quality);
        Need(quality == null || !string.IsNullOrEmpty(qualityPath), "Original Quality override is not persistent.");
        Directory.CreateDirectory(output);
        var restore = new RestoreState { scenes = setup, emptyScene = empty, qualityWasNull = quality == null, qualityPipeline = qualityPath };
        SessionState.SetString(Key + "output", output); SessionState.SetString(Key + "restore", JsonUtility.ToJson(restore));
        SessionState.SetBool(Key + "imports", false);
        try {
            Need(SystemInfo.graphicsDeviceType == GraphicsDeviceType.Direct3D12 && QualitySettings.activeColorSpace == ColorSpace.Linear,
                "Existing Linear/DX12 project required.");
            var map = JsonUtility.FromJson<ImportMap>(File.ReadAllText(Original + "/import-map.json"));
            Need(map != null && map.assets != null && map.assets.Length > 0, "Archive import map missing.");
            foreach (var item in map.assets) Need(!string.IsNullOrEmpty(item.guid) && item.path.StartsWith(Generated + "/", StringComparison.Ordinal) &&
                AssetDatabase.GUIDToAssetPath(item.guid) == item.path, "Archive GUID/path mismatch: " + item.path);
            SessionState.SetBool(Key + "imports", true);
            Need(AssetDatabase.LoadAssetAtPath<SceneAsset>(SourceScene) != null, "Original saved scene unavailable; do not regenerate it.");
            var scene = EditorSceneManager.OpenScene(SourceScene, OpenSceneMode.Single);
            Need(!All<MonoBehaviour>(scene).Any(c => c == null), "Archived scene has missing scripts; no fixture repair is allowed.");
            var oldHosts = All<MonoBehaviour>(scene).Where(c => c.GetType().Name == "ValidationPackageV2Host").ToArray();
            Need(oldHosts.Length == 1, "Expected the original serialized Host."); oldHosts[0].enabled = false;
            var sequences = All<HybridLumenGIValidationSequence>(scene); Need(sequences.Length == 1, "Original sequence reference missing/ambiguous.");
            var sequence = sequences[0]; var edit = new SerializedObject(sequence);
            var camera = edit.FindProperty("targetCamera").objectReferenceValue as Camera;
            Need(camera != null && All<Camera>(scene).Length == 1, "Original camera reference differs.");
            Need(edit.FindProperty("door").objectReferenceValue != null && edit.FindProperty("colorView").objectReferenceValue != null &&
                edit.FindProperty("thinWallView").objectReferenceValue != null && edit.FindProperty("blackRoomView").objectReferenceValue != null,
                "Original door/view marker references missing.");
            var lights = edit.FindProperty("switchedLights"); Need(lights.arraySize == 5, "Original five-light array differs.");
            for (int i = 0; i < lights.arraySize; i++) Need(lights.GetArrayElementAtIndex(i).objectReferenceValue != null, "Original light reference missing.");
            var proxies = All<HybridLumenGIProxy>(scene); Need(proxies.Length == 20, "Original 20-owner scene differs.");
            foreach (var proxy in proxies) {
                Need(proxy.SourceRenderer is MeshRenderer && proxy.SourceMesh != null && proxy.MeshSdf != null && proxy.MeshSdf.IsValid &&
                    proxy.MeshSdf.SourceMesh == proxy.SourceMesh && proxy.SurfaceCharts != null && proxy.SurfaceCharts.IsValid &&
                    proxy.SurfaceCharts.SourceMesh == proxy.SourceMesh && proxy.SurfaceCharts.CaptureMesh != null,
                    "Archived source/baked references cannot be used directly: " + proxy.name);
                Need(proxy.SourceRenderer.sharedMaterials.All(m => m != null && m.shader != null), "Archived material/shader missing: " + proxy.name);
            }
            // OpenScene may invalidate native wrappers; load the renderer/pipeline only here, next to use.
            var renderer = AssetDatabase.LoadAssetAtPath<UniversalRendererData>(RendererPath); var feature = Feature(renderer);
            Need(edit.FindProperty("feature").objectReferenceValue == feature, "Original scene feature does not resolve to archived renderer.");
            restore.originalSettings = JsonUtility.ToJson(Settings.GetValue(feature));
            SessionState.SetString(Key + "restore", JsonUtility.ToJson(restore));
            // The Host changes the existing Settings object in Start. A pass created
            // during pipeline preparation may already hold that same object.
            var pipeline = AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(PipelinePath); Need(pipeline != null, "Archived pipeline missing.");
            var pipelineData = new SerializedObject(pipeline); var rendererList = pipelineData.FindProperty("m_RendererDataList");
            int selected = new SerializedObject(camera.GetUniversalAdditionalCameraData()).FindProperty("m_RendererIndex").intValue;
            if (selected == -1) selected = pipelineData.FindProperty("m_DefaultRendererIndex").intValue;
            Need(selected >= 0 && selected < rendererList.arraySize && rendererList.GetArrayElementAtIndex(selected).objectReferenceValue == renderer,
                "Original camera/pipeline does not select the archived renderer.");
            Need(renderer.renderingMode == RenderingMode.Forward && camera.GetUniversalAdditionalCameraData().renderType == CameraRenderType.Base,
                "Original renderer/camera is not Forward Base.");
            sequence.enabled = true; camera.enabled = false;
            edit.FindProperty("runOnStart").boolValue = false; edit.FindProperty("feature").objectReferenceValue = feature;
            edit.FindProperty("expectedBackend").enumValueIndex = (int)HybridLumenGIValidationSequence.ExpectedBackend.Hardware;
            edit.FindProperty("width").intValue = 1918; edit.FindProperty("height").intValue = 1078;
            edit.FindProperty("captureEvery").intValue = 9999; edit.FindProperty("explicitRenderRequests").boolValue = true;
            edit.FindProperty("exportReferencePackage").boolValue = false; edit.FindProperty("referenceSourcePackage").stringValue = "";
            edit.FindProperty("outputRoot").stringValue = Path.Combine(output, "capture");
            edit.FindProperty("runLabel").stringValue = "resize-history-136";
            edit.ApplyModifiedPropertiesWithoutUndo();
            var host = new GameObject("ResizeHistory136Host").AddComponent<ResizeHistory136Host>();
            host.sequence = sequence; host.targetCamera = camera; host.feature = feature; host.expectedPipeline = pipeline;
            host.outputDirectory = output;
            Need(EditorSceneManager.SaveScene(scene, WorkingScene), "Could not save private observer scene.");
            // No SaveAssets: original physical assets and renderer/pipeline serialization remain untouched.
            QualitySettings.renderPipeline = pipeline; SessionState.SetBool(Key + "active", true);
            EditorApplication.EnterPlaymode();
        } catch (Exception e) {
            var result = new Result { output = output, error = e.ToString(), importIdentityMatched = SessionState.GetBool(Key + "imports", false) };
            try { Restore(); result.restored = true; } catch (Exception restoreError) { result.error += "\nRestore: " + restoreError; }
            SessionState.SetBool(Key + "active", false);
            File.WriteAllText(Path.Combine(output, "result.json"), JsonUtility.ToJson(result, true)); EditorApplication.Exit(1);
        }
    }
}
#endif
