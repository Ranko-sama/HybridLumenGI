using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using HybridLumenGI;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;

// One Edit-mode capture sequence. No Play, camera, transport or lighting cache.
public static class CardReuse132Editor
{
    const string Root = "Assets/HLGICardReuse132";
    [StructLayout(LayoutKind.Sequential)] struct GpuCard
    {
        public Matrix4x4 worldToCard;
        public Vector4 atlasRect, directionTolerance;
        public uint stableId, revision, generation, ready, ownerSlot, chartId, layoutGeneration, flags;
    }
    [Serializable] sealed class Chart
    {
        public uint stableId;
        public int sourceSubmesh;
        public int[] triangleIndices;
        public float[] localToCard;
        public Vector3 direction, boundsCenter, boundsExtents;
    }
    [Serializable] sealed class Source
    {
        public string name, meshAsset, chartsAsset, captureAsset, materialAsset, shader;
        public int stableId, revision, geometryRevision, vertexCount, submeshCount;
        public Vector3[] vertices, normals;
        public Vector2[] uv;
        public int[] indices;
        public float[] localToWorld;
        public Chart[] charts;
        public Color baseColor, emissionColor, albedoTint, emissionOverride;
        public float metallic, workflow, cull, alphaClip, alphaToMask, surface, emissionIntensity;
        public bool hasPropertyBlock, hasBaseMap;
        public string[] keywords;
    }
    [Serializable] sealed class Binding
    {
        public int slot, submesh, primitive;
        public bool available;
        // Do not nest the production, non-Serializable TriangleChartBinding.
        public uint cardIndex, chartId, layoutGeneration, geometryRevision;
    }
    [Serializable] sealed class CardRow
    {
        public int index;
        public float[] worldToCard;
        public Vector4 atlasRect, directionTolerance;
        public uint stableId, revision, generation, ready, ownerSlot, chartId, layoutGeneration, flags;
    }
    [Serializable] sealed class Plane
    {
        public string role, file, sourceFormat;
        public string format = "rgba32f-le", rowOrder = "native-readback-no-row-flip";
        public int width, height, textureInstanceId;
        public bool requested, completed, hasError;
    }
    [Serializable] sealed class Phase
    {
        public string name;
        public Source source;
        public int ownerSlot = -1, cardIndex = -1, physicalOwnerSlot = -1;
        public int cardCount, atlasWidth, atlasHeight, capturedCards, beforeRecordReadyCards, afterRecordReadyCards;
        public uint atlasGeneration, layoutGeneration, captureGeneration;
        public bool beforeRecordReady, submitted, fencePassed;
        public double submittedSeconds;
        public Binding[] bindings;
        public Plane[] atlases;
        public CardRow[] metadata;
        public Vector2Int[] anchors;
        public string metadataFile, anchorsFile;
        public int metadataStride = 128, anchorsStride = 8, metadataCount, anchorsCount;
        public bool metadataCompleted, metadataError, anchorsCompleted, anchorsError;
    }
    [Serializable] sealed class Result
    {
        public string status = "failed", error = "", unity, device, api, colorSpace;
        public string scope = "One Edit-mode production SurfaceCache, A square then B triangle; atlas/metadata/anchor reuse only, no HLOD or transport";
        public int processId, qualityMsaa, tileResolution = 64, maxResidentCards = 1, maxAtlasMiB = 1, patchGrid = 4, capturesPerFrame = 1;
        public bool restored, uvStartsAtTop, invertCullingBefore, invertCullingAfter;
        public float alphaToMaskAvailableBefore, alphaToMaskAvailableAfter;
        public bool aReadbacksPendingBeforeB, uncertainSubmission, allReadbacksCompleted;
        public int aPendingCountBeforeB, requestedReadbacks, completedReadbacks;
        public List<string> order = new List<string>();
        public Phase a, b;
        public Binding staleABindingAfterB;
    }
    sealed class Ticket
    {
        public AsyncGPUReadbackRequest request;
        public bool requested, completed;
    }
    sealed class Capture
    {
        public Phase row;
        public readonly List<Ticket> tickets = new List<Ticket>();
        public readonly Vector4[][] planeData = new Vector4[3][];
        public GpuCard[] metadata;
        public Vector2Int[] anchors;
        public GraphicsFence fence;
        public CommandBuffer command;
        public bool fenceReadFailed;
    }
    static Result result;
    static string output;
    static SceneSetup[] prior;
    static bool originalEmpty, changedScene, submitting, finished, checkpointWritten;
    static double start;
    static HybridLumenGIScene scene;
    static HybridLumenGISurfaceCache cards;
    static GameObject aObject, bObject;
    static readonly List<Capture> captures = new List<Capture>();
    static void Need(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
    static void Fail(Exception error) { result.status = "failed"; result.error += (result.error.Length == 0 ? "" : "\n") + error; }
    static float[] Rows(Matrix4x4 m)
    {
        var a = new float[16]; for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) a[r * 4 + c] = m[r, c]; return a;
    }
    static ComputeBuffer Buffer(string name) => (ComputeBuffer)typeof(HybridLumenGISurfaceCache)
        .GetField(name, BindingFlags.Instance | BindingFlags.NonPublic).GetValue(cards);
    static void WriteRaw<T>(string file, T[] data) where T : struct
    {
        if (data == null) return;
        var bytes = new byte[checked(data.Length * Marshal.SizeOf<T>())];
        var pin = GCHandle.Alloc(data, GCHandleType.Pinned);
        try { if (bytes.Length != 0) Marshal.Copy(pin.AddrOfPinnedObject(), bytes, 0, bytes.Length); }
        finally { pin.Free(); }
        File.WriteAllBytes(Path.Combine(output, file), bytes);
    }
    static void MakeAssets(string name, bool triangle)
    {
        Vector3[] positions = triangle ? new[] { new Vector3(-1,-1,0), new Vector3(-1,1,0), new Vector3(1,-1,0) }
            : new[] { new Vector3(-1,-1,0), new Vector3(1,-1,0), new Vector3(1,1,0), new Vector3(-1,1,0) };
        var mesh = new Mesh { name = name + "Source", vertices = positions,
            normals = Enumerable.Repeat(Vector3.back, positions.Length).ToArray(),
            uv = positions.Select(p => new Vector2((p.x + 1) * .5f, (p.y + 1) * .5f)).ToArray() };
        mesh.SetTriangles(triangle ? new[] { 0,1,2 } : new[] { 0,2,1,0,3,2 }, 0);
        mesh.RecalculateBounds(); mesh.RecalculateTangents();
        AssetDatabase.CreateAsset(mesh, Root + "/" + name + "Mesh.asset");
        var baked = HybridLumenGISurfaceCharts.Bake(mesh, new HybridLumenGISurfaceCharts.BakeSettings(), out var report);
        Need(baked.Length == 1 && report.validTriangles == (triangle ? 1 : 2), name + " must bake to one complete chart.");
        var captureMesh = HybridLumenGISurfaceCharts.CreateCaptureMesh(mesh, baked);
        var charts = ScriptableObject.CreateInstance<HybridLumenGISurfaceCharts>();
        charts.name = name + "Charts"; charts.SetBakedData(mesh, captureMesh, baked);
        AssetDatabase.CreateAsset(charts, Root + "/" + name + "Charts.asset");
        AssetDatabase.AddObjectToAsset(captureMesh, charts);
        var shader = Shader.Find("Universal Render Pipeline/Lit"); Need(shader != null, "Ordinary Lit missing.");
        var material = new Material(shader) { name = name + "Material", shaderKeywords = Array.Empty<string>() };
        material.SetColor("_BaseColor", triangle ? Color.blue : Color.red);
        material.SetColor("_EmissionColor", Color.black);
        material.SetFloat("_WorkflowMode", 1); material.SetFloat("_Metallic", 0); material.SetFloat("_Surface", 0);
        material.SetFloat("_Cull", (float)CullMode.Back); material.SetFloat("_AlphaClip", 0); material.SetFloat("_AlphaToMask", 0);
        material.SetFloat("_ZWrite", 1); material.SetFloat("_SrcBlend", 1); material.SetFloat("_DstBlend", 0);
        material.SetFloat("_OcclusionStrength", 1); material.SetTexture("_BaseMap", null);
        material.DisableKeyword("_EMISSION"); material.renderQueue = (int)RenderQueue.Geometry;
        AssetDatabase.CreateAsset(material, Root + "/" + name + "Material.mat");
    }
    static GameObject MakeObject(string name, Vector3 position)
    {
        // Reload only after every asset has been created/saved; do not retain native wrappers across creation.
        var mesh = AssetDatabase.LoadAssetAtPath<Mesh>(Root + "/" + name + "Mesh.asset");
        var charts = AssetDatabase.LoadAssetAtPath<HybridLumenGISurfaceCharts>(Root + "/" + name + "Charts.asset");
        var material = AssetDatabase.LoadAssetAtPath<Material>(Root + "/" + name + "Material.mat");
        Need(mesh != null && charts != null && material != null && charts.SourceMesh == mesh && charts.IsValid &&
            charts.CaptureMesh != null && AssetDatabase.IsSubAsset(charts.CaptureMesh), "Saved source/chart/capture/material missing: " + name);
        var go = new GameObject(name); go.SetActive(false); go.transform.position = position;
        go.AddComponent<MeshFilter>().sharedMesh = mesh;
        var renderer = go.AddComponent<MeshRenderer>(); renderer.sharedMaterial = material;
        var proxy = go.AddComponent<HybridLumenGIProxy>(); proxy.SetSources(renderer, null); proxy.SetSurfaceCharts(charts);
        return go;
    }
    static Source Describe(HybridLumenGIProxy proxy)
    {
        var renderer = (MeshRenderer)proxy.SourceRenderer; var mesh = renderer.GetComponent<MeshFilter>().sharedMesh;
        var asset = proxy.SurfaceCharts; var material = renderer.sharedMaterial;
        return new Source { name = proxy.name, meshAsset = AssetDatabase.GetAssetPath(mesh), chartsAsset = AssetDatabase.GetAssetPath(asset),
            captureAsset = AssetDatabase.GetAssetPath(asset.CaptureMesh), materialAsset = AssetDatabase.GetAssetPath(material), shader = material.shader.name,
            stableId = proxy.StableId, revision = proxy.Revision, geometryRevision = proxy.GeometryContentRevision,
            vertexCount = mesh.vertexCount, submeshCount = mesh.subMeshCount, vertices = mesh.vertices, normals = mesh.normals,
            uv = mesh.uv, indices = mesh.GetIndices(0), localToWorld = Rows(renderer.localToWorldMatrix),
            charts = asset.Charts.Select(c => new Chart { stableId = c.stableId, sourceSubmesh = c.sourceSubmesh,
                triangleIndices = c.triangleIndices, localToCard = Rows(c.localToCard), direction = c.direction,
                boundsCenter = c.localBounds.center, boundsExtents = c.localBounds.extents }).ToArray(),
            baseColor = material.GetColor("_BaseColor"), emissionColor = material.GetColor("_EmissionColor"),
            metallic = material.GetFloat("_Metallic"), workflow = material.GetFloat("_WorkflowMode"), cull = material.GetFloat("_Cull"),
            alphaClip = material.GetFloat("_AlphaClip"), alphaToMask = material.GetFloat("_AlphaToMask"), surface = material.GetFloat("_Surface"),
            keywords = material.shaderKeywords, hasPropertyBlock = renderer.HasPropertyBlock(), hasBaseMap = material.GetTexture("_BaseMap") != null,
            albedoTint = proxy.AlbedoTint, emissionOverride = proxy.EmissionOverride, emissionIntensity = proxy.EmissionIntensity };
    }
    static Binding GetBinding(int slot, Mesh mesh, int primitive)
    {
        bool available = cards.TryGetTriangleBinding(slot, mesh, 0, primitive, out var b);
        return new Binding { slot = slot, submesh = 0, primitive = primitive, available = available,
            cardIndex = b.cardIndex, chartId = b.chartId, layoutGeneration = b.layoutGeneration, geometryRevision = b.geometryRevision };
    }
    static Capture Submit(string name, GameObject source)
    {
        var proxy = source.GetComponent<HybridLumenGIProxy>();
        scene.Prepare(Vector3.zero, 32, 100, 100, 16, 32);
        cards.Prepare(scene, new HybridLumenGISurfaceCache.Config { referencePosition = Vector3.zero, tileResolution = 64,
            maxResidentCards = 1, maxAtlasMiB = 1, capturesPerFrame = 1, patchGrid = 4 });
        int slot = Enumerable.Range(0, scene.Capacity).Single(i => scene.GetProxy(i) == proxy && scene.IsPublished(i));
        var mesh = source.GetComponent<MeshFilter>().sharedMesh;
        var row = new Phase { name = name, source = Describe(proxy), ownerSlot = slot, cardIndex = cards.GetCardIndex(slot, 0),
            cardCount = cards.CardCount, atlasGeneration = cards.AtlasGeneration, atlasWidth = cards.AtlasWidth, atlasHeight = cards.AtlasHeight,
            layoutGeneration = cards.GetLayoutGeneration(slot), beforeRecordReady = cards.IsSlotReady(slot, proxy.StableId, proxy.Revision),
            beforeRecordReadyCards = cards.ReadyCards, metadataFile = name + "-metadata.bin", anchorsFile = name + "-anchors.bin" };
        var capture = new Capture { row = row, command = new CommandBuffer { name = "Card reuse " + name } };
        captures.Add(capture); if (name == "A") result.a = row; else result.b = row;
        Need(cards.GetCardCount(slot) == 1 && row.cardIndex >= 0 && cards.CardCount == 1, "Expected a single physical card.");
        row.physicalOwnerSlot = cards.CardOwners[row.cardIndex]; row.captureGeneration = cards.GetGeneration(row.cardIndex);
        row.bindings = Enumerable.Range(0, mesh.GetIndices(0).Length / 3).Select(p => GetBinding(slot, mesh, p)).ToArray();
        row.capturedCards = cards.RecordCapture(capture.command, new Rect(0, 0, 64, 64));
        row.afterRecordReadyCards = cards.ReadyCards;
        Need(row.capturedCards == 1, "Expected exactly one recorded capture for " + name);
        // Completion boundary also protects failure paths where a readback request itself throws.
        capture.fence = capture.command.CreateGraphicsFence(GraphicsFenceType.AsyncQueueSynchronisation, SynchronisationStageFlags.AllGPUOperations);
        result.uncertainSubmission = true;
        Graphics.ExecuteCommandBuffer(capture.command);
        result.uncertainSubmission = false; row.submitted = true;
        row.submittedSeconds = EditorApplication.timeSinceStartup - start;
        result.order.Add(name + ":ExecuteCommandBuffer-returned");
        return capture;
    }
    static void Request(Capture capture, Func<Action<AsyncGPUReadbackRequest>, AsyncGPUReadbackRequest> submit, Action<AsyncGPUReadbackRequest> copy)
    {
        var ticket = new Ticket(); capture.tickets.Add(ticket);
        ticket.requested = true; result.requestedReadbacks++;
        try {
            ticket.request = submit(request => {
                try { Need(request.done && !request.hasError, "GPU readback failed: " + capture.row.name); copy(request); }
                catch (Exception e) { Fail(e); }
                finally { ticket.completed = true; result.completedReadbacks++; }
            });
        } catch {
            // No returned request exists. The capture fence still owns the submitted command's resources.
            ticket.requested = false; result.requestedReadbacks--; throw;
        }
    }
    static void ReadPhase(Capture capture)
    {
        var handles = new[] { cards.DiffuseAtlas, cards.PositionAtlas, cards.EmissionAtlas };
        var roles = new[] { "diffuse", "position", "emissionValidity" };
        capture.row.atlases = new Plane[3];
        for (int i = 0; i < handles.Length; i++) {
            int planeIndex = i; var rt = handles[i].rt;
            Need(rt != null, "Missing " + roles[i]);
            var plane = new Plane { role = roles[i], file = capture.row.name + "-" + roles[i] + ".rgba32f",
                sourceFormat = rt.graphicsFormat.ToString(), width = rt.width, height = rt.height, textureInstanceId = rt.GetInstanceID(), requested = true };
            capture.row.atlases[i] = plane;
            Request(capture, callback => AsyncGPUReadback.Request(rt, 0, TextureFormat.RGBAFloat, request => {
                plane.completed = true; plane.hasError = request.hasError; callback(request);
            }), request => {
                var data = request.GetData<Vector4>().ToArray(); Need(data.Length == plane.width * plane.height, "Unexpected plane length.");
                capture.planeData[planeIndex] = data;
            });
        }
        var metadata = Buffer("metadataBuffer"); var anchors = Buffer("anchorsBuffer");
        Need(metadata.stride == 128 && anchors.stride == 8, "Product buffer ABI changed.");
        capture.row.metadataCount = metadata.count; capture.row.anchorsCount = anchors.count;
        Request(capture, callback => AsyncGPUReadback.Request(metadata, request => {
            capture.row.metadataCompleted = true; capture.row.metadataError = request.hasError; callback(request);
        }), request => {
            capture.metadata = request.GetData<GpuCard>().ToArray(); Need(capture.metadata.Length == capture.row.metadataCount, "Metadata length.");
        });
        Request(capture, callback => AsyncGPUReadback.Request(anchors, request => {
            capture.row.anchorsCompleted = true; capture.row.anchorsError = request.hasError; callback(request);
        }), request => {
            capture.anchors = request.GetData<Vector2Int>().ToArray(); Need(capture.anchors.Length == capture.row.anchorsCount, "Anchor length.");
        });
        result.order.Add(capture.row.name + ":five-readbacks-requested");
    }
    public static void Run()
    {
        var args = Environment.GetCommandLineArgs(); int at = Array.IndexOf(args, "-cardReuseOutput");
        Need(at >= 0 && at + 1 < args.Length, "Missing -cardReuseOutput."); output = args[at + 1];
        Need(Path.IsPathRooted(output) && !Directory.Exists(output) && !File.Exists(output), "Fresh absolute output required.");
        Directory.CreateDirectory(output);
        result = new Result { unity = Application.unityVersion, processId = System.Diagnostics.Process.GetCurrentProcess().Id,
            device = SystemInfo.graphicsDeviceName, api = SystemInfo.graphicsDeviceType.ToString(), colorSpace = QualitySettings.activeColorSpace.ToString(),
            qualityMsaa = QualitySettings.antiAliasing, uvStartsAtTop = SystemInfo.graphicsUVStartsAtTop,
            invertCullingBefore = GL.invertCulling, alphaToMaskAvailableBefore = Shader.GetGlobalFloat("_AlphaToMaskAvailable") };
        start = EditorApplication.timeSinceStartup; submitting = true; EditorApplication.update += Poll;
        try {
            Need(!EditorApplication.isPlayingOrWillChangePlaymode && SystemInfo.supportsComputeShaders && SystemInfo.supportsAsyncGPUReadback &&
                SystemInfo.supportsGraphicsFence && SystemInfo.graphicsDeviceType == GraphicsDeviceType.Direct3D12 && BitConverter.IsLittleEndian,
                "Expected idle little-endian DX12 Editor with compute/readback/fence support.");
            Need(Marshal.SizeOf<GpuCard>() == 128 && Marshal.SizeOf<Vector2Int>() == 8, "Observer ABI differs.");
            prior = EditorSceneManager.GetSceneManagerSetup(); originalEmpty = prior.Length == 0;
            for (int i = 0; i < SceneManager.sceneCount; i++) {
                var s = SceneManager.GetSceneAt(i); Need(!s.isDirty, "Save existing scene edits before observation.");
                if (string.IsNullOrEmpty(s.path)) { Need(SceneManager.sceneCount == 1 && s.rootCount == 0, "Cannot replace unnamed nonempty scene."); originalEmpty = true; }
            }
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single); changedScene = true;
            GL.invertCulling = false;
            MakeAssets("A", false); MakeAssets("B", true); AssetDatabase.SaveAssets();
            aObject = MakeObject("A", Vector3.zero); bObject = MakeObject("B", new Vector3(3, 0, 1));
            aObject.SetActive(true); bObject.SetActive(false);
            scene = new HybridLumenGIScene(); cards = new HybridLumenGISurfaceCache();
            var a = Submit("A", aObject); ReadPhase(a);
            // No synchronous GetData/WaitForCompletion and no deferred A command execution.
            aObject.SetActive(false); bObject.SetActive(true);
            result.aPendingCountBeforeB = a.tickets.Count(t => t.requested && !t.request.done);
            result.aReadbacksPendingBeforeB = result.aPendingCountBeforeB != 0;
            result.order.Add("A-disabled:B-enabled:A-pending-sampled");
            var b = Submit("B", bObject); ReadPhase(b);
            result.staleABindingAfterB = GetBinding(a.row.ownerSlot, aObject.GetComponent<MeshFilter>().sharedMesh, 0);
        } catch (Exception e) { Fail(e); }
        finally { submitting = false; }
    }
    static void Poll()
    {
        if (finished || submitting) return;
        bool terminal = !result.uncertainSubmission;
        foreach (var capture in captures) {
            if (capture.row.submitted) {
                try { capture.row.fencePassed = capture.fence.passed; }
                catch (Exception e) { if (!capture.fenceReadFailed) Fail(e); capture.fenceReadFailed = true; terminal = false; }
                terminal &= capture.row.fencePassed;
            }
            terminal &= capture.tickets.All(t => !t.requested || t.completed);
        }
        if (!terminal) {
            if (!checkpointWritten && EditorApplication.timeSinceStartup - start >= 300) {
                checkpointWritten = true; Fail(new TimeoutException("GPU ownership has not terminated; resources retained and polling continues. No restart/disposal."));
                File.WriteAllText(Path.Combine(output, "retained-checkpoint.json"), JsonUtility.ToJson(result, true));
            }
            return;
        }
        finished = true; EditorApplication.update -= Poll;
        result.allReadbacksCompleted = result.requestedReadbacks == result.completedReadbacks;
        try {
            foreach (var capture in captures) {
                if (capture.row.atlases != null) for (int i = 0; i < capture.row.atlases.Length; i++)
                    if (capture.row.atlases[i] != null) WriteRaw(capture.row.atlases[i].file, capture.planeData[i]);
                WriteRaw(capture.row.metadataFile, capture.metadata); WriteRaw(capture.row.anchorsFile, capture.anchors);
                capture.row.anchors = capture.anchors;
                if (capture.metadata != null) capture.row.metadata = capture.metadata.Select((m, i) => new CardRow {
                    index = i, worldToCard = Rows(m.worldToCard), atlasRect = m.atlasRect, directionTolerance = m.directionTolerance,
                    stableId = m.stableId, revision = m.revision, generation = m.generation, ready = m.ready, ownerSlot = m.ownerSlot,
                    chartId = m.chartId, layoutGeneration = m.layoutGeneration, flags = m.flags }).ToArray();
            }
            if (result.error.Length == 0 && result.a != null && result.b != null && result.requestedReadbacks == 10 && result.allReadbacksCompleted)
                result.status = "collected";
            else if (result.error.Length == 0) Fail(new InvalidOperationException("Both submitted phases and ten completed readbacks are required."));
        } catch (Exception e) { Fail(e); }
        finally {
            // Only terminal GPU work reaches here. Persistent author assets remain for the runner to archive.
            foreach (var capture in captures) try { capture.command?.Release(); } catch (Exception e) { Fail(e); }
            try { cards?.Dispose(); } catch (Exception e) { Fail(e); }
            try { scene?.Dispose(); } catch (Exception e) { Fail(e); }
            try {
                GL.invertCulling = result.invertCullingBefore;
                if (changedScene) {
                    if (aObject != null) UnityEngine.Object.DestroyImmediate(aObject);
                    if (bObject != null) UnityEngine.Object.DestroyImmediate(bObject);
                    if (originalEmpty) EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                    else EditorSceneManager.RestoreSceneManagerSetup(prior);
                }
                result.invertCullingAfter = GL.invertCulling;
                result.alphaToMaskAvailableAfter = Shader.GetGlobalFloat("_AlphaToMaskAvailable"); result.restored = true;
            } catch (Exception e) { Fail(e); }
            try { File.WriteAllText(Path.Combine(output, "result.json"), JsonUtility.ToJson(result, true)); }
            finally { EditorApplication.Exit(result.status == "collected" && result.restored ? 0 : 1); }
        }
    }
}
