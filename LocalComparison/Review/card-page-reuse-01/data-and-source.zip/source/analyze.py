"""Interpret only the frozen two-source page reuse. No Unity, hashes or solver."""
import argparse
import json
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont


def need(ok, why):
    if not ok:
        raise ValueError(why)


def vec(v, fields):
    return np.array([v[k] for k in fields], dtype=np.float64)


def load(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))


def phase(base, p, index):
    s = p['source']; chart = s['charts'][0]
    need(len(s['charts']) == 1 and chart['sourceSubmesh'] == 0, 'Single source chart required')
    vertices = np.array([vec(v, 'xyz') for v in s['vertices']])
    expected = np.array([[-1,-1,0], [-1,1,0], [1,-1,0]]) if index else np.array([[-1,-1,0], [1,-1,0], [1,1,0], [-1,1,0]])
    need(np.array_equal(vertices, expected) and s['indices'] == ([0,1,2] if index else [0,2,1,0,3,2]), 'Source topology differs')
    need(np.array_equal(np.array([vec(v, 'xyz') for v in s['normals']]), np.tile([0,0,-1], (len(vertices),1))), 'Source normals differ')
    need(np.array_equal(np.array([vec(v, 'xy') for v in s['uv']]), (vertices[:,:2]+1)*.5), 'Source UV differs')
    model = np.array(s['localToWorld']).reshape(4,4); expected_model = np.eye(4)
    if index: expected_model[:3,3] = [3,0,1]
    need(np.array_equal(model, expected_model), 'Source transform differs')
    color = [0,0,1,1] if index else [1,0,0,1]
    need(s['shader'] == 'Universal Render Pipeline/Lit' and np.array_equal(vec(s['baseColor'],'rgba'),color), 'Source shader/color differs')
    need(s['metallic'] == 0 and s['workflow'] == 1 and s['cull'] == 2 and s['alphaClip'] == s['alphaToMask'] == s['surface'] == 0, 'Source material mode differs')
    need(not s['hasPropertyBlock'] and not s['hasBaseMap'] and not s['keywords'] and np.array_equal(vec(s['albedoTint'],'rgba'),[1,1,1,1]), 'Source modifiers differ')
    need(np.all(vec(s['emissionColor'],'rgb') == 0) and np.all(vec(s['emissionOverride'],'rgb') == 0), 'Source emission differs')
    need(p['cardCount'] == p['capturedCards'] == 1 and not p['beforeRecordReady'] and p['beforeRecordReadyCards'] == 0 and p['afterRecordReadyCards'] == 1, 'Capture readiness differs')
    need(p['submitted'] and p['fencePassed'] and p['physicalOwnerSlot'] == p['ownerSlot'], 'Submission/ownership incomplete')
    ci = p['cardIndex']; m = p['metadata'][ci]
    need(m['index'] == ci and m['ready'] == 1 and m['stableId'] == (s['stableId'] & 0xffffffff) and m['revision'] == s['revision'], 'GPU source identity differs')
    need(m['ownerSlot'] == p['ownerSlot'] and m['chartId'] == chart['stableId'] and m['layoutGeneration'] == p['layoutGeneration'] != 0 and m['generation'] == p['captureGeneration'] != 0 and m['flags'] & 1, 'GPU chart/generation differs')
    bindings = p['bindings']
    need(len(bindings) == (1 if index else 2) and [b['primitive'] for b in bindings] == list(range(len(bindings))), 'Binding records incomplete')
    for b in bindings:
        need(b['available'] and b['slot'] == p['ownerSlot'] and b['submesh'] == 0 and b['cardIndex'] == ci and b['chartId'] == chart['stableId'] and b['layoutGeneration'] == m['layoutGeneration'] and b['geometryRevision'] == s['geometryRevision'], 'Actual binding values differ')
    need(p['metadataCompleted'] and p['anchorsCompleted'] and not p['metadataError'] and not p['anchorsError'], 'Buffer readback failed')
    raw = (base/p['metadataFile']).read_bytes()
    need(p['metadataStride'] == 128 and len(raw) == 128*p['metadataCount'], 'Metadata byte layout differs')
    # Unity Matrix4x4 is column-major in native storage; JSON Rows() is row-major.
    raw_m = np.frombuffer(raw, '<f4', 16, ci*128).reshape(4,4).T
    raw_vectors = np.frombuffer(raw, '<f4', 8, ci*128+64)
    raw_ids = np.frombuffer(raw, '<u4', 8, ci*128+96)
    need(np.array_equal(raw_m, np.array(m['worldToCard'],dtype=np.float32).reshape(4,4)) and np.array_equal(raw_vectors, np.r_[vec(m['atlasRect'],'xyzw'),vec(m['directionTolerance'],'xyzw')].astype(np.float32)), 'Metadata JSON/raw mismatch')
    need(np.array_equal(raw_ids, [m[k] for k in ['stableId','revision','generation','ready','ownerSlot','chartId','layoutGeneration','flags']]), 'Metadata integer JSON/raw mismatch')
    projected = np.array(chart['localToCard']).reshape(4,4) @ np.linalg.inv(model)
    need(np.allclose(raw_m, projected, rtol=0, atol=1e-7), 'GPU projection differs from source chart')
    w,h = p['atlasWidth'],p['atlasHeight']; planes = {}
    for t in p['atlases']:
        need(t['requested'] and t['completed'] and not t['hasError'] and t['width'] == w and t['height'] == h and t['format'] == 'rgba32f-le' and t['rowOrder'] == 'native-readback-no-row-flip', 'Atlas readback incomplete')
        planes[t['role']] = np.fromfile(base/t['file'], '<f4').reshape(h,w,4)
    diffuse,position,emission = (planes[k] for k in ['diffuse','position','emissionValidity'])
    # Packed geometric normal is the capture's coverage tag (1..1024).
    # position.w stores projected depth, not a coverage boolean. This is not a
    # claim that all consumer checks (including the unread shading normal) ran.
    tag = emission[:,:,3]
    covered = np.isfinite(tag) & (tag >= 1) & (tag <= 1024) & (tag == np.rint(tag))
    rect = vec(m['atlasRect'],'xyzw'); yy,xx = np.mgrid[:h,:w]
    uv = np.stack(((xx+.5)/w,(yy+.5)/h),-1)
    card_xy = (uv-rect[:2])/rect[2:]
    z = float(index)
    xy = (card_xy-projected[:2,3]-projected[:2,2]*z) @ np.linalg.inv(projected[:2,:2]).T
    local = xy-model[:2,3]
    distances = np.stack((local[:,:,0]+1,local[:,:,1]+1,-(local[:,:,0]+local[:,:,1])/np.sqrt(2)),-1) if index else 1-np.abs(local)
    minimum = np.rint(rect[:2]*[w,h]).astype(int); count = np.rint(rect[2:]*[w,h]).astype(int)
    tile = (xx>=minimum[0]) & (xx<minimum[0]+count[0]) & (yy>=minimum[1]) & (yy<minimum[1]+count[1])
    inside = tile & (distances.min(-1)>1e-5)
    outside = ~tile | (distances.min(-1)<-1e-5)
    need(inside.any() and covered.any(), 'No interior/capture')
    expected_pos = np.concatenate((xy,np.full((h,w,1),z)),-1)
    poserr = float(np.abs(position[:,:,:3][covered].astype(float)-expected_pos[covered]).max())
    colerr = float(np.abs(diffuse[:,:,:3][covered].astype(float)-np.array(color[:3])*.96).max())
    emissionerr = float(np.abs(emission[:,:,:3][covered]).max())
    actual_local = position[:,:,:2].astype(float)-model[:2,3]
    actual_dist = np.stack((actual_local[:,:,0]+1,actual_local[:,:,1]+1,-actual_local.sum(-1)/np.sqrt(2)),-1) if index else 1-np.abs(actual_local)
    covered_finite = np.isfinite(position[covered]).all() and np.isfinite(diffuse[covered]).all() and np.isfinite(emission[covered]).all()
    missed = int(np.sum(inside & ~covered)); leaked = int(np.sum(outside & covered))
    valid_shape = bool(np.all(actual_dist[covered] >= -2e-5))
    position_depth = bool(np.all((position[:,:,3][covered]>=0)&(position[:,:,3][covered]<=1)))
    anchors = np.fromfile(base/p['anchorsFile'], '<i4').reshape(-1,2)
    need(p['anchorsStride'] == 8 and len(anchors) == p['anchorsCount'] and np.array_equal(anchors,np.array([vec(v,'xy') for v in p['anchors']])), 'Anchor JSON/raw mismatch')
    cells = []
    for cy in range(4):
        for cx in range(4):
            lo = minimum+np.array([cx,cy])*count//4; hi = minimum+(np.array([cx,cy])+1)*count//4
            cell = (xx>=lo[0])&(xx<hi[0])&(yy>=lo[1])&(yy<hi[1])
            occupied = bool(np.any(cell&inside)); empty = bool(np.all(outside[cell]))
            a = anchors[ci*16+cy*4+cx]; anchor_valid = bool(np.all(a>=lo)&np.all(a<hi))
            if anchor_valid: anchor_valid = bool(covered[a[1],a[0]])
            ok = anchor_valid if occupied else bool(np.all(a==-1)) if empty else bool(np.all(a==-1) or anchor_valid)
            cells.append({'cell':[cx,cy],'expected':'occupied' if occupied else 'empty' if empty else 'boundary-only','anchor':a.tolist(),'anchorValid':anchor_valid,'passed':ok})
    passed = bool(covered_finite and position_depth and valid_shape and missed==leaked==0 and poserr<=2e-5 and colerr<=2/255 and emissionerr==0 and np.all(np.abs(diffuse[:,:,3][covered]-1)<=1/255) and all(c['passed'] for c in cells))
    row = {'phase':p['name'],'sourceStableId':s['stableId'],'cardIndex':ci,'ownerSlot':p['ownerSlot'],'layoutGeneration':m['layoutGeneration'],'captureGeneration':m['generation'],'actualBindings':bindings,'coveredTexels':int(covered.sum()),'strictInteriorTexels':int(inside.sum()),'missedInterior':missed,'leakedExterior':leaked,'positionMaxError':poserr,'diffuseMaxError':colerr,'emissionMaxAbs':emissionerr,'coveredBelongsToSource':valid_shape,'cells':cells,'passed':passed}
    return row, {'covered':covered,'inside':inside,'outside':outside,'diffuse':diffuse,'anchors':anchors[ci*16:ci*16+16],'minimum':minimum,'count':count}


def figure(out, phases):
    scale=5; w=64*scale; header=48; row_h=64*scale+40
    canvas=Image.new('RGB',(3*w,header+2*row_h),(242,242,242)); d=ImageDraw.Draw(canvas)
    try: font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',16)
    except OSError: font=ImageFont.load_default()
    for i,t in enumerate(['Source geometry expectation','Captured diffuse / coverage','Actual anchors (green = valid)']): d.text((i*w+8,12),t,fill=(15,15,15),font=font)
    for j,p in enumerate(phases):
        shape=p['covered'].shape; expected=np.zeros((*shape,3),np.uint8)+30; expected[p['inside']]=[180,180,180]; expected[~(p['inside']|p['outside'])]=[100,80,30]
        actual=np.zeros_like(expected)+30; actual[p['covered']]=np.rint(np.clip(p['diffuse'][:,:,:3][p['covered']],0,1)*255).astype(np.uint8)
        for i,pixels in enumerate([expected,actual,actual]):
            pic=Image.fromarray(pixels).resize((w,w),Image.Resampling.NEAREST)
            if i==2:
                q=ImageDraw.Draw(pic); lo=p['minimum']; count=p['count']
                for k in range(5):
                    x=int((lo[0]+k*count[0]//4)*scale); y=int((lo[1]+k*count[1]//4)*scale)
                    q.line((x,lo[1]*scale,x,(lo[1]+count[1])*scale),fill=(180,180,180));q.line((lo[0]*scale,y,(lo[0]+count[0])*scale,y),fill=(180,180,180))
                for a in p['anchors']:
                    if np.all(a>=0):
                        x,y=(a+.5)*scale;q.ellipse((x-3,y-3,x+3,y+3),fill=(0,255,80))
            # Explicit visual-only flip; analysis/raw addresses remain native order.
            canvas.paste(pic.transpose(Image.Transpose.FLIP_TOP_BOTTOM),(i*w,header+j*row_h))
        d.text((8,header+j*row_h+w+8),'A: red square' if j==0 else 'B: translated blue triangle',fill=(15,15,15),font=font)
    canvas.save(out/'comparison.png')


def analyze(base,out):
    r=load(base/'result.json')
    need(r['status']=='collected' and r['restored'] and not r['error'] and r['allReadbacksCompleted'] and r['requestedReadbacks']==r['completedReadbacks']==10 and not r['uncertainSubmission'],'Collection incomplete')
    need(r['api']=='Direct3D12' and r['unity']=='6000.0.85f1' and r['colorSpace']=='Linear' and r['tileResolution']==64 and r['patchGrid']==4 and r['maxResidentCards']==1 and r['capturesPerFrame']==1,'Platform/configuration differs')
    need(r['order']==['A:ExecuteCommandBuffer-returned','A:five-readbacks-requested','A-disabled:B-enabled:A-pending-sampled','B:ExecuteCommandBuffer-returned','B:five-readbacks-requested'],'Actual submission order differs')
    a,b=r['a'],r['b']; rows=[]; pictures=[]
    for i,p in enumerate([a,b]):
        row,picture=phase(base,p,i);rows.append(row);pictures.append(picture)
    same_page=all(a[k]==b[k] for k in ['cardIndex','atlasGeneration','atlasWidth','atlasHeight'])
    same_page &= all(x['role']==y['role'] and x['textureInstanceId']==y['textureInstanceId'] for x,y in zip(a['atlases'],b['atlases']))
    same_page &= a['metadata'][a['cardIndex']]['atlasRect']==b['metadata'][b['cardIndex']]['atlasRect']
    new_identity=a['source']['stableId']!=b['source']['stableId'] and a['layoutGeneration']!=b['layoutGeneration'] and a['captureGeneration']!=b['captureGeneration']
    resets=[x['cell'] for x,y in zip(rows[0]['cells'],rows[1]['cells']) if x['anchorValid'] and y['expected']=='empty' and y['anchor']==[-1,-1]]
    stale_rejected=not r['staleABindingAfterB']['available']
    passed=bool(same_page and new_identity and stale_rejected and resets and all(p['passed'] for p in rows))
    result={'status':'single-page-two-owner-reuse-observed' if passed else 'reuse-contract-not-observed','scope':'One Edit-mode DX12 production SurfaceCache; submitted A square then B triangle, tile64/grid4; no transport, HLOD, arbitrary concurrency or full T4 qualification. Invalid RGB is ignored.','samePhysicalPage':bool(same_page),'differentIdentityAndGenerations':bool(new_identity),'staleABindingRejected':stale_rejected,'aPendingBeforeB':r['aPendingCountBeforeB'],'aToBEmptyAnchorCells':resets,'positionTolerance':2e-5,'diffuseTolerance':2/255,'phases':rows}
    figure(out,pictures)
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('capture',type=Path);p.add_argument('output',type=Path);args=p.parse_args();args.output.mkdir(parents=True,exist_ok=False)
    try: result=analyze(args.capture,args.output)
    except (OSError,ValueError,KeyError,IndexError) as e: result={'status':'insufficient-input-or-record','error':str(e)}
    (args.output/'analysis.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result))
