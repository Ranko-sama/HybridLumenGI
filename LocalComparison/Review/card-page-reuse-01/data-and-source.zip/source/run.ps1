$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
$project=[IO.Path]::GetFullPath('I:/Unity test/Project')
$comparison=[IO.Path]::GetFullPath('I:/Unity test/Comparison')
$owned=[IO.Path]::GetFullPath("$project/Assets/HLGICardReuse132")
$output=[IO.Path]::GetFullPath("$comparison/CardReuse132")
$setup=[IO.Path]::GetFullPath($output+'Setup')
$lastScene="$project/Library/LastSceneManagerSetup.txt"
$quality="$project/ProjectSettings/QualitySettings.asset"
function Idle {
    if(Get-Process Unity,HybridLumenGIPlayer -ErrorAction SilentlyContinue){throw 'Wait for the current Unity/Player to exit; staged files remain owned by a live process.'}
}
Idle
foreach($path in @($owned,"$owned.meta",$output,$setup,
    'I:/Unity test/Logs/CardReuse132.log','I:/Unity test/Logs/CardReuse132-upm.log')){
    if(Test-Path -LiteralPath $path){throw "Preserve existing source/result: $path"}
}
# Only the five direct production inputs; no product deployment, hash or full-tree inventory.
foreach($relative in @(
    'Runtime/HybridLumenGISurfaceCache.cs',
    'Runtime/HybridLumenGISurfaceCharts.cs',
    'Runtime/HybridLumenGIScene.cs',
    'Runtime/Resources/HybridLumenGI/HybridLumenGICardCapture.shader',
    'Runtime/Resources/HybridLumenGI/HybridLumenGISurfaceAnchors.compute'
)){
    $wanted=[IO.File]::ReadAllText("$repo/$relative").Replace([string][char]13,'')
    $installed=[IO.File]::ReadAllText("$project/Assets/HybridLumenGI/$relative").Replace([string][char]13,'')
    if($installed -cne $wanted){throw "Installed source differs from current workspace: $relative"}
}
$hadScene=Test-Path -LiteralPath $lastScene -PathType Leaf
New-Item -ItemType Directory -Path $setup | Out-Null
Copy-Item -LiteralPath $quality -Destination $setup
if($hadScene){Copy-Item -LiteralPath $lastScene -Destination $setup}
$created=$false
try{
    Idle
    New-Item -ItemType Directory -Path $owned | Out-Null
    $created=$true
    New-Item -ItemType Directory -Path "$owned/Editor" | Out-Null
    Copy-Item -LiteralPath "$PSScriptRoot/CardReuse132Editor.cs" -Destination "$owned/Editor"
    # Freeze only the supplied interpretation files; neither is executed by this runner.
    foreach($name in @('contract.md','analyze.py')){
        if(Test-Path -LiteralPath "$PSScriptRoot/$name" -PathType Leaf){Copy-Item -LiteralPath "$PSScriptRoot/$name" -Destination $setup}
    }
    # KeepRunning omits -quit: the Editor entry owns shutdown after the ten real callbacks.
    & 'I:/Unity test/Start-Unity.ps1' -Batch -KeepRunning -ProjectPath $project -LogName CardReuse132 `
        -ExecuteMethod CardReuse132Editor.Run -ExtraArguments @('-cardReuseOutput',$output)
    $code=$LASTEXITCODE
    @{exitCode=$code;project=$project;output=$output;phase='single-editor-card-reuse'} | ConvertTo-Json |
        Set-Content -LiteralPath "$setup/native-exit.json" -Encoding utf8
    if($code -ne 0){throw "Card reuse observation exited $code; preserve first failure."}
    $observed=Get-Content -Raw -LiteralPath "$output/result.json" | ConvertFrom-Json
    if($observed.status -ne 'collected' -or !$observed.restored -or !$observed.allReadbacksCompleted){
        throw "Observation incomplete: $($observed.error)"
    }
    $observed | Select-Object status,restored,requestedReadbacks,completedReadbacks,aReadbacksPendingBeforeB
}finally{
    # Never restore/move resources beneath a live Editor. No timeout kill or retry here.
    Idle
    Copy-Item -LiteralPath "$setup/QualitySettings.asset" -Destination $quality -Force
    if($hadScene){Copy-Item -LiteralPath "$setup/LastSceneManagerSetup.txt" -Destination $lastScene -Force}
    elseif(Test-Path -LiteralPath $lastScene){Move-Item -LiteralPath $lastScene -Destination "$setup/generated-scene-setup.txt"}
    if($created){
        $source=Get-Item -LiteralPath $owned
        $archive=[IO.Path]::GetFullPath("$setup/used-fixture")
        if($source.FullName -ine [IO.Path]::GetFullPath("$project/Assets/HLGICardReuse132") -or
            [IO.Path]::GetDirectoryName($setup) -ine $comparison -or [IO.Path]::GetDirectoryName($archive) -ine $setup -or
            $source.Attributes.HasFlag([IO.FileAttributes]::ReparsePoint) -or
            (Get-ChildItem -LiteralPath $owned -Recurse -Force -Attributes ReparsePoint | Select-Object -First 1) -or
            (Test-Path -LiteralPath $archive) -or (Test-Path -LiteralPath "$archive.meta")){
            throw 'Unexpected observer/archive path; preserve staged files.'
        }
        Move-Item -LiteralPath $source.FullName -Destination $archive
        if(Test-Path -LiteralPath "$owned.meta"){Move-Item -LiteralPath "$owned.meta" -Destination "$archive.meta"}
    }
}
