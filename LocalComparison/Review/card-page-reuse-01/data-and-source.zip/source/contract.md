# 单页图集的换 owner 与部分覆盖

原§8／Validation要求复用页不能把旧owner或anchor当成新使用者的有效数据。125只有首次静态捕获，资源循环只有账目，现有限量去重没有等价原生复用结果。Astra同意这一项有独立价值；不扩HLOD、照明缓存、调度或整个T4，也不因捕获代次已有精度保护而立新bug。

## 固定输入

一个Editor进程、实际D3D12 raster/compute，直接使用产品Scene／SurfaceCharts／SurfaceCache API，不修改产品或新建GPU探针。红A为XY满正方形、顶点±1、z=0，两三角索引0,2,1,0,3,2；蓝B为局部直角三角(-1,-1,0),(-1,1,0),(1,-1,0)，索引0,1,2，平移至(3,0,1)。源法线均-Z，UV=(xy+1)/2，普通Lit白光无关的材质数据：M0／Workflow1／CullBack／AO1、RGB纯红或纯蓝alpha1，无贴图／alpha-test／发光／MPB。用现有Bake／CreateCaptureMesh／SetBakedData生成每源一个chart并保存资产，不声称两进程重开验收。

同一Scene与SurfaceCache，物理card容量1、tile64、grid4、atlas预算1MiB、每次capture1。先只启用A，Prepare／RecordCapture A后必须先Graphics.ExecuteCommandBuffer(A)，立即排入diffuse／position／emission及metadata／anchors共5个实际异步读回，才禁用A、启用B并Prepare／RecordCapture／Execute B及其5个读回。不能在A未提交时改写它依赖的CPU准备数据；不压成一个cmd，也不制造GPU延迟。记录Prepare B时A的请求是否确实仍pending，若已经完成就如实说明。

之后仅等待已提交请求的真实终止；回调先复制原始数据，全部终止后统一落盘、恢复及销毁。300秒仍未终止只写保留所有权checkpoint，不能用观察超时当完成或另起进程。最多两次capture、10个回读，不延长或扩输入。

## 独立采用条件

- 确认A、B用同一物理card、同一atlas尺寸／generation／纹理资源及rect；并非重新分配空atlas后称复用。
- 每phase实际GPU metadata有其来源stableId／revision／owner slot／chart／layout及非零capture generation，ready=1；B代次／layout与A不同。CPU Prepare不能预先把B标ready。
- 每个实际TryGetTriangleBinding的四个uint返回值完整记录并与源及metadata对应，不用available=true代替。B以后用旧slot／A mesh查询应拒绝，不能拿新owner的绑定伪装旧mesh仍有效。
- 投影来源为冻结的chart.localToCard*source.worldToLocal；独立从像素中心／card rect反解源平面。A应在其正方形内部，B应在其平移后的三角内部；位置容差2e-5世界单位，已知diffuse对.96红／蓝最大通道差≤2/255，无发光。
- 严格几何内部（距边界>1e-5）必须有有效位置／材质；严格外部必须无有效覆盖。覆盖取自 emission.a 的已打包几何法线标记（整数1..1024）；position.w是投影深度，不能误当覆盖布尔。边界带不用于精确raster覆盖判断，但任何实际覆盖纹素仍须属于本phase源（含2e-5边界容差），B不能保留A的有效位置／红材质。**无覆盖标记下的残留RGB位模式不作为错误或通过依据。**未直读normal图集，不外推全部consumer资格。
- 独立按源几何与各半开patch cell计算占用；有覆盖cell的anchor须在本cell并指向正确源的有效纹素。确定空cell必须(-1,-1)。只触边而无严格内部的格子单列，不据未知取巧。至少存在一个A曾有效、B确定空的相同cell，其旧anchor必须失效，才关闭旧anchor清除子项。

若来源／页复用／覆盖／绑定／回读不足，按这次事实收束，不改阈值或补采更多形状。结果只证明本单页两源的实际复用，不证明HLOD票据、transport cache消费、任意并发或完整T4；A pending窗口只有实际观察到才可报告。按Astra结果审阅后结束，不发新版本。
