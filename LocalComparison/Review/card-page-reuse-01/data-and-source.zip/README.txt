CardReuse132: one actual DX12 Edit-mode SurfaceCache page reused by two sources.

Full frozen contract DID NOT PASS: A/B position error exceeds the predeclared
2e-5 world-unit tolerance. Actual identity/generation, complete bindings,
independent source coverage and old-anchor reset are finite positive sub-results.
Do not turn the pending-request observation into a general GPU concurrency claim.

Offline replay (Python, numpy and pillow; no Unity/GPU):
  python source/analyze.py raw fresh-replay
fresh-replay must not already exist. Compare analysis.json with delivered analysis.
The geometry expectation comes from frozen source arrays/chart matrices, not
the observed atlas positions/colors. Invalid RGB is ignored. Display is flipped
vertically; numerical analysis keeps native readback row order.

raw/: original result.json and ten native readback payloads.
source/: observer/runner, pre-run contract and offline interpreter.
assets/: only this observer's saved source/chart/capture/material assets.
record/: terminal process exit record. No whole project or public Player build.
The observer uses installed production sources corresponding to Release122;
the five direct production input files were text-compared by the runner before
launch. Original data are at I:/Unity test/Comparison/CardReuse132.
