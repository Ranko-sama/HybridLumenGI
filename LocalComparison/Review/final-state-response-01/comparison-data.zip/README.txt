This is the one fixed Final HDR response comparison, not a new product build.
Run with Python/NumPy: python analyze.py GreenToBlue BlueFromStart <fresh-output-directory>
Only the three baseline roles consumed by analysis are bundled; the complete native capture remains in the recorded local outputs.
Two retained complete Final images per lane and all fixed-point/source-frame observations are included.
PreparationFailure had zero render requests; corrected native runs are the first actual pair.
Control is a product output with a longer blue history, not a physical reference.
