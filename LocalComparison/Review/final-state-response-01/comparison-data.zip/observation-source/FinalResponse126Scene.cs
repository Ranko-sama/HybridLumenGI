using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using HybridLumenGI;
using UnityEngine;
using UnityEngine.Rendering;

public sealed class FinalResponse126Scene : MonoBehaviour
{
    public const int Width=960,Height=540,MaxRequests=512;
    const double MinimumSourceInterval=1.0/30.0;
    public Camera targetCamera;
    public RenderPipelineAsset expectedPipeline;
    public HybridLumenGIRendererFeature feature;
    public MeshRenderer wall,floor;
    public BoxCollider panel;
    public Light sourceLight;
    public string outputDirectory,lane,selectionJson;
    public int finalLogical=-1,firstTwoLogical=-1;
    [Serializable] public sealed class Point {public string id;public int[] oldSampledFull,full;}
    [Serializable] public sealed class Selection {public int oldWidth,oldHeight,width,height;public string mapping,rowOrder;public Point[] points;}
    [Serializable] public sealed class Result
    {
        public string status,error,lane,settings,materialGiFlags;
        public string rowOrder="native-top-to-bottom",format="rgba32f-le",clock="Time.realtimeSinceStartupAsDouble";
        public string quantity="Final camera HDR after this complete explicit render request";
        public int width=Width,height=Height,requests,eventAfterLogical=-1,eventEngine=-1,requestedFinalLogical=-1,finalLogical=-1;
        public int requestedFirstTwoLogical=-1,firstTwoLogical=-1;
        public int supportLogical=0,preEventLogical=119,supportWorkFrame=-1,supportEngineFrame=-1,earlyEngineGap=-1;
        public int materialLayerMask,panelLayer,submeshes,pendingReadbacks,completedReadbacks,peakPendingReadbacks;
        public bool readMaterialProperties,readable,forceRenderingOff,hasSdf,hasCharts,emissionKeyword;
        public bool baselineDrained,preEventReadbackCompleted,readbacksDrained,uvStartsAtTop;
        public Vector4 sharedEmission,baseColor;
        public Vector3 panelPosition,panelCenter,panelSize,cameraPosition;
        public Quaternion cameraRotation;
        public double eventSeconds=-1,baselineDrainSeconds=-1,lastElapsedSeconds=-1,maxSourceGapAfterEvent;
        public double earlySourceGap=-1;
        public double drainStartSeconds=-1,drainEndSeconds=-1;
        public string baselineDirectory="baseline";
        public Sample baselineSource;
        public HybridLumenGIValidationSourceState.CameraDescriptor baselineCamera;
        public Selection selection;
        public List<Frame> frames=new List<Frame>(MaxRequests);
    }
    [Serializable] public sealed class Sample
    {
        public string phase;
        public int logicalFrame,workFrame,engineFrame,slot,revision,instanceId,cardCount,wallCards,floorCards;
        public uint panelExact,wallExact,floorExact;
        public bool slotBlockEmpty,rendererBlockHasEmission,slotBlockHasEmission;
        public Vector4 rendererBlockEmission,slotBlockEmission,gpuProxyDiffuse,gpuProxyEmission,gpuProxyIdentity;
        public HybridLumenGIRendererFeature.CameraDiagnostics diagnostics;
    }
    [Serializable] public sealed class Frame
    {
        public int logicalFrame,engineFrame,workFrame=-1;
        public double sourceSeconds,elapsedSeconds=-1,previousSourceGap=-1,renderCallEndSeconds,completionSeconds=-1;
        public Vector4 inputEmission;
        public HybridLumenGIRendererFeature.CameraDiagnostics diagnostics;
        public bool response,readbackRequested,readbackCompleted,firstAtTwoSeconds,pairedFirstTwo,terminal;
        public string readbackError,fullFile;
        public Color[] points;
        [NonSerialized] public byte[] fullPixels;
    }
    [Serializable] public sealed class DrainTimeout
    {
        public string status="awaiting-real-readback-termination",clock,error,lane;
        public double startedSeconds,checkpointSeconds,elapsedSeconds;
        public int engineFrame,requests,pendingReadbacks;
        public bool capturePending,retained=true,targetRetained;
    }
    readonly Result result=new Result();
    MeshRenderer board;
    Mesh privateMesh;
    Material privateMaterial;
    RenderTexture target;
    HybridLumenGIValidationCapture.Session capture;
    HybridLumenGIValidationCapture.Ticket ticket;
    RenderPipeline.StandardRequest request;
    MaterialPropertyBlock currentBlock;
    int stableUpdates,pending;
    object previousPipeline;
    double started,lastSourceSeconds=-1;
    bool finished,stopping,firstTwoScheduled,drainTimeoutWritten;
    Color InitialEmission=>lane=="BlueFromStart"?Color.blue:Color.green;
    static readonly int Emission=Shader.PropertyToID("_EmissionColor");
    static void Require(bool value,string reason){if(!value)throw new InvalidOperationException(reason);}
    static object Field(object owner,string name)=>owner.GetType().GetField(name,BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance).GetValue(owner);
    void Start()
    {
        currentBlock=new MaterialPropertyBlock();
        started=Time.realtimeSinceStartupAsDouble;
        try
        {
            Require(lane=="GreenToBlue"||lane=="BlueFromStart","Unknown lane.");
            result.lane=lane;result.requestedFinalLogical=finalLogical;result.requestedFirstTwoLogical=firstTwoLogical;
            result.selection=JsonUtility.FromJson<Selection>(selectionJson);
            Require(result.selection.points.Length==27,"Expected the frozen 27 points.");
            foreach(var point in result.selection.points)
                Require(point.full.Length==2 && point.full[0]>=0 && point.full[0]<Width && point.full[1]>=0 && point.full[1]<Height,"Invalid selected pixel.");
            Require(lane!="BlueFromStart"||(finalLogical>=120&&finalLogical<MaxRequests),"Control requires the event lane's final logical frame.");
            Require(lane!="BlueFromStart"||(firstTwoLogical>=120&&firstTwoLogical<=finalLogical),"Control requires the event lane's first-two-second logical frame.");
            Require(SystemInfo.supportsAsyncGPUReadback,"Async GPU readback required.");
            Require(expectedPipeline!=null,"Private pipeline missing.");
            QualitySettings.renderPipeline=expectedPipeline;
            var p=panel.GetComponent<HybridLumenGIProxy>();board=panel.GetComponent<MeshRenderer>();
            privateMaterial=new Material(board.sharedMaterial);
            var keyword=privateMaterial.shader.keywordSpace.FindKeyword("_EMISSION");
            Require(keyword.isValid,"The panel shader has no declared _EMISSION keyword.");
            privateMaterial.SetColor("_EmissionColor",Color.black);
            privateMaterial.globalIlluminationFlags=MaterialGlobalIlluminationFlags.RealtimeEmissive;
            privateMaterial.EnableKeyword(keyword);
            board.sharedMaterial=privateMaterial;
            result.materialGiFlags=board.sharedMaterial.globalIlluminationFlags.ToString();
            var mf=panel.GetComponent<MeshFilter>();
            privateMesh=Instantiate(mf.sharedMesh);privateMesh.UploadMeshData(true);mf.sharedMesh=privateMesh;board.forceRenderingOff=true;
            var settings=(HybridLumenGIRendererFeature.Settings)Field(feature,"settings");
            result.settings=JsonUtility.ToJson(settings);
            Require(!sourceLight.enabled && !FindObjectsByType<Light>(FindObjectsSortMode.None).Any(l=>l.isActiveAndEnabled) &&
                !wall.sharedMaterial.IsKeywordEnabled("_EMISSION") && !floor.sharedMaterial.IsKeywordEnabled("_EMISSION") &&
                wall.GetComponent<HybridLumenGIProxy>().GetEmissionLinear().maxColorComponent==0 &&
                floor.GetComponent<HybridLumenGIProxy>().GetEmissionLinear().maxColorComponent==0,"Unexpected analytic light or secondary emitter.");
            result.readable=privateMesh.isReadable;result.forceRenderingOff=board.forceRenderingOff;result.submeshes=privateMesh.subMeshCount;
            result.panelLayer=board.gameObject.layer;result.materialLayerMask=settings.materialLayers.value;
            result.hasCharts=p.SurfaceCharts!=null;result.hasSdf=p.MeshSdf!=null;result.readMaterialProperties=(bool)Field(p,"readMaterialProperties");
            result.sharedEmission=board.sharedMaterial.GetColor("_EmissionColor");result.baseColor=board.sharedMaterial.GetColor("_BaseColor");
            result.emissionKeyword=board.sharedMaterial.IsKeywordEnabled("_EMISSION");result.panelPosition=panel.transform.position;
            result.panelCenter=panel.center;result.panelSize=panel.size;result.cameraPosition=targetCamera.transform.position;result.cameraRotation=targetCamera.transform.rotation;
            Require(p.SourceRenderer==board && p.SourceCollider==panel && p.SourceMesh==privateMesh && result.readMaterialProperties &&
                board.sharedMaterials.Length==1 && result.submeshes==1 && !result.readable && result.forceRenderingOff && !result.hasCharts && !result.hasSdf &&
                (result.materialLayerMask&(1<<result.panelLayer))==0 && (result.materialLayerMask&1)!=0 &&
                board.sharedMaterial.shader.name=="Universal Render Pipeline/Lit" && result.emissionKeyword &&
                board.sharedMaterial.globalIlluminationFlags==MaterialGlobalIlluminationFlags.RealtimeEmissive &&
                result.sharedEmission==(Vector4)Color.black && result.baseColor==(Vector4)Color.black && p.EmissionOverride==Color.black &&
                panel.transform.rotation==Quaternion.identity && panel.transform.lossyScale==Vector3.one && result.panelPosition==new Vector3(.25f,0,0),
                "Invalid ordinary single-slot analytic panel source.");
            Physics.SyncTransforms();
            Require((board.bounds.center-panel.bounds.center).sqrMagnitude<1e-10f &&
                (board.bounds.size-panel.bounds.size).sqrMagnitude<1e-10f,"Mesh-renderer and collider bounds differ.");
            var block=new MaterialPropertyBlock();
            block.SetVector("_BaseColor",new Vector4(.5f,.25f,.125f,1));wall.SetPropertyBlock(block);
            block.Clear();block.SetVector("_BaseColor",Vector4.one);floor.SetPropertyBlock(block);
            block.Clear();block.SetVector(Emission,InitialEmission);board.SetPropertyBlock(block);
            RenderSettings.ambientMode=AmbientMode.Flat;RenderSettings.ambientLight=Color.black;RenderSettings.ambientIntensity=0;
            RenderSettings.ambientProbe=new SphericalHarmonicsL2();RenderSettings.reflectionIntensity=0;RenderSettings.skybox=null;
            RenderSettings.fog=false;RenderSettings.sun=null;LightmapSettings.lightmaps=Array.Empty<LightmapData>();
            target=new RenderTexture(Width,Height,24,RenderTextureFormat.ARGBFloat,RenderTextureReadWrite.Linear){antiAliasing=1};
            Require(target.Create()&&!targetCamera.enabled,"Ready target and disabled camera required.");
            targetCamera.targetTexture=target;targetCamera.aspect=Width/(float)Height;
            request=new RenderPipeline.StandardRequest{destination=target};
            capture=HybridLumenGIValidationCapture.Begin(targetCamera,feature,Path.Combine(outputDirectory,"baseline"),1,384L*1024*1024);
        }
        catch(Exception e){Fail(e);}
    }

    Sample ReadUploadedRow(int frame)
    {
        var cameraStates=(IDictionary)Field(Field(feature,"pass"),"cameras");
        var state=cameraStates[targetCamera.GetInstanceID()];
        Require(ReferenceEquals(Field(state,"camera"),targetCamera),"Camera state identity changed.");
        var scene=(HybridLumenGIScene)Field(state,"scene");
        var cards=(HybridLumenGISurfaceCache)Field(state,"surfaceCache");
        var flags=(ComputeBuffer)Field(Field(state,"hardware"),"flagsBuffer");
        var visible=feature.GetDiagnostics().Single(d=>d.camera==targetCamera.name);
        int FindSlot(Component owner)=>Enumerable.Range(0,scene.Capacity).Single(i=>ReferenceEquals(scene.GetProxy(i),owner.GetComponent<HybridLumenGIProxy>()));
        uint Exact(int i){var value=new uint[1];flags.GetData(value,0,i,1);return value[0];}
        int slot=FindSlot(board),ws=FindSlot(wall),fs=FindSlot(floor);
        var gpu=new HybridLumenGIScene.ProxyGpuData[1];scene.Buffer.GetData(gpu,0,slot,1);
        var rb=new MaterialPropertyBlock();var sb=new MaterialPropertyBlock();
        board.GetPropertyBlock(rb);board.GetPropertyBlock(sb,0);
        var row=new Sample {phase="baseline-"+lane,logicalFrame=frame,workFrame=visible.transportRecordedWorkFrame,
            engineFrame=visible.transportRecordedEngineFrame,slot=slot,instanceId=(int)gpu[0].identity.x,revision=(int)gpu[0].identity.y,
            gpuProxyDiffuse=gpu[0].albedo,gpuProxyEmission=gpu[0].emission,gpuProxyIdentity=gpu[0].identity,diagnostics=visible,
            cardCount=cards.GetCardCount(slot),floorCards=cards.GetCardCount(fs),wallCards=cards.GetCardCount(ws),
            panelExact=Exact(slot),floorExact=Exact(fs),wallExact=Exact(ws),rendererBlockEmission=rb.GetVector(Emission),slotBlockEmission=sb.GetVector(Emission),
            rendererBlockHasEmission=rb.HasProperty(Emission),slotBlockHasEmission=sb.HasProperty(Emission),slotBlockEmpty=sb.isEmpty};
        Require(row.gpuProxyIdentity.w==1 && row.instanceId==board.GetComponent<HybridLumenGIProxy>().StableId &&
            row.cardCount==0 && row.floorCards>0 && row.wallCards>0 && row.panelExact==0 && row.wallExact==1 && row.floorExact==1 &&
            visible.hardwareBackend && visible.publishedInstances==3 && visible.hardwareMeshes==2 && visible.hardwareFallbacks==1 &&
            visible.lightSelected==0 && row.workFrame+1==visible.frame &&
            row.rendererBlockHasEmission && row.rendererBlockEmission==(Vector4)InitialEmission &&
            row.slotBlockEmpty && !row.slotBlockHasEmission &&
            row.gpuProxyEmission==(Vector4)InitialEmission,
            "Owner binding, uploaded geometry or observed MPB state differs.");
        return row;
    }
    void Update()
    {
        if(finished)return;
        try{
            double now=Time.realtimeSinceStartupAsDouble;
            if(stopping){
                if(pending!=0 || (capture!=null&&!capture.IsDrained)){
                    if(now-started>=300&&!drainTimeoutWritten)RecordDrainTimeout(now);
                    return;
                }
                Finish();return;
            }
            if(now-started>=300){Fail(new TimeoutException("The fixed 300-second submission watchdog expired."));return;}
            if(result.requests==1 && !result.baselineDrained){
                if(!capture.IsDrained)return;
                Require(ticket!=null&&ticket.Succeeded,"Logical0 support capture failed.");
                result.baselineDrained=true;result.baselineDrainSeconds=now;
            }
            Require(result.requests<MaxRequests,"Fixed 512 source-request limit reached.");
            bool supported=RenderPipeline.SupportsRenderRequest(targetCamera,request);
            if(result.requests==0&&!supported)return;
            Require(supported,"Explicit rendering became unavailable after the source sequence started.");
            var current=RenderPipelineManager.currentPipeline;
            if(result.requests==0){
                if(current==null||!ReferenceEquals(previousPipeline,current)){previousPipeline=current;stableUpdates=0;return;}
                if(++stableUpdates<2)return;
            }
            Require(ReferenceEquals(previousPipeline,current),"Pipeline changed.");
            bool response=result.eventSeconds>=0;
            int logical=result.requests;
            if(logical>=2)Require(Time.frameCount==result.frames[result.frames.Count-1].engineFrame+1,
                "Engine-frame continuity was broken after the permitted logical0 support drain.");
            if(response||logical==119)Require(pending<8,"Eight pending readbacks exhausted; source cadence is not paused.");
            // Wait inside this same Update so HistoryLifecycle sees consecutive
            // engine frames, rather than treating throttle returns as missing renders.
            double remaining=MinimumSourceInterval-(Time.realtimeSinceStartupAsDouble-lastSourceSeconds);
            if(lastSourceSeconds>=0 && remaining>0)
                System.Threading.Thread.Sleep(Math.Min(34,(int)Math.Ceiling(remaining*1000)));
            double sourceSeconds=Time.realtimeSinceStartupAsDouble;
            double elapsed=response?sourceSeconds-result.eventSeconds:-1;
            if(response)Require(elapsed<=3,"Source time exceeded the fixed three-second response bound.");
            bool terminal=response&&(lane=="GreenToBlue"?elapsed>=2.6:logical==finalLogical);
            board.GetPropertyBlock(currentBlock);
            var row=new Frame{logicalFrame=logical,engineFrame=Time.frameCount,sourceSeconds=sourceSeconds,elapsedSeconds=elapsed,
                previousSourceGap=lastSourceSeconds<0?-1:sourceSeconds-lastSourceSeconds,inputEmission=currentBlock.GetVector(Emission),response=response,terminal=terminal};
            if(logical==1){
                result.earlyEngineGap=Time.frameCount-result.frames[0].engineFrame-1;
                result.earlySourceGap=row.previousSourceGap;
            }
            Require(row.inputEmission==(Vector4)(response?Color.blue:InitialEmission),"Unexpected source emission.");
            if(response && lastSourceSeconds>=result.eventSeconds)result.maxSourceGapAfterEvent=Math.Max(result.maxSourceGapAfterEvent,row.previousSourceGap);
            if(response && lastSourceSeconds<result.eventSeconds)result.maxSourceGapAfterEvent=Math.Max(result.maxSourceGapAfterEvent,elapsed);
            if(logical==0)ticket=capture.Request(logical,Time.frameCount);
            result.frames.Add(row);lastSourceSeconds=sourceSeconds;
            RenderPipeline.SubmitRenderRequest(targetCamera,request);row.renderCallEndSeconds=Time.realtimeSinceStartupAsDouble;result.requests++;
            row.diagnostics=feature.GetDiagnostics().Single(d=>d.camera==targetCamera.name);
            row.workFrame=row.diagnostics.transportRecordedWorkFrame;
            if(logical==0){
                result.baselineCamera=ticket.Camera;result.supportWorkFrame=ticket.Result.workFrame;
                result.supportEngineFrame=ticket.Result.engineFrame;
                Require(ticket.Result.logicalFrame==0&&ticket.Camera!=null,"Logical0 capture source differs.");capture.Seal();return;
            }
            if(!response && logical!=119)return;
            Require(row.workFrame==logical && row.diagnostics.transportRecordedEngineFrame==Time.frameCount,"Recorded source frame differs.");
            row.firstAtTwoSeconds=response&&!firstTwoScheduled&&elapsed>=2;
            if(row.firstAtTwoSeconds)firstTwoScheduled=true;
            // Control selects the event lane's fixed source frame, while the
            // existing firstAtTwoSeconds/elapsedSeconds describe its own clock.
            row.pairedFirstTwo=response&&(lane=="GreenToBlue"?row.firstAtTwoSeconds:logical==firstTwoLogical);
            if(row.pairedFirstTwo)result.firstTwoLogical=logical;
            row.readbackRequested=true;pending++;result.peakPendingReadbacks=Math.Max(result.peakPendingReadbacks,pending);
            try{AsyncGPUReadback.Request(target,0,TextureFormat.RGBAFloat,r=>CompleteReadback(row,r));}
            catch{pending--;row.readbackRequested=false;throw;}
            if(logical==119){
                result.baselineSource=ReadUploadedRow(logical);
                Require(result.baselineDrained&&result.baselineSource.engineFrame==Time.frameCount,"Pre-event source qualification differs.");
                if(stopping)return;
                if(lane=="GreenToBlue"){
                    currentBlock.Clear();currentBlock.SetVector(Emission,Color.blue);board.SetPropertyBlock(currentBlock);
                }
                result.eventSeconds=Time.realtimeSinceStartupAsDouble;result.eventAfterLogical=119;result.eventEngine=Time.frameCount;
                return;
            }
            if(terminal){
                if(lane=="GreenToBlue")Require(firstTwoScheduled,"No source frame at or after two seconds.");
                result.finalLogical=logical;result.lastElapsedSeconds=elapsed;stopping=true;
                result.drainStartSeconds=Time.realtimeSinceStartupAsDouble;
            }
        }catch(Exception e){Fail(e);}
    }
    void CompleteReadback(Frame row,AsyncGPUReadbackRequest request)
    {
        row.completionSeconds=Time.realtimeSinceStartupAsDouble;
        try{
            Require(request.done&&!request.hasError,"Final HDR readback failed.");
            var data=request.GetData<Color>();Require(data.Length==Width*Height,"Unexpected Final pixel count.");
            row.points=new Color[result.selection.points.Length];
            for(int i=0;i<row.points.Length;i++){
                var pixel=result.selection.points[i].full;row.points[i]=data[pixel[1]*Width+pixel[0]];
            }
            if(row.pairedFirstTwo||row.terminal){
                row.fullPixels=request.GetData<byte>().ToArray();row.fullFile="final-"+row.logicalFrame.ToString("D4")+".rgba32f";
            }
            row.readbackCompleted=true;result.completedReadbacks++;
            if(row.logicalFrame==119)result.preEventReadbackCompleted=true;
        }catch(Exception e){row.readbackError=e.ToString();Fail(e);}
        finally{pending--;}
    }
    void Fail(Exception error)
    {
        if(string.IsNullOrEmpty(result.error)){result.error=error.ToString();Debug.LogError(result.error);}
        stopping=true;if(result.drainStartSeconds<0)result.drainStartSeconds=Time.realtimeSinceStartupAsDouble;
        capture?.Close("The finite Final response observation failed.");
    }
    void RecordDrainTimeout(double now)
    {
        drainTimeoutWritten=true;
        const string reason="The 300-second bound expired with readbacks still nonterminal; owners remain retained.";
        result.error=string.IsNullOrEmpty(result.error)?reason:result.error+"\n"+reason;
        var checkpoint=new DrainTimeout{clock=result.clock,error=result.error,lane=lane,startedSeconds=started,
            checkpointSeconds=now,elapsedSeconds=now-started,engineFrame=Time.frameCount,requests=result.requests,
            pendingReadbacks=pending,capturePending=capture!=null&&!capture.IsDrained,targetRetained=target!=null};
        Debug.LogError(reason+" Pending Final="+pending+", Capture="+checkpoint.capturePending);
        File.WriteAllText(Path.Combine(outputDirectory,"drain-timeout.json"),JsonUtility.ToJson(checkpoint,true));
    }
    void Finish()
    {
        if(finished)return;
        Require(pending==0&&(capture==null||capture.IsDrained),"Cannot finish or retire owners before readback termination.");
        finished=true;result.pendingReadbacks=pending;result.readbacksDrained=true;
        result.drainEndSeconds=Time.realtimeSinceStartupAsDouble;result.uvStartsAtTop=SystemInfo.graphicsUVStartsAtTop;
        try{
            capture?.Close();
            foreach(var row in result.frames)if(row.fullPixels!=null)File.WriteAllBytes(Path.Combine(outputDirectory,row.fullFile),row.fullPixels);
            if(string.IsNullOrEmpty(result.error)){
                Require(result.baselineDrained&&result.preEventReadbackCompleted&&result.readbacksDrained&&result.finalLogical>=120,"Sequence did not finish.");
                Require(result.firstTwoLogical>=120&&result.firstTwoLogical<=result.finalLogical,"The paired first-two-second source frame was not captured.");
                Require(result.frames.Where(f=>f.response||f.logicalFrame==119).All(f=>f.readbackRequested&&f.readbackCompleted),
                    "A pre-event or response source frame has no completed readback.");
            }
        }catch(Exception e){if(string.IsNullOrEmpty(result.error))result.error=e.ToString();}
        result.status=string.IsNullOrEmpty(result.error)?"collected":"failed";
        File.WriteAllText(Path.Combine(outputDirectory,"scene-result.json"),JsonUtility.ToJson(result,true));
        if(targetCamera)targetCamera.targetTexture=null;
        var oldTarget=target;var oldMesh=privateMesh;var oldMaterial=privateMaterial;
        HybridLumenGIResourceRetirement.Retire(()=>{
            if(oldTarget){oldTarget.Release();Destroy(oldTarget);}if(oldMesh)Destroy(oldMesh);if(oldMaterial)Destroy(oldMaterial);
        });
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying=false;
#endif
    }
}
