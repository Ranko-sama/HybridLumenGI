param([ValidateSet('Original','Corrected')][string]$Attempt='Original')
$ErrorActionPreference='Stop'
$suffix=if($Attempt -eq 'Corrected'){'Corrected'}else{''}
$project='I:/Unity test/Project'
$comparison=[IO.Path]::GetFullPath('I:/Unity test/Comparison')
$owned=[IO.Path]::GetFullPath("$project/Assets/FinalResponse126")
$release='I:/Unity test/Comparison/PortableUnified122/HybridLumenGI-Release122-UnityProject'
$released="$release/Assets/UnifiedRelease74/Generated/Renderer.asset"
$quality="$project/ProjectSettings/QualitySettings.asset"
$lastScene="$project/Library/LastSceneManagerSetup.txt"
function Idle {
    if(Get-Process Unity,HybridLumenGIPlayer -ErrorAction SilentlyContinue){throw 'A render process is active. Preserve staged files.'}
}
Idle
foreach($p in @($owned,"$owned.meta")){
    if(Test-Path -LiteralPath $p){throw "Existing owned input: $p"}
}
foreach($lane in @('GreenToBlue','BlueFromStart')){
    $name="FinalResponse126${lane}${suffix}"
    $setupPath=Join-Path $comparison ($name+'Setup')
    foreach($p in @("$comparison/$name",$setupPath,"I:/Unity test/Logs/$name.log","I:/Unity test/Logs/$name-upm.log")){
        if(Test-Path -LiteralPath $p){throw "Preserve existing input/output: $p"}
    }
}
if(!(Test-Path -LiteralPath $released -PathType Leaf)){throw 'Release122 settings asset is missing.'}
foreach($name in @('HybridLumenGIRendererFeature.cs','HybridLumenGIValidationCapture.cs')){
    $actual=[IO.File]::ReadAllText("$project/Assets/HybridLumenGI/Runtime/$name").Replace([string][char]13,'')
    $expected=[IO.File]::ReadAllText("$release/Assets/HybridLumenGI/Runtime/$name").Replace([string][char]13,'')
    if($actual -cne $expected){throw "Installed camera/capture source differs from Release122: $name"}
}
$eventEndpoint=-1
$eventFirstTwo=-1
foreach($lane in @('GreenToBlue','BlueFromStart')){
    Idle
    $name="FinalResponse126${lane}${suffix}"
    $output=[IO.Path]::GetFullPath("$comparison/$name")
    $record=[IO.Path]::GetFullPath($output+'Setup')
    $hadSetup=Test-Path -LiteralPath $lastScene -PathType Leaf
    New-Item -ItemType Directory -Path $record | Out-Null
    Copy-Item -LiteralPath $quality -Destination $record
    if($hadSetup){Copy-Item -LiteralPath $lastScene -Destination $record}
    Copy-Item -LiteralPath "$PSScriptRoot/selection.json" -Destination $record
    $created=$false
    try{
        New-Item -ItemType Directory -Path $owned | Out-Null
        $created=$true
        New-Item -ItemType Directory -Path "$owned/Editor" | Out-Null
        Copy-Item -LiteralPath "$PSScriptRoot/FinalResponse126Scene.cs","$PSScriptRoot/selection.json" -Destination $owned
        Copy-Item -LiteralPath "$PSScriptRoot/FinalResponse126Editor.cs" -Destination "$owned/Editor"
        Copy-Item -LiteralPath $released -Destination "$owned/Release122Renderer.asset"
        $argsForLane=@('-finalResponseOutput',$output,'-finalResponseLane',$lane)
        if($lane -eq 'BlueFromStart'){
            if($eventEndpoint -lt 120 -or $eventEndpoint -ge 512){throw 'Event endpoint is unavailable.'}
            if($eventFirstTwo -lt 120 -or $eventFirstTwo -gt $eventEndpoint){throw 'Event first-two-second source frame is unavailable.'}
            $argsForLane+=@('-finalResponseEndLogical',[string]$eventEndpoint,'-finalResponseFirstTwoLogical',[string]$eventFirstTwo)
        }
        & 'I:/Unity test/Start-Unity.ps1' -Batch -KeepRunning -ProjectPath $project -LogName $name -ExecuteMethod FinalResponse126Editor.Run -ExtraArguments $argsForLane
        $nativeExit=$LASTEXITCODE
        @{exitCode=$nativeExit;output=$output;lane=$lane;requestedEndLogical=$eventEndpoint;requestedFirstTwoLogical=$eventFirstTwo} | ConvertTo-Json | Set-Content -LiteralPath "$record/native-exit.json" -Encoding utf8
        if($nativeExit -ne 0){throw "$lane exited $nativeExit. Original output retained."}
        $editor=Get-Content -Raw -LiteralPath "$output/editor-result.json" | ConvertFrom-Json
        $observed=Get-Content -Raw -LiteralPath "$output/scene-result.json" | ConvertFrom-Json
        if($editor.status -ne 'collected' -or !$editor.restored -or $observed.status -ne 'collected' -or $observed.lane -ne $lane){
            throw "$lane did not finish and restore."
        }
        if($lane -eq 'GreenToBlue'){$eventEndpoint=[int]$observed.finalLogical;$eventFirstTwo=[int]$observed.firstTwoLogical}
        elseif($observed.finalLogical -ne $eventEndpoint -or $observed.firstTwoLogical -ne $eventFirstTwo){throw 'The paired complete-image source frames differ.'}
    }finally{
        Idle
        Copy-Item -LiteralPath "$record/QualitySettings.asset" -Destination $quality -Force
        if($hadSetup){Copy-Item -LiteralPath "$record/LastSceneManagerSetup.txt" -Destination $lastScene -Force}
        elseif(Test-Path -LiteralPath $lastScene){Move-Item -LiteralPath $lastScene -Destination "$record/generated-scene-setup.txt"}
        if($created){
            $source=Get-Item -LiteralPath $owned
            $destination=[IO.Path]::GetFullPath("$record/used-fixture")
            if($source.FullName -ine [IO.Path]::GetFullPath("$project/Assets/FinalResponse126") -or
                [IO.Path]::GetDirectoryName($record) -ine $comparison -or [IO.Path]::GetDirectoryName($destination) -ine $record -or
                $source.Attributes.HasFlag([IO.FileAttributes]::ReparsePoint) -or
                (Get-ChildItem -LiteralPath $owned -Force -Recurse -Attributes ReparsePoint | Select-Object -First 1)){throw 'Unsafe helper archive path.'}
            Move-Item -LiteralPath $source.FullName -Destination $destination
            if(Test-Path -LiteralPath "$owned.meta"){Move-Item -LiteralPath "$owned.meta" -Destination "$destination.meta"}
        }
    }
}
