One fixed ordinary Win64 Mono DX12 Player material workflow observation.

Recompute (Python + NumPy):
  python source/analyze.py capture replay-output
Output must be a fresh directory.

Original scene-result, source material keywords/map pixels/MPB, actual camera, fixed single source, native build/player exit receipts and the selected original Capture planes are retained unchanged. Full Capture receipts remain unchanged, including paths to unused planes intentionally not bundled. This package replays the reported contract checks, not every unused support plane.

Reference is independent: installed URP17.0.4 SampleMetallicSpecGloss and InitializeBRDFData plus the analytic unit environment D=1. It is not fitted from measured material values. Fixed linear Point/no-mip inputs and six interior domains are defined in source/contract.md, staged before the run.

Executed Host/Editor sources come from the archived actual helper. There was one BuildOptions.None build and one native Player source. No Editor Play or native retry. Build warnings remain in build-result and warnings excerpt. Public Release122 is unchanged.

Scope: empty-world software, ordinary capture/composite only. Spec uniform is the explicit shader-space MPB input, not arbitrary author-color conversion. No world-hit/DXR, alpha/normal/Cull matrix, performance or whole-G1 claim.
