#if UNITY_EDITOR
using System;
using System.IO;
using System.Linq;
using System.Reflection;
using HybridLumenGI;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;

public static class MaterialWorkflow130Editor
{
    const string Root="Assets/HLGIMaterialWorkflow130", ScenePath=Root+"/Grid.unity";
    [Serializable] sealed class Receipt
    {
        public string status="Failed",error,unity,target="StandaloneWindows64",configuration="Release",actualOptions;
        public string output,scene=ScenePath,settingsSource="Release122 portable Pipeline.asset / Renderer.asset";
        public int errors,warnings;public ulong bytes;public bool restored;
    }
    static void Need(bool value,string reason){if(!value)throw new InvalidOperationException(reason);}
    static string Arg(string key){var args=Environment.GetCommandLineArgs();int i=Array.IndexOf(args,key);return i>=0&&i+1<args.Length?args[i+1]:null;}
    static T Asset<T>(string path) where T:UnityEngine.Object
    {var asset=AssetDatabase.LoadAssetAtPath<T>(path);Need(asset!=null,"Missing staged asset: "+path);return asset;}
    static void TextureAsset(string path,byte low)
    {
        var texture=new Texture2D(8,8,TextureFormat.RGBA32,false,true){name=Path.GetFileNameWithoutExtension(path),filterMode=FilterMode.Point,wrapMode=TextureWrapMode.Clamp,anisoLevel=0};
        var pixels=new Color32[64];
        for(int y=0;y<8;y++)for(int x=0;x<8;x++){byte v=x<4?(byte)255:low;pixels[y*8+x]=new Color32(v,v,v,255);}
        texture.SetPixels32(pixels);texture.Apply(false,false);AssetDatabase.CreateAsset(texture,path);
    }
    static Material MaterialAsset(string name,bool specular,bool mapped)
    {
        var shader=Shader.Find("Universal Render Pipeline/Lit");Need(shader!=null,"Stock URP Lit is unavailable.");
        var m=new Material(shader){name=name};m.shaderKeywords=Array.Empty<string>();
        m.SetFloat("_Surface",0);m.SetFloat("_Blend",0);m.SetFloat("_SrcBlend",1);m.SetFloat("_DstBlend",0);
        m.SetFloat("_ZWrite",1);m.SetFloat("_Cull",(float)CullMode.Back);m.SetFloat("_AlphaClip",0);m.SetFloat("_AlphaToMask",0);
        m.SetFloat("_WorkflowMode",specular?0:1);m.SetFloat("_Metallic",.5f);m.SetFloat("_SmoothnessTextureChannel",0);
        m.SetColor("_BaseColor",Color.white);m.SetTexture("_BaseMap",null);m.SetColor("_EmissionColor",Color.black);
        m.SetTexture("_MetallicGlossMap",null);m.SetTexture("_SpecGlossMap",null);m.SetTexture("_OcclusionMap",null);
        m.SetTexture("_BumpMap",null);m.SetTexture("_ParallaxMap",null);m.SetTexture("_DetailMask",null);
        m.SetTexture("_DetailAlbedoMap",null);m.SetTexture("_DetailNormalMap",null);m.SetFloat("_OcclusionStrength",1);
        m.globalIlluminationFlags=MaterialGlobalIlluminationFlags.EmissiveIsBlack;m.renderQueue=(int)RenderQueue.Geometry;
        if(specular)m.EnableKeyword("_SPECULAR_SETUP");
        if(mapped){m.SetTexture(specular?"_SpecGlossMap":"_MetallicGlossMap",Asset<Texture2D>(Root+(specular?"/SpecMap.asset":"/MetalMap.asset")));m.EnableKeyword("_METALLICSPECGLOSSMAP");}
        AssetDatabase.CreateAsset(m,Root+"/"+name+".mat");return m;
    }
    public static void Build()
    {
        string executable=Arg("-materialWorkflowBuild"),receiptPath=Arg("-materialWorkflowBuildReceipt");
        Need(!string.IsNullOrWhiteSpace(executable)&&Path.IsPathRooted(executable)&&Path.GetExtension(executable).Equals(".exe",StringComparison.OrdinalIgnoreCase),"A fresh absolute executable path is required.");
        Need(!string.IsNullOrWhiteSpace(receiptPath)&&Path.IsPathRooted(receiptPath)&&Directory.Exists(Path.GetDirectoryName(receiptPath))&&!File.Exists(receiptPath),"A fresh build receipt in an existing directory is required.");
        string buildDirectory=Path.GetDirectoryName(Path.GetFullPath(executable));
        Need(!Directory.Exists(buildDirectory)&&!File.Exists(buildDirectory),"Preserve existing build output.");
        Need(!EditorApplication.isPlayingOrWillChangePlaymode,"Build outside Play mode.");
        Need(EditorUserBuildSettings.activeBuildTarget==BuildTarget.StandaloneWindows64&&PlayerSettings.GetScriptingBackend(NamedBuildTarget.Standalone)==ScriptingImplementation.Mono2x,"Existing Win64 Mono project required.");
        Need(PlayerSettings.colorSpace==ColorSpace.Linear&&!PlayerSettings.GetUseDefaultGraphicsAPIs(BuildTarget.StandaloneWindows64)&&
            PlayerSettings.GetGraphicsAPIs(BuildTarget.StandaloneWindows64).SequenceEqual(new[]{GraphicsDeviceType.Direct3D12}),"Existing Linear / explicit D3D12 project required.");
        Need(AssetDatabase.IsValidFolder(Root)&&AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath)==null,"Fresh staged helper root required.");
        var setup=EditorSceneManager.GetSceneManagerSetup();bool empty=setup.Length==0;int unnamed=0;
        for(int i=0;i<SceneManager.sceneCount;i++)
        {
            var s=SceneManager.GetSceneAt(i);Need(!s.isDirty,"Save original dirty scenes first.");
            if(string.IsNullOrEmpty(s.path)){Need(s.isLoaded&&s.rootCount==0,"Unnamed original scene is not empty.");unnamed++;}
        }
        if(empty||unnamed>0){Need(SceneManager.sceneCount==0||(SceneManager.sceneCount==1&&unnamed==1),"Mixed unnamed scene setup cannot be restored.");empty=true;}
        else Need(setup.All(s=>!string.IsNullOrEmpty(s.path))&&setup.Count(s=>s.isActive&&s.isLoaded)==1,"Original scene setup cannot be restored.");
        var oldQuality=QualitySettings.renderPipeline;bool qualityWasNull=oldQuality==null;string qualityPath=AssetDatabase.GetAssetPath(oldQuality);
        Need(qualityWasNull||!string.IsNullOrEmpty(qualityPath),"Original quality override must be saved.");
        var receipt=new Receipt{unity=Application.unityVersion,output=Path.GetFullPath(executable)};
        try
        {
            var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
            TextureAsset(Root+"/MetalMap.asset",128);TextureAsset(Root+"/SpecMap.asset",64);
            var mesh=new Mesh{name="WorkflowQuad"};
            mesh.vertices=new[]{new Vector3(-1.2f,-.65f,0),new Vector3(1.2f,-.65f,0),new Vector3(1.2f,.65f,0),new Vector3(-1.2f,.65f,0)};
            mesh.normals=Enumerable.Repeat(Vector3.back,4).ToArray();mesh.tangents=Enumerable.Repeat(new Vector4(1,0,0,-1),4).ToArray();
            mesh.uv=new[]{Vector2.zero,Vector2.right,Vector2.one,Vector2.up};mesh.triangles=new[]{0,2,1,0,3,2};mesh.RecalculateBounds();
            AssetDatabase.CreateAsset(mesh,Root+"/Quad.asset");
            string[] names={"metalUniform","metalMap","specUniform","specMap"};
            Vector3[] centers={new Vector3(-1.5f,.8f,0),new Vector3(1.5f,.8f,0),new Vector3(-1.5f,-.8f,0),new Vector3(1.5f,-.8f,0)};
            var surfaces=new MeshRenderer[4];
            for(int i=0;i<4;i++)
            {
                var go=new GameObject(names[i]);go.transform.position=centers[i];go.AddComponent<MeshFilter>().sharedMesh=mesh;
                var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterial=MaterialAsset(names[i],i>=2,(i&1)!=0);
                renderer.lightProbeUsage=LightProbeUsage.Off;renderer.reflectionProbeUsage=ReflectionProbeUsage.Off;surfaces[i]=renderer;
            }
            AssetDatabase.SaveAssets();
            // OpenScene/NewScene can unload native assets while managed wrappers remain.
            // Resolve each released pipeline asset only after geometry/material preparation, next to its use.
            var sourceRenderer=Asset<UniversalRendererData>(Root+"/Release122Renderer.asset");
            Need(sourceRenderer.renderingMode==RenderingMode.Forward,"Ordinary Forward renderer required.");
            var published=sourceRenderer.rendererFeatures.OfType<HybridLumenGIRendererFeature>().Single();
            var field=typeof(HybridLumenGIRendererFeature).GetField("settings",BindingFlags.Instance|BindingFlags.NonPublic);
            var settings=JsonUtility.FromJson<HybridLumenGIRendererFeature.Settings>(JsonUtility.ToJson(field.GetValue(published)));
            Need(settings.resolutionScale==.5f&&settings.raysPerPixel==2&&settings.filterIterations==4&&!settings.measureGpuCost&&!settings.adaptiveGpuBudget,"Released quality settings differ.");
            settings.debugView=HybridLumenGIRendererFeature.DebugView.IndirectOnly;settings.environmentRadiance=Color.white;settings.environmentCubemap=null;settings.indirectIntensity=1;
            var rendererData=UnityEngine.Object.Instantiate(sourceRenderer);rendererData.name="MaterialWorkflow130Renderer";rendererData.rendererFeatures.Clear();
            AssetDatabase.CreateAsset(rendererData,Root+"/Renderer.asset");
            var feature=ScriptableObject.CreateInstance<HybridLumenGIRendererFeature>();feature.name="MaterialWorkflow130GI";field.SetValue(feature,settings);
            AssetDatabase.AddObjectToAsset(feature,rendererData);rendererData.rendererFeatures.Add(feature);feature.SetActive(true);
            EditorUtility.SetDirty(rendererData);EditorUtility.SetDirty(feature);
            var sourcePipeline=Asset<UniversalRenderPipelineAsset>(Root+"/Release122Pipeline.asset");
            var pipeline=UnityEngine.Object.Instantiate(sourcePipeline);pipeline.name="MaterialWorkflow130Pipeline";
            pipeline.msaaSampleCount=1;pipeline.supportsHDR=true;pipeline.renderScale=1;pipeline.supportsCameraDepthTexture=true;
            AssetDatabase.CreateAsset(pipeline,Root+"/Pipeline.asset");
            var edit=new SerializedObject(pipeline);var renderers=edit.FindProperty("m_RendererDataList");renderers.arraySize=1;
            renderers.GetArrayElementAtIndex(0).objectReferenceValue=rendererData;edit.FindProperty("m_DefaultRendererIndex").intValue=0;edit.ApplyModifiedPropertiesWithoutUndo();
            RenderSettings.ambientMode=AmbientMode.Flat;RenderSettings.ambientLight=Color.black;RenderSettings.ambientIntensity=0;
            RenderSettings.ambientProbe=new SphericalHarmonicsL2();RenderSettings.reflectionIntensity=0;RenderSettings.skybox=null;RenderSettings.fog=false;RenderSettings.sun=null;
            LightmapSettings.lightmaps=Array.Empty<LightmapData>();
            var camera=new GameObject("Material workflow camera").AddComponent<Camera>();camera.enabled=false;camera.orthographic=true;camera.orthographicSize=1.8f;
            camera.transform.SetPositionAndRotation(new Vector3(0,0,-3),Quaternion.identity);camera.aspect=960f/540;camera.allowHDR=true;camera.allowMSAA=false;camera.allowDynamicResolution=false;
            camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=Color.black;
            var additional=camera.GetUniversalAdditionalCameraData();additional.renderType=CameraRenderType.Base;additional.renderPostProcessing=false;
            additional.requiresDepthOption=CameraOverrideOption.On;additional.requiresColorOption=CameraOverrideOption.On;additional.SetRenderer(0);
            var host=new GameObject("MaterialWorkflow130Host").AddComponent<MaterialWorkflow130Host>();host.targetCamera=camera;host.expectedPipeline=pipeline;host.feature=feature;host.surfaces=surfaces;
            Need(EditorSceneManager.SaveScene(scene,ScenePath),"Fixture scene save failed.");AssetDatabase.SaveAssets();
            QualitySettings.renderPipeline=pipeline;Directory.CreateDirectory(buildDirectory);
            var report=BuildPipeline.BuildPlayer(new BuildPlayerOptions{scenes=new[]{ScenePath},locationPathName=receipt.output,target=BuildTarget.StandaloneWindows64,options=BuildOptions.None});
            receipt.actualOptions=report.summary.options.ToString();receipt.errors=(int)report.summary.totalErrors;receipt.warnings=(int)report.summary.totalWarnings;receipt.bytes=report.summary.totalSize;
            Need(report.summary.result==BuildResult.Succeeded&&report.summary.totalErrors==0,"Player build did not succeed: "+report.summary.result);receipt.status="Succeeded";
        }
        catch(Exception e){receipt.error=e.ToString();}
        finally
        {
            try
            {
                QualitySettings.renderPipeline=qualityWasNull?null:Asset<RenderPipelineAsset>(qualityPath);
                if(empty)EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);else EditorSceneManager.RestoreSceneManagerSetup(setup);
                receipt.restored=true;
            }
            catch(Exception e){receipt.status="Failed";receipt.error+="\nRestore: "+e;}
            File.WriteAllText(receiptPath,JsonUtility.ToJson(receipt,true));
        }
        if(receipt.status!="Succeeded"||!receipt.restored)throw new BuildFailedException(receipt.error??"Fixture build failed.");
    }
}
#endif
