# 普通 Player 的 metallic／specular 工作流与贴图

原 G1／Validation 明列 slider／map 与 metallic／specular 合同。已有51／52固定HLSL结果验证算术，V209验证全金属端点，但不替代实际Unity原材质关键字到普通相机捕获／合成的传递。本次只关闭这项固定网格输入，复用99白炉的单位环境解析参考；无新MC、求解器、验证框架或其他材质矩阵。Astra已同意，并同意只运行普通Win64／Mono／DX12 Player，Editor仅准备和Build，不重复Play。

## 独立期望

依据安装的 URP17.0.4 `Shaders/LitInput.hlsl::SampleMetallicSpecGloss` 和 `ShaderLibrary/BRDF.hlsl::InitializeBRDFData`：map关键字开时读取对应map，不再用slider；SPECULAR_SETUP选择镜面工作流。白底无AO衰减时，metallic rho=.96*(1-M)，specular rho=1-max(S.rgb)。恒定单位入射环境 Li=1 的余弦半球积分 D=E/pi=1，所以间接出射期望独立为 rho。**不以捕获rho反推Final参考。**

四个普通Lit面，按 metalUniform、metalMap、specUniform、specMap 顺序：XY z=0、朝-Z、UV0..1，中心分别(-1.5,.8)/(1.5,.8)/(-1.5,-.8)/(1.5,-.8)，半宽1.2／半高.65。BaseColor白、Metallic=.5、opaque／CullBack，无alpha、normal、detail或emission，AO1。SPECULAR_SETUP在两个spec面开启，数值WorkflowMode相应0／1。specUniform运行时仅用Renderer MPB向量写shader-space SpecColor=(.25,.25,.25,1)，不将作者颜色转换混入该结论。

两张map是8×8 linear RGBA32、Point／Clamp／无mip；每行x0..3为白RGBA255，x4..7的RGB分别为metal128、spec64，alpha255。map两面开启METALLICSPECGLOSSMAP；无map两面关闭。固定六域：

| 域 | GI x起点（含） | GI y起点（含） | 尺寸 | 独立rho／出射RGB各通道 |
| --- | ---: | ---: | --- | ---: |
| metallic uniform .5 | 120 | 187 | 16×16 | .48 |
| metallic map white | 300 | 187 | 16×16 | 0 |
| metallic map 128 | 390 | 187 | 16×16 | .96*(1-128/255)=.4781176471 |
| specular uniform MPB .25 | 120 | 67 | 16×16 | .75 |
| specular map white | 300 | 67 | 16×16 | 0 |
| specular map 64 | 390 | 67 | 16×16 | 1-64/255=.7490196078 |

full像素=(2*GI.x+1,2*GI.y+1)，远离几何、纹理分色及滤波边界。行号采用既有DX12离屏GPU投影／原生回读约定：上表的世界上方metal面对应原生较大y行，不按屏幕截图上下来猜选点。用实际camera矩阵与原生／捕获深度独立验证落在对应源平面及UV域，不按输出选点。

## 实际路径与资格

私有场景／普通Release Player沿用122产品源码与管线质量2ray／filter4／半GI；仅设GI单位环境、intensity1、IndirectOnly。原生ambient／SH／skybox／反射／baked／灯／emission全零。空世界无Proxy，所有逃逸确定，**实际软件空世界路径，不声称世界命中或DXR材质通过**。引导及其他原设置不调参。

相机正交size1.8，位置(0,0,-3)，identity旋转、960×540，HDR、无MSAA／动态分辨率／postprocess，普通Forward Base。仅一次完整 source request；已有 Capture 记录同源材质、有效性、filteredD、深度及合成前后，另读Final HDR。等所有真实读回终止再退出；300秒若仍非终止，写retained checkpoint，不重启或释放未完成资源。单次Build成功不代表材质正确，必须实际Player读回符合以下条件。

- 源Material keywords／workflow／slider、spec MPB shader-space、纹理格式／sampler／像素与上表一致，深度确有覆盖，emissionValidity表示已知材质、AO=1，原生合成前RGB≤1e-6。
- 非零rho域：实际捕获rho各通道绝对差≤1/255；filteredD有有效测量且单位D差≤2/255；Final各通道对独立rho参考绝对差≤2/255。容差覆盖R8材质和half重建链，不是10%总体颜色口径替代。
- 零rho域：覆盖／材质资格仍须成立，捕获rho精确为零、实际Final绝对值≤1e-6。已知零rho不额外要求未必消费的D必须等于1；不能把漏绘或unknown形成的黑色当正确。
- 输出非有限、来源不符、缺读回、runtime错误或失败按实际情况收束，不更换区域、放宽阈值、补跑更多seed或追加其他变体。只有可归因的产品错误才另决定修复。

结果只适用于这一次实际构建后的普通相机捕获／合成配置、上述六域和MPB输入。它不关闭世界hit材质、法线／smoothness-alpha／Cull、任意作者颜色转换、性能／平台或完整G1／G4；不重建公开122或发版。结果后交Astra范围审阅并结束。
