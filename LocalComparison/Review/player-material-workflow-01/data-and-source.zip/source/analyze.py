"""One fixed material-grid Player interpretation, no renderer or reference solver."""
import argparse,json
from pathlib import Path
import numpy as np

def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def need(ok,why):
    if not ok:raise ValueError(why)
def plane(base,item):
    name=item['data']['file'] if 'data' in item else item['file']
    return np.fromfile(base/name,dtype='<f4').reshape(item['height'],item['width'],4)
def rgb(c):return np.array([c[k] for k in 'rgb'])
def analyze(base):
    r=load(base/'scene-result.json');need(r['status']=='collected' and r['requests']==1 and r['captureDrained'] and r['finalCompleted'] and not r['runtimeErrors'],'Runtime capture incomplete')
    need(r['api']=='Direct3D12' and r['unity']=='6000.0.85f1','Platform differs')
    settings=json.loads(r['settings']);need(settings['debugView']==1 and settings['resolutionScale']==.5 and settings['raysPerPixel']==2 and settings['filterIterations']==4 and settings['indirectIntensity']==1 and np.array_equal(rgb(settings['environmentRadiance']),[1,1,1]),'Unit environment/quality differs')
    need(not settings['measureGpuCost'] and not settings['adaptiveGpuBudget'],'Unexpected measurement/feedback')
    d=r['diagnostics'];need(not d['hardwareBackend'] and d['publishedInstances']==0 and d['warmingInstances']==0 and r['work']==0 and d['transportRecordedEngineFrame']==r['engine'],'Not the same empty-world software source')
    sources=r['sources'];need(len(sources)==4,'Source grid differs')
    for i,s in enumerate(sources):
        kw=set(s['keywords']);need(s['shader']=='Universal Render Pipeline/Lit' and s['workflow']==(1 if i<2 else 0) and s['metallic']==.5 and s['cull']==2 and s['alphaClip']==0 and np.array_equal(rgb(s['baseColor']),[1,1,1]),'Source material differs')
        need(('_SPECULAR_SETUP' in kw)==(i>=2) and ('_METALLICSPECGLOSSMAP' in kw)==(i%2==1) and '_ALPHATEST_ON' not in kw and '_EMISSION' not in kw,'Source keyword differs')
        if i==2:need(s['blockHasSpecular'] and np.array_equal([s['blockSpecular'][k] for k in 'xyz'],[.25,.25,.25]),'Specular shader-space MPB differs')
        else:need(s['blockEmpty'],'Unexpected source MPB')
        if i%2:
            t=s['map'];need(t['width']==t['height']==8 and t['mips']==1 and t['format']=='RGBA32' and not t['srgb'] and t['filter']=='Point' and t['wrapU']==t['wrapV']=='Clamp','Source texture state differs')
            actual=np.array([[p[k] for k in 'rgba'] for p in t['pixels']]).reshape(8,8,4);expected=np.full((8,8,4),255);expected[:,4:,:3]=128 if i==1 else 64
            need(np.array_equal(actual,expected),'Source texture input pixels differ')
    folder=base/'capture';c=load(folder/'frame-0000-capture.json')
    need(c['status']=='complete' and c['engineFrame']==r['engine'] and c['workFrame']==r['work'] and c['composite']['debug']==1,'Capture source differs')
    samples={p['signalId']:p for p in c['samples']};support={p['role']:p for p in c['support']}
    native=plane(folder,samples['cameraBeforeHLGI']);need(np.isfinite(native).all() and np.max(abs(native[:,:,:3]))<=1e-6,'Native contribution not black')
    material=plane(folder,support['material']);emission=plane(folder,support['emissionValidity']);depth=plane(folder,support['depth']);capture_depth=plane(folder,support['captureDepth'])
    fd=plane(folder,samples['filteredD']);need(fd.shape==(270,480,4),'Actual GI size differs')
    mask=np.fromfile(folder/samples['filteredD']['validity']['file'],dtype=np.uint8).reshape(270,480)
    final=np.fromfile(base/r['finalFile'],dtype='<f4').reshape(540,960,4)
    camera=r['camera'];need(camera['matrixOrder']=='row-major' and camera['uvOrigin']=='top-left' and camera['clipDepth']=='zero-to-one','Camera conventions differ')
    vp=np.array(camera['projection']).reshape(4,4)@np.array(camera['view']).reshape(4,4);inv=np.linalg.inv(vp)
    domains=[('metalUniform',0,120,187,.48,None),('metalMapWhite',1,300,187,0,(0,.5)),('metalMap128',1,390,187,.96*(1-128/255),(.5,1)),
        ('specUniform',2,120,67,.75,None),('specMapWhite',3,300,67,0,(0,.5)),('specMap64',3,390,67,1-64/255,(.5,1))]
    results=[]
    for name,index,gx0,gy0,expected,urange in domains:
        gx,gy=np.meshgrid(np.arange(gx0,gx0+16),np.arange(gy0,gy0+16));gx=gx.ravel();gy=gy.ravel();x=2*gx+1;y=2*gy+1
        m=material[y,x];e=emission[y,x];z=depth[y,x,0];cz=capture_depth[y,x,0];f=final[y,x,:3];v=fd[gy,gx];valid=np.isfinite(v).all(1)&(v[:,3]>0)&(mask[gy,gx]>0)
        need(np.isfinite(m).all() and np.isfinite(e).all() and np.isfinite(f).all() and np.max(abs(z-cz))<=1e-7 and np.all(abs(e[:,3])>.5) and np.max(abs(e[:,:3]))<=1e-6 and np.max(abs(m[:,3]-1))<=1/255,'Unknown material/AO/geometry at '+name)
        clip=np.c_[(np.c_[x,y]+.5)/[960,540]*2-1,z,np.ones(256)];clip[:,1]*=-1;h=clip@inv.T;xyz=h[:,:3]/h[:,3:]
        cx=-1.5 if index%2==0 else 1.5;cy=.8 if index<2 else -.8;u=(xyz[:,0]-(cx-1.2))/2.4;uvy=(xyz[:,1]-(cy-.65))/1.3
        need(np.isfinite(xyz).all() and np.max(abs(xyz[:,2]))<=.0025 and np.all((u>0)&(u<1)&(uvy>0)&(uvy<1)),'Fixed domain is outside source plane '+name)
        if urange:need(np.all((u>urange[0])&(u<urange[1])),'Wrong source texture domain '+name)
        capture_error=float(np.max(abs(m[:,:3]-expected)));out_error=float(np.max(abs(f-expected)));unit_error=float(np.max(abs(v[:,:3]-1))) if np.isfinite(v).all() else None
        if expected==0:passed=np.all(m[:,:3]==0) and out_error<=1e-6
        else:passed=capture_error<=1/255 and np.all(valid) and unit_error is not None and unit_error<=2/255 and out_error<=2/255
        results.append({'domain':name,'expectedEachChannel':expected,'materialMeanRgb':m[:,:3].mean(0).tolist(),'materialMaxError':capture_error,
            'outgoingMeanRgb':f.mean(0).tolist(),'outgoingMaxError':out_error,'filteredDMeanRgb':v[:,:3].mean(0).tolist(),'filteredUnknown':int(np.sum(~valid)),
            'unitDMaxError':unit_error,'unitDRequired':expected!=0,'worldZMaxError':float(np.max(abs(xyz[:,2]))),'passed':bool(passed)})
    return {'status':'fixed-player-workflow-contract-observed' if all(v['passed'] for v in results) else 'fixed-workflow-target-not-observed',
        'scope':'One private ordinary Win64 Mono DX12 Player, empty-world software, fixed four surfaces and six interior domains; no world-hit/DXR material qualification',
        'nativeMaximumAbsRgb':float(np.max(abs(native[:,:,:3]))),'cameraEngine':r['engine'],'work':r['work'],'domains':results}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('capture',type=Path);p.add_argument('output',type=Path);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
    try:r=analyze(a.capture)
    except (ValueError,KeyError,IndexError,OSError) as e:r={'status':'insufficient-input-or-record','error':str(e)}
    (a.output/'result.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(json.dumps(r))
