import json,sys
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont
base=Path(sys.argv[1]);metrics=json.loads(Path(sys.argv[2]).read_text());out=Path(sys.argv[3])
c=json.loads((base/'capture/frame-0000-capture.json').read_text());item=next(p for p in c['support'] if p['role']=='material')
images=[np.fromfile(base/'capture'/item['file'],dtype='<f4').reshape(540,960,4)[:,:,:3],np.fromfile(base/'final.rgba32f',dtype='<f4').reshape(540,960,4)[:,:,:3]]
canvas=Image.new('RGB',(980,500),(22,22,27));draw=ImageDraw.Draw(canvas)
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',17);small=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',15)
draw.text((10,8),'Private Win64 Player | one source | exposure 1 / Reinhard / sRGB | display flipped vertically',fill='white',font=font)
domains=[(120,187),(300,187),(390,187),(120,67),(300,67),(390,67)]
for i,a in enumerate(images):
    a=np.maximum(a,0);a=a/(1+a);a=np.where(a<=.0031308,a*12.92,1.055*a**(1/2.4)-.055)
    im=Image.fromarray(np.rint(np.clip(np.flipud(a),0,1)*255).astype('uint8')).resize((480,270),Image.Resampling.LANCZOS)
    left=10+480*i;canvas.paste(im,(left,62));draw=ImageDraw.Draw(canvas)
    draw.text((left+4,37),'Captured diffuse reflectance' if i==0 else 'Actual indirect outgoing contribution',fill='white',font=font)
    for j,(x,y) in enumerate(domains):
        x0=left+(2*x+1)/2;y0=62+(539-(2*(y+15)+1))/2
        draw.rectangle((x0,y0,x0+15,y0+15),outline=(50,220,230),width=1);draw.text((x0-1,y0-18),str(j+1),fill=(50,220,230),font=small)
for x,label in [(14,'Domain'),(250,'Expected rho'),(500,'Measured outgoing G'),(750,'Max RGB error')]:
    draw.text((x,347),label,fill=(210,210,210),font=font)
for i,d in enumerate(metrics['domains']):
    draw.text((14,375+19*i),f"{i+1}. {d['domain']}",fill='white',font=small)
    draw.text((250,375+19*i),f"{d['expectedEachChannel']:.5f}",fill='white',font=small)
    draw.text((500,375+19*i),f"{d['outgoingMeanRgb'][1]:.5f}",fill='white',font=small)
    draw.text((750,375+19*i),f"{d['outgoingMaxError']:.6f}",fill=(100,230,160) if d['passed'] else (255,120,120),font=small)
canvas.save(out)
