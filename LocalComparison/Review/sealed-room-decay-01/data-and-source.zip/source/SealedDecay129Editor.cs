#if UNITY_EDITOR
using System;
using System.IO;
using System.Linq;
using System.Reflection;
using HybridLumenGI;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;

[InitializeOnLoad]
public static class SealedDecay129Editor
{
    const string Root="Assets/HLGISealedDecay129", Generated=Root+"/Generated", Key="SealedDecay129.";
    // This saved geometry is retained in the development project, not shipped in the 122 portable ZIP.
    const string SourceScene="Assets/UnifiedRelease74/Generated/Scenes/Run/Validation.unity";
    const string WorkingScene=Generated+"/SealedDecay.unity";
    [Serializable] sealed class RestoreState { public SceneSetup[] scenes; public string qualityPipeline; public bool qualityWasNull,emptyScene; }
    [Serializable] sealed class SceneReceipt { public string status,error; }
    [Serializable] sealed class EditorReceipt
    {
        public string status,error,output,sourceScene=SourceScene,workingScene=WorkingScene;
        public string settingsSource="Release122 portable Pipeline.asset / Renderer.asset";
        public bool restored;
    }
    static SealedDecay129Editor(){EditorApplication.playModeStateChanged+=StateChanged;}
    static void Need(bool value,string reason){if(!value)throw new InvalidOperationException(reason);}
    static string Arg(string key){var args=Environment.GetCommandLineArgs();int i=Array.IndexOf(args,key);return i>=0&&i+1<args.Length?args[i+1]:null;}
    static T[] All<T>(Scene scene) where T:Component => scene.GetRootGameObjects().SelectMany(o=>o.GetComponentsInChildren<T>(true)).ToArray();
    static void StateChanged(PlayModeStateChange state)
    {if(state==PlayModeStateChange.EnteredEditMode&&SessionState.GetBool(Key+"active",false))EditorApplication.delayCall+=Complete;}
    static void Restore()
    {
        var state=JsonUtility.FromJson<RestoreState>(SessionState.GetString(Key+"restore",""));
        Need(state!=null,"Original Editor state is unavailable.");
        QualitySettings.renderPipeline=state.qualityWasNull?null:AssetDatabase.LoadAssetAtPath<RenderPipelineAsset>(state.qualityPipeline);
        Need(state.qualityWasNull||QualitySettings.renderPipeline!=null,"Original quality pipeline is missing.");
        if(state.emptyScene)EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
        else EditorSceneManager.RestoreSceneManagerSetup(state.scenes);
    }
    static void Complete()
    {
        string output=SessionState.GetString(Key+"output","");
        var receipt=new EditorReceipt{status="failed",output=output};
        try
        {
            var scene=JsonUtility.FromJson<SceneReceipt>(File.ReadAllText(Path.Combine(output,"scene-result.json")));
            Need(scene!=null&&scene.status=="collected","Scene observation failed: "+scene?.error);
            receipt.status="collected";
        }
        catch(Exception e){receipt.error=e.ToString();}
        try{Restore();receipt.restored=true;}
        catch(Exception e){receipt.status="failed";receipt.error+="\nRestore: "+e;}
        SessionState.SetBool(Key+"active",false);
        File.WriteAllText(Path.Combine(output,"editor-result.json"),JsonUtility.ToJson(receipt,true));
        EditorApplication.Exit(receipt.status=="collected"&&receipt.restored?0:1);
    }
    public static void Run()
    {
        Need(!EditorApplication.isPlayingOrWillChangePlaymode&&!SessionState.GetBool(Key+"active",false),"An Editor Play session is already active.");
        Need(!EditorSettings.enterPlayModeOptionsEnabled||
            (EditorSettings.enterPlayModeOptions&(EnterPlayModeOptions.DisableDomainReload|EnterPlayModeOptions.DisableSceneReload))==0,
            "The existing sequence requires scene and domain reload.");
        string output=Arg("-sealedDecayOutput");
        Need(!string.IsNullOrEmpty(output)&&Path.IsPathRooted(output)&&!Directory.Exists(output)&&!File.Exists(output),"A fresh absolute -sealedDecayOutput is required.");
        Need(SystemInfo.graphicsDeviceType==GraphicsDeviceType.Direct3D12&&QualitySettings.activeColorSpace==ColorSpace.Linear,"Existing Linear/DX12 project required.");
        Need(AssetDatabase.LoadAssetAtPath<SceneAsset>(SourceScene)!=null,"The saved Validation source scene is missing; do not regenerate it.");
        Need(!AssetDatabase.IsValidFolder(Generated)&&!Directory.Exists(Generated),"Preserve an existing private fixture.");
        var setup=EditorSceneManager.GetSceneManagerSetup();bool empty=setup.Length==0;int unnamed=0;
        for(int i=0;i<SceneManager.sceneCount;i++)
        {
            var existing=SceneManager.GetSceneAt(i);Need(!existing.isDirty,"Save original dirty scenes first.");
            if(string.IsNullOrEmpty(existing.path)){Need(existing.isLoaded&&existing.rootCount==0,"Unnamed original scene is not empty.");unnamed++;}
        }
        if(empty||unnamed>0)
        {Need(SceneManager.sceneCount==0||(SceneManager.sceneCount==1&&unnamed==1),"Mixed unnamed scene setup cannot be restored.");empty=true;}
        else Need(setup.All(s=>!string.IsNullOrEmpty(s.path))&&setup.Count(s=>s.isActive&&s.isLoaded)==1,"Original scene setup cannot be restored.");
        var quality=QualitySettings.renderPipeline;string qualityPath=AssetDatabase.GetAssetPath(quality);
        Need(quality==null||!string.IsNullOrEmpty(qualityPath),"Original quality override must be a saved asset.");
        Directory.CreateDirectory(output);
        SessionState.SetString(Key+"output",output);
        SessionState.SetString(Key+"restore",JsonUtility.ToJson(new RestoreState{scenes=setup,emptyScene=empty,qualityWasNull=quality==null,qualityPipeline=qualityPath}));
        try
        {
            AssetDatabase.CreateFolder(Root,"Generated");
            Need(AssetDatabase.CopyAsset(SourceScene,WorkingScene),"Could not copy the saved source scene.");
            var scene=EditorSceneManager.OpenScene(WorkingScene,OpenSceneMode.Single);
            foreach(var driver in All<HybridLumenGIValidationSequence>(scene))driver.enabled=false;
            foreach(var driver in All<HybridLumenGIValidationMotion>(scene))driver.enabled=false;
            foreach(var driver in All<HybridLumenGIUnifiedSampleInteraction>(scene))driver.enabled=false;
            foreach(var driver in All<HybridLumenGIUnifiedSample>(scene))driver.enabled=false;

            string[] roomNames={"Sealed room back","Sealed room floor","Sealed room front","Sealed room gray receiver","Sealed room left","Sealed room right","Sealed room roof"};
            var room=All<MeshRenderer>(scene).Where(r=>r.name.StartsWith("Sealed room ",StringComparison.Ordinal)).OrderBy(r=>r.name,StringComparer.Ordinal).ToArray();
            Need(room.Select(r=>r.name).SequenceEqual(roomNames),"Saved six-wall/gray-receiver geometry does not match the existing room.");
            foreach(var renderer in All<Renderer>(scene))renderer.enabled=room.Any(r=>r==renderer);
            foreach(var proxy in All<HybridLumenGIProxy>(scene))proxy.enabled=room.Any(r=>proxy.SourceRenderer==r);
            for(int i=0;i<room.Length;i++)
            {
                var renderer=room[i];var proxy=renderer.GetComponent<HybridLumenGIProxy>();
                Need(renderer.gameObject.activeInHierarchy&&proxy!=null&&proxy.isActiveAndEnabled&&proxy.SourceRenderer==renderer&&
                    proxy.SourceMesh!=null&&proxy.MeshSdf!=null&&proxy.MeshSdf.IsValid&&proxy.SurfaceCharts!=null&&proxy.SurfaceCharts.IsValid&&
                    proxy.SurfaceCharts.SourceMesh==proxy.SourceMesh,"Original room source mesh/baked bindings are missing: "+renderer.name);
                var emission=proxy.EmissionOverride;
                Need(emission.r==0&&emission.g==0&&emission.b==0&&!renderer.HasPropertyBlock(),"Unexpected author emission override or property block: "+renderer.name);
                var materials=renderer.sharedMaterials;Need(materials.Length>0,"Missing room material: "+renderer.name);
                for(int slot=0;slot<materials.Length;slot++)
                {
                    var original=materials[slot];
                    Need(original!=null&&original.shader!=null&&original.shader.name=="Universal Render Pipeline/Lit","Room material is not ordinary Lit: "+renderer.name);
                    var clone=new Material(original){name=renderer.name+" material "+slot};
                    clone.DisableKeyword("_EMISSION");clone.SetColor("_EmissionColor",Color.black);
                    AssetDatabase.CreateAsset(clone,Generated+"/Room-"+i+"-"+slot+".mat");materials[slot]=clone;
                }
                renderer.sharedMaterials=materials;
            }
            var light=All<Light>(scene).Single(l=>l.name=="Outside sealed room only");
            Need(light.type==LightType.Point&&light.gameObject.activeInHierarchy,"Original point light is missing or inactive.");
            foreach(var other in All<Light>(scene))other.enabled=false;
            light.transform.position=new Vector3(16,2,-.5f);light.color=Color.green;light.intensity=20;light.range=10;
            light.bounceIntensity=1;light.useColorTemperature=false;light.shadows=LightShadows.Hard;light.enabled=true;
            Need(light.cookie==null&&light.lightmapBakeType==LightmapBakeType.Realtime,"Original point light has unexpected cookie/baked input.");

            // OpenScene can unload native assets even while managed wrappers remain.
            // Resolve these after scene/material preparation, immediately before use.
            var sourceRenderer=AssetDatabase.LoadAssetAtPath<UniversalRendererData>(Root+"/Release122Renderer.asset");
            Need(sourceRenderer!=null,"Staged Release122 renderer is missing.");
            Need(sourceRenderer.renderingMode==RenderingMode.Forward,"The released renderer is not ordinary Forward.");
            var published=sourceRenderer.rendererFeatures.OfType<HybridLumenGIRendererFeature>().Single();
            var field=typeof(HybridLumenGIRendererFeature).GetField("settings",BindingFlags.Instance|BindingFlags.NonPublic);
            var settings=JsonUtility.FromJson<HybridLumenGIRendererFeature.Settings>(JsonUtility.ToJson(field.GetValue(published)));
            Need(settings.resolutionScale==.5f&&settings.raysPerPixel==2&&settings.filterIterations==4&&settings.preferHardwareTracing&&
                settings.temporalAccumulation&&settings.bounceFeedback==1&&!settings.adaptiveGpuBudget&&!settings.measureGpuCost,"Unexpected Release122 quality settings.");
            settings.environmentRadiance=Color.black;settings.environmentCubemap=null;settings.debugView=HybridLumenGIRendererFeature.DebugView.IndirectOnly;
            var rendererData=UnityEngine.Object.Instantiate(sourceRenderer);rendererData.name="SealedDecay129Renderer";rendererData.rendererFeatures.Clear();
            AssetDatabase.CreateAsset(rendererData,Generated+"/Renderer.asset");
            var feature=ScriptableObject.CreateInstance<HybridLumenGIRendererFeature>();feature.name="SealedDecay129GI";field.SetValue(feature,settings);
            AssetDatabase.AddObjectToAsset(feature,rendererData);rendererData.rendererFeatures.Add(feature);feature.SetActive(true);
            EditorUtility.SetDirty(feature);EditorUtility.SetDirty(rendererData);
            var sourcePipeline=AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(Root+"/Release122Pipeline.asset");
            Need(sourcePipeline!=null,"Staged Release122 pipeline is missing.");
            var pipeline=UnityEngine.Object.Instantiate(sourcePipeline);pipeline.name="SealedDecay129Pipeline";
            pipeline.supportsHDR=true;pipeline.msaaSampleCount=1;pipeline.renderScale=1;pipeline.supportsCameraDepthTexture=true;
            AssetDatabase.CreateAsset(pipeline,Generated+"/Pipeline.asset");
            var pipelineEdit=new SerializedObject(pipeline);var renderers=pipelineEdit.FindProperty("m_RendererDataList");renderers.arraySize=1;
            renderers.GetArrayElementAtIndex(0).objectReferenceValue=rendererData;pipelineEdit.FindProperty("m_DefaultRendererIndex").intValue=0;pipelineEdit.ApplyModifiedPropertiesWithoutUndo();

            RenderSettings.ambientMode=AmbientMode.Flat;RenderSettings.ambientLight=Color.black;RenderSettings.ambientIntensity=0;
            RenderSettings.ambientProbe=new SphericalHarmonicsL2();RenderSettings.reflectionIntensity=0;RenderSettings.skybox=null;
            RenderSettings.fog=false;RenderSettings.sun=null;LightmapSettings.lightmaps=Array.Empty<LightmapData>();
            var camera=All<Camera>(scene).Single(c=>c.name=="Validation Camera");
            foreach(var other in All<Camera>(scene))other.enabled=false;
            camera.orthographic=true;camera.orthographicSize=1.8f;camera.transform.SetPositionAndRotation(new Vector3(16,.7f,-2.5f),Quaternion.identity);
            camera.aspect=SealedDecay129Scene.Width/(float)SealedDecay129Scene.Height;camera.allowHDR=true;camera.allowMSAA=false;camera.allowDynamicResolution=false;
            camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=Color.black;camera.targetTexture=null;
            var additional=camera.GetUniversalAdditionalCameraData();additional.renderType=CameraRenderType.Base;additional.renderPostProcessing=false;
            additional.requiresDepthOption=CameraOverrideOption.On;additional.requiresColorOption=CameraOverrideOption.On;additional.SetRenderer(0);
            var host=new GameObject("SealedDecay129Host").AddComponent<SealedDecay129Scene>();
            host.targetCamera=camera;host.expectedPipeline=pipeline;host.feature=feature;host.sourceLight=light;
            host.receiver=room.Single(r=>r.name=="Sealed room gray receiver");host.room=room;host.outputDirectory=output;
            Need(EditorSceneManager.SaveScene(scene,WorkingScene),"Private scene save failed.");AssetDatabase.SaveAssets();
            QualitySettings.renderPipeline=pipeline;SessionState.SetBool(Key+"active",true);
            File.WriteAllText(Path.Combine(output,"editor-prepared.json"),JsonUtility.ToJson(new EditorReceipt{status="prepared",output=output},true));
            EditorApplication.EnterPlaymode();
        }
        catch(Exception e)
        {
            var receipt=new EditorReceipt{status="failed",output=output,error=e.ToString()};
            try{Restore();receipt.restored=true;}catch(Exception restore){receipt.error+="\nRestore: "+restore;}
            SessionState.SetBool(Key+"active",false);
            File.WriteAllText(Path.Combine(output,"editor-result.json"),JsonUtility.ToJson(receipt,true));
            Debug.LogError(receipt.error);EditorApplication.Exit(1);
        }
    }
}
#endif
