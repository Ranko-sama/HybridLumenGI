"""Interpret one frozen existing-room observation; does not render or fit thresholds."""
import argparse,json
from pathlib import Path
import numpy as np

def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def need(ok,message):
    if not ok:raise ValueError(message)
def rgba(rows):return np.array([[c[k] for k in 'rgba'] for c in rows],float)
def plane(folder,item):
    p=item['data']['file'] if 'data' in item else item['file']
    return np.fromfile(folder/p,dtype='<f4').reshape(item['height'],item['width'],4)
def capture(folder,n,camera,pixels,expected,terminal=False):
    r=load(folder/f'frame-{n:04d}-capture.json')
    need(r['status']=='complete' and r['logicalFrame']==n and r['composite']['debug']==1,'Capture source/output invalid')
    samples={p['signalId']:p for p in r['samples']};support={p['role']:p for p in r['support']}
    x,y=pixels.T
    material=plane(folder,support['material'])[y,x,:3]
    need(np.isfinite(material).all() and np.max(abs(material-expected))<=2/255,'Source receiver diffuse differs')
    emission=plane(folder,support['emissionValidity'])[y,x]
    need(np.all(abs(emission[:,3])>.5) and np.max(abs(emission[:,:3]))<=1e-6,'Receiver emission/validity differs')
    depth=plane(folder,support['depth'])[y,x,0];cd=plane(folder,support['captureDepth'])[y,x,0]
    need(np.isfinite(depth).all() and np.max(abs(depth-cd))<=1e-7,'Capture/native geometry depth differs')
    need(camera['matrixOrder']=='row-major' and camera['uvOrigin']=='top-left' and camera['clipDepth']=='zero-to-one','Camera conventions differ')
    vp=np.array(camera['projection']).reshape(4,4)@np.array(camera['view']).reshape(4,4)
    clip=np.c_[(pixels+.5)/[960,540]*2-1,depth,np.ones(9)];clip[:,1]*=-1
    h=clip@np.linalg.inv(vp).T;xyz=h[:,:3]/h[:,3:]
    need(np.isfinite(xyz).all() and np.max(abs(xyz[:,2]-.3))<=.0025 and np.all((xyz[:,0]>15.3)&(xyz[:,0]<16.7)&(xyz[:,1]>0)&(xyz[:,1]<1.4)),'Fixed sample is not inside existing gray receiver front')
    report={'maxDiffuseError':float(np.max(abs(material-expected))),'maxFrontZError':float(np.max(abs(xyz[:,2]-.3))),'worldPoints':xyz.tolist()}
    if terminal:
        p=samples['filteredD'];need((p['width'],p['height'])==(480,270),'GI size differs')
        gi=(pixels-1)//2;gx,gy=gi.T;v=plane(folder,p)[gy,gx]
        mask=np.fromfile(folder/p['validity']['file'],dtype=np.uint8).reshape(270,480)[gy,gx]
        valid=np.isfinite(v).all(1)&(v[:,3]>0)&(mask>0)
        report.update(filteredUnknown=int(np.sum(~valid)),filteredMinAlpha=float(v[:,3].min()),filteredMeanRgb=v[:,:3].mean(0).tolist())
    return r,report

def analyze(base):
    r=load(base/'scene-result.json');editor=load(base/'editor-result.json')
    need(r['status']==editor['status']=='collected' and editor['restored'] and r['drained'] and r['terminalDrained'],'Observation/restoration incomplete')
    settings=json.loads(r['settings']);expected_settings={'resolutionScale':.5,'raysPerPixel':2,'filterIterations':4,'debugView':1}
    need(all(settings[k]==v for k,v in expected_settings.items()) and settings['preferHardwareTracing'] and not settings['adaptiveGpuBudget'] and not settings['measureGpuCost'],'Released quality/input differs')
    env=settings.get('environmentCubemap');need((env is None or isinstance(env,dict) and env.get('instanceID',0)==0) and all(settings['environmentRadiance'][k]==0 for k in 'rgb'),'Continuing environment input')
    pixels=np.array([[p['x'],p['y']] for p in r['points']]);expected_pixels=np.array([[x,y] for y in (225,269,313) for x in (435,479,523)])
    need(np.array_equal(pixels,expected_pixels),'Frozen points differ')
    owners={o['name']:o for o in r['owners']};names={'Sealed room '+n for n in ('floor','roof','left','right','front','back','gray receiver')}
    need(set(owners)==names,'Existing closed room domain differs')
    # Source boxes overlap at the seams; retain numerical inputs, not a generic watertightness claim.
    source_boxes={'floor':((16,-.15,0),(8.3,.3,8.3)),'roof':((16,4.15,0),(8.3,.3,8.3)),
        'left':((12,2,0),(.3,4.3,8.3)),'right':((20,2,0),(.3,4.3,8.3)),
        'front':((16,2,-4),(8.3,4.3,.3)),'back':((16,2,4),(8.3,4.3,.3)),
        'gray receiver':((16,.7,1),(1.4,1.4,1.4))}
    for key,(center,size) in source_boxes.items():
        o=owners['Sealed room '+key];b=o['bounds'];c=np.array([b['m_Center'][k] for k in 'xyz']);e=np.array([b['m_Extents'][k] for k in 'xyz'])
        need(np.max(abs(c-center))<=2e-5 and np.max(abs(2*e-size))<=2e-5 and o['shader']=='Universal Render Pipeline/Lit' and o['charts'] and o['sdf'],'Saved room box/source changed')
        need(all(o['proxyEmission'][k]==0 for k in 'rgb') and '_EMISSION' not in o['keywords'],'Continuing room emitter')
    receiver=owners['Sealed room gray receiver'];need('_SPECULAR_SETUP' not in receiver['keywords'],'Unexpected receiver workflow')
    expected=np.array([receiver['baseColorLinear'][k]*receiver['proxyTintLinear'][k]*.96*(1-receiver['metallic']) for k in 'rgb'])
    need(np.all(expected>0),'Black/metallic receiver cannot establish decay')
    frames=r['frames'];need([f['logical'] for f in frames]==list(range(r['requests'])),'Missing source request')
    need(all(frames[i]['engine']==frames[i-1]['engine']+1 for i in range(2,len(frames))),'Engine f-1 cadence broken')
    need(r['eventLogical']==119 and r['eventEngine']==frames[119]['engine'] and r['eventSeconds']>=frames[119]['renderEnded'],'Event/source ordering differs')
    rows=frames[119:];need(all(f['finalRead'] and f['historyRead'] and not f['error'] and f['work']==f['logical'] and f['diagnostics']['transportRecordedEngineFrame']==f['engine'] for f in rows),'Missing Final/history source')
    need(all(f['diagnostics']['hardwareBackend'] and f['diagnostics']['hardwareMeshes']==7 and f['diagnostics']['hardwareFallbacks']==0 and f['diagnostics']['hardwareMaterialUnknownRecords']==0 and f['diagnostics']['publishedInstances']==7 and f['diagnostics']['lightSelected']==(1 if f['logical']==119 else 0) for f in rows),'Actual source/backend not as declared')
    final=np.array([rgba(f['final']) for f in rows]);history=np.array([rgba(f['history']) for f in rows])
    need(final.shape==history.shape==(len(rows),9,4) and np.isfinite(final).all(),'Readback shape/nonfinite differs')
    need(np.all(final[0,:,1]>1e-4) and np.max(abs(final[0,:,[0,2]]))<=1e-6 and np.all(np.isfinite(history[0])) and np.all(history[0,:,3]>0),'Pre-event indirect energy/validity not established')
    need(rows[0]['lightEnabled'] and all(f['response'] and not f['lightEnabled'] for f in rows[1:]),'Continuing point source')
    t=np.array([f['elapsed'] for f in rows[1:]]);need(np.all(np.diff(t)>0) and 2.6<=t[-1]<=3,'Response window differs')
    for state in ('baselineGpu','terminalGpu'):
        need(len(r[state])==7 and all(o['exact']==1 and o['cards']>0 and o['identity']['w']==1 and all(o['emission'][k]==0 for k in 'xyz') for o in r[state]),'GPU source/representation differs')
    first,source0=capture(base/'support',0,r['supportCamera'],pixels,expected)
    last,source_end=capture(base/'terminal',r['finalLogical'],r['terminalCamera'],pixels,expected,True)
    need(r['supportCamera']==r['terminalCamera'] and last['engineFrame']==frames[-1]['engine'] and last['workFrame']==frames[-1]['work'],'Terminal camera/source changed')
    temporal=np.isfinite(history[1:]).all(2)&(history[1:,:,3]>0);qualified=temporal.all(1)
    ratio=final[1:,:,1].mean(1)/final[0,:,1].mean();perpoint=final[1:,:,1]/final[0,:,1]
    def item(i):return {'logical':int(rows[i+1]['logical']),'seconds':float(t[i]),'oldGreenMeanPercent':float(ratio[i]*100),'oldGreenWorstPointPercent':float(perpoint[i].max()*100),'temporalUnknown':int(np.sum(~temporal[i]))}
    deadlines={}
    for second,limit in ((1,.05),(2,.01)):
        before=np.flatnonzero(t<=second);after=np.flatnonzero(t>=second)
        met=len(before)>0 and qualified[before[-1]] and ratio[before[-1]]<=limit
        held=met and np.all(qualified[before[-1]:]) and np.all(ratio[before[-1]:]<=limit)
        deadlines[str(second)]={'before':item(before[-1]) if len(before) else None,'after':item(after[0]) if len(after) else None,'metBefore':bool(met),'allLaterWithin':bool(held)}
    window=None
    for i in np.flatnonzero(t<=2):
        j=np.searchsorted(t,t[i]+.5)
        if j<len(t) and np.all(qualified[i:j+1]) and np.all(ratio[i:j+1]<=.01) and np.max(np.diff(t[i:j+1]))<=2/30:
            window={'start':float(t[i]),'end':float(t[j]),'span':float(t[j]-t[i])};break
    cadence=float(np.diff(t).max());passed=all(d['metBefore'] and d['allLaterWithin'] for d in deadlines.values()) and window is not None and source_end['filteredUnknown']==0 and cadence<=2/30
    return {'status':'finite-local-decay-target-observed' if passed else 'finite-target-not-observed-or-unqualified',
        'scope':'Existing sealed reflective room, local sole point-light removal; finite 9-point outgoing contribution, not asymptotic proof or global 5s acceptance',
        'baselineMeanGreen':float(final[0,:,1].mean()),'deadlines':deadlines,'firstQualifiedOnePercentWindow':window,
        'last':item(len(t)-1),'temporalUnknownSamples':int(np.sum(~temporal)),'source0':source0,'terminal':source_end,
        'cadenceHz':float((len(t)-1)/(t[-1]-t[0])),'intervalMedian':float(np.median(np.diff(t))),'intervalP95':float(np.quantile(np.diff(t),.95)),'intervalMax':cadence,
        'finalReadbackMedianLatency':float(np.median([f['finalCompleted']-f['sourceSeconds'] for f in rows[1:]])),
        'historyReadbackMedianLatency':float(np.median([f['historyCompleted']-f['sourceSeconds'] for f in rows[1:]])),
        'terminalDrainSeconds':r['drainSeconds'],'peakPending':r['peakPending'],'currentRawFreshness':'not-observed','intermediateFilteredValidity':'not-directly-observed',
        'frames':[item(i) for i in range(len(t))]}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('capture',type=Path);p.add_argument('output',type=Path);a=p.parse_args();a.output.mkdir(exist_ok=False,parents=True)
    try:result=analyze(a.capture)
    except (ValueError,KeyError,IndexError,OSError) as e:result={'status':'insufficient-input-or-record','error':str(e)}
    (a.output/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='frames'},ensure_ascii=False))
