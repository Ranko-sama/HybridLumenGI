using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using HybridLumenGI;
using UnityEngine;
using UnityEngine.Rendering;

public sealed class SealedDecay129Scene : MonoBehaviour
{
    public const int Width=960,Height=540;
    public Camera targetCamera;public RenderPipelineAsset expectedPipeline;
    public HybridLumenGIRendererFeature feature;public Light sourceLight;
    public MeshRenderer receiver;public MeshRenderer[] room;public string outputDirectory;
    static readonly int[] X={435,479,523},Y={225,269,313};
    [Serializable] public sealed class Point {public int x,y,gx,gy;}
    [Serializable] public sealed class Owner {
        public string name,shader;public int stableId,revision,geometryRevision;public Bounds bounds;
        public Matrix4x4 matrix;public Vector3[] vertices;public int[] indices;
        public Color baseColor,baseColorLinear,proxyTint,proxyTintLinear,proxyEmission;public string[] keywords;public float metallic,cull;public bool charts,sdf;
    }
    [Serializable] public sealed class GpuOwner {public string name;public int slot,cards;public uint exact;public Vector4 identity,diffuse,emission;}
    [Serializable] public sealed class Frame {
        public int logical,engine,work=-1,historyIndex=-1;public double sourceSeconds,elapsed=-1,renderEnded,finalCompleted=-1,historyCompleted=-1;
        public bool lightEnabled,response,terminal,atTwo,finalRead,historyRead;
        public string error,fullFile;public Color[] final,history;
        public HybridLumenGIRendererFeature.CameraDiagnostics diagnostics;
        [NonSerialized] public byte[] pixels;
    }
    [Serializable] public sealed class Result {
        public string status="failed",error,settings,device,api,unity;
        public string eventClassification="local point-light removal; the only previously active source; 1s <=5%, 2s <=1%, then >=0.5s retained; not a global 5s test";
        public string quantity="IndirectOnly Final outgoing diffuse contribution; temporal D alpha is valid stored history, not fresh raw validity";
        public int width=Width,height=Height,eventLogical=119,eventEngine=-1,requests,finalLogical=-1,peakPending;
        public double eventSeconds=-1,drainSeconds=-1;public bool uvStartsAtTop,drained,baselineDrained,terminalDrained;
        public Vector3 cameraPosition,lightPosition;public Quaternion cameraRotation;
        public float orthographicSize,lightIntensity,lightRange;public Color lightColor;
        public Point[] points;public Owner[] owners;public GpuOwner[] baselineGpu,terminalGpu;
        public string baselineCapture,terminalCapture;
        public HybridLumenGIValidationSourceState.CameraDescriptor supportCamera,terminalCamera;
        public List<Frame> frames=new List<Frame>(240);
    }
    readonly Result result=new Result();
    HybridLumenGIValidationCapture.Session support,terminalCapture;
    HybridLumenGIValidationCapture.Ticket supportTicket,terminalTicket;
    RenderTexture target;RenderPipeline.StandardRequest request;
    object pipeline;int stable,pending;double started,last=-1,drainStarted=-1;bool stopping,finished,firstTwo,timeoutWritten;
    static object Field(object obj,string name)=>obj.GetType().GetField(name,BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public).GetValue(obj);
    static void Need(bool value,string reason){if(!value)throw new InvalidOperationException(reason);}
    bool Drained=>(support==null||support.IsDrained)&&(terminalCapture==null||terminalCapture.IsDrained);
    object State(){var states=(IDictionary)Field(Field(feature,"pass"),"cameras");return states[targetCamera.GetInstanceID()];}
    void Start(){
        started=Time.realtimeSinceStartupAsDouble;
        try{
            Need(expectedPipeline&&targetCamera&&feature&&sourceLight&&receiver&&room.Length==7,"Missing existing room inputs.");
            QualitySettings.renderPipeline=expectedPipeline;
            Need(sourceLight.enabled&&sourceLight.type==LightType.Point&&sourceLight.color==Color.green&&sourceLight.bounceIntensity==1,"Expected the sole local green point source.");
            Need(FindObjectsByType<Light>(FindObjectsSortMode.None).Count(l=>l.isActiveAndEnabled)==1,"Unexpected active light.");
            var settings=(HybridLumenGIRendererFeature.Settings)Field(feature,"settings");result.settings=JsonUtility.ToJson(settings);
            Need(settings.environmentRadiance==Color.black&&settings.environmentCubemap==null&&settings.debugView==HybridLumenGIRendererFeature.DebugView.IndirectOnly,"Environment/output differs.");
            Need(RenderSettings.ambientIntensity==0&&RenderSettings.reflectionIntensity==0&&RenderSettings.skybox==null&&LightmapSettings.lightmaps.Length==0,"Native ambient/baked/reflection input not zero.");
            result.owners=room.Select(r=>{
                var p=r.GetComponent<HybridLumenGIProxy>();var m=r.sharedMaterial;var mesh=p.SourceMesh;
                Need(p&&p.isActiveAndEnabled&&r.enabled&&mesh&&mesh.isReadable&&m.shader.name=="Universal Render Pipeline/Lit"&&!m.IsKeywordEnabled("_EMISSION")&&p.EmissionOverride==Color.black,"Invalid ordinary room source.");
                return new Owner{name=r.name,shader=m.shader.name,stableId=p.StableId,revision=p.Revision,geometryRevision=p.GeometryContentRevision,
                    bounds=r.bounds,matrix=r.localToWorldMatrix,vertices=mesh.vertices,indices=mesh.triangles,baseColor=m.GetColor("_BaseColor"),
                    baseColorLinear=m.GetColor("_BaseColor").linear,keywords=m.shaderKeywords,metallic=m.GetFloat("_Metallic"),cull=m.GetFloat("_Cull"),
                    proxyTint=p.AlbedoTint,proxyTintLinear=p.AlbedoTint.linear,proxyEmission=p.EmissionOverride,charts=p.SurfaceCharts!=null,sdf=p.MeshSdf!=null};
            }).ToArray();
            Need(HybridLumenGIProxy.ActiveProxies.Count(p=>p.isActiveAndEnabled)==7,"Unexpected active GI owner.");
            result.device=SystemInfo.graphicsDeviceName;result.api=SystemInfo.graphicsDeviceType.ToString();result.unity=Application.unityVersion;
            result.cameraPosition=targetCamera.transform.position;result.cameraRotation=targetCamera.transform.rotation;result.orthographicSize=targetCamera.orthographicSize;
            result.lightPosition=sourceLight.transform.position;result.lightIntensity=sourceLight.intensity;result.lightRange=sourceLight.range;result.lightColor=sourceLight.color;
            result.points=(from y in Y from x in X select new Point{x=x,y=y,gx=(x-1)/2,gy=(y-1)/2}).ToArray();
            Need(SystemInfo.supportsAsyncGPUReadback&&!targetCamera.enabled&&targetCamera.orthographic,"Expected explicit orthographic capture.");
            target=new RenderTexture(Width,Height,24,RenderTextureFormat.ARGBFloat,RenderTextureReadWrite.Linear){antiAliasing=1};Need(target.Create(),"Target allocation failed.");
            targetCamera.targetTexture=target;targetCamera.aspect=Width/(float)Height;request=new RenderPipeline.StandardRequest{destination=target};
            support=HybridLumenGIValidationCapture.Begin(targetCamera,feature,Path.Combine(outputDirectory,"support"),1,384L*1024*1024);
        }catch(Exception ex){Fail(ex);}
    }
    void Update(){
        if(finished)return;
        try{
            double now=Time.realtimeSinceStartupAsDouble;
            if(stopping){
                if(pending!=0||!Drained){
                    if(now-started>=300&&!timeoutWritten){timeoutWritten=true;File.WriteAllText(Path.Combine(outputDirectory,"drain-timeout.json"),JsonUtility.ToJson(new TimeoutReceipt{pending=pending,error=result.error},true));}
                    return;
                }
                Finish();return;
            }
            Need(now-started<300&&result.requests<240,"Fixed observation bound expired.");
            if(result.requests==1&&!result.baselineDrained){if(!support.IsDrained)return;Need(supportTicket.Succeeded,"Initial support capture failed.");result.baselineDrained=true;}
            bool supported=RenderPipeline.SupportsRenderRequest(targetCamera,request);
            if(result.requests==0&&!supported)return;Need(supported,"Render request became unavailable.");
            var current=RenderPipelineManager.currentPipeline;
            if(result.requests==0){if(current==null||!ReferenceEquals(current,pipeline)){pipeline=current;stable=0;return;}if(++stable<2)return;}
            Need(ReferenceEquals(current,pipeline),"Pipeline changed.");
            int logical=result.requests;
            if(logical>=2)Need(Time.frameCount==result.frames.Last().engine+1,"Engine frame continuity broke after the initial support drain.");
            if(last>=0){int sleep=(int)Math.Ceiling((1.0/30-(Time.realtimeSinceStartupAsDouble-last))*1000);if(sleep>0)System.Threading.Thread.Sleep(Math.Min(34,sleep));}
            bool response=result.eventSeconds>=0;now=Time.realtimeSinceStartupAsDouble;double elapsed=response?now-result.eventSeconds:-1;
            bool terminal=response&&elapsed>=2.6;
            Need(!response||elapsed<=3,"Source cadence passed the fixed three-second end bound.");
            Need(sourceLight.enabled==!response,"Source state changed outside the event.");
            if(logical==0)supportTicket=support.Request(logical,Time.frameCount);
            if(terminal){terminalCapture=HybridLumenGIValidationCapture.Begin(targetCamera,feature,Path.Combine(outputDirectory,"terminal"),1,384L*1024*1024);terminalTicket=terminalCapture.Request(logical,Time.frameCount);}
            now=Time.realtimeSinceStartupAsDouble;elapsed=response?now-result.eventSeconds:-1;Need(!response||elapsed<=3,"Terminal capture admission exceeded source bound.");
            var row=new Frame{logical=logical,engine=Time.frameCount,sourceSeconds=now,elapsed=elapsed,response=response,terminal=terminal,lightEnabled=sourceLight.enabled,atTwo=response&&!firstTwo&&elapsed>=2};
            if(row.atTwo)firstTwo=true;
            result.frames.Add(row);last=now;
            RenderPipeline.SubmitRenderRequest(targetCamera,request);row.renderEnded=Time.realtimeSinceStartupAsDouble;result.requests++;
            row.diagnostics=feature.GetDiagnostics().Single(d=>d.camera==targetCamera.name);row.work=row.diagnostics.transportRecordedWorkFrame;
            Need(row.work==logical&&row.diagnostics.transportRecordedEngineFrame==row.engine,"Actual source recording differs.");
            if(logical==0){result.baselineCapture=supportTicket.ReceiptPath;result.supportCamera=supportTicket.Camera;support.Seal();return;}
            if(logical<119)return;
            Need(pending+2<=8,"More than eight pending observations; cadence is not paused.");
            Need(row.diagnostics.hardwareBackend&&row.diagnostics.hardwareMeshes==7&&row.diagnostics.hardwareFallbacks==0&&row.diagnostics.publishedInstances==7,"Unexpected actual backend/geometry.");
            Need(row.diagnostics.lightSelected==(response?0:1)&&row.diagnostics.hardwareMaterialUnknownRecords==0,"Unexpected light count or material unknown.");
            var state=State();int index=(int)Field(state,"readIndex");var history=((RTHandle[])Field(state,"history"))[index].rt;row.historyIndex=index;
            Need((int)Field(state,"frame")==logical+1&&(int)Field(state,"transportRecordedWorkFrame")==logical&&history.width==Width/2&&history.height==Height/2,"History/source association differs.");
            Read(row,target,false);Read(row,history,true);
            if(logical==119){result.baselineGpu=ReadGpu();Need(result.baselineDrained,"Initial support did not drain before event.");sourceLight.enabled=false;result.eventEngine=Time.frameCount;result.eventSeconds=Time.realtimeSinceStartupAsDouble;}
            if(terminal){result.finalLogical=logical;result.terminalCapture=terminalTicket.ReceiptPath;result.terminalCamera=terminalTicket.Camera;terminalCapture.Seal();stopping=true;drainStarted=Time.realtimeSinceStartupAsDouble;}
        }catch(Exception ex){Fail(ex);}
    }
    void Read(Frame row,RenderTexture texture,bool history){
        pending++;result.peakPending=Math.Max(result.peakPending,pending);
        try{AsyncGPUReadback.Request(texture,0,TextureFormat.RGBAFloat,r=>{
            try{
                Need(r.done&&!r.hasError,"Final/history readback failed.");var data=r.GetData<Color>();Need(data.Length==texture.width*texture.height,"Readback shape differs.");
                var samples=new Color[9];for(int i=0;i<9;i++){var p=result.points[i];samples[i]=data[(history?p.gy:p.y)*texture.width+(history?p.gx:p.x)];}
                if(history){row.history=samples;row.historyRead=true;row.historyCompleted=Time.realtimeSinceStartupAsDouble;}
                else{row.final=samples;row.finalRead=true;row.finalCompleted=Time.realtimeSinceStartupAsDouble;
                    if(row.logical==119||row.atTwo||row.terminal){row.pixels=r.GetData<byte>().ToArray();row.fullFile="final-"+row.logical.ToString("D4")+".rgba32f";}}
            }catch(Exception ex){row.error=ex.ToString();Fail(ex);}finally{pending--;}
        });}catch{pending--;throw;}
    }
    GpuOwner[] ReadGpu(){
        var state=State();var scene=(HybridLumenGIScene)Field(state,"scene");var cards=(HybridLumenGISurfaceCache)Field(state,"surfaceCache");var backend=(HybridLumenGIHardwareBackend)Field(state,"hardware");
        var data=new HybridLumenGIScene.ProxyGpuData[scene.Capacity];scene.Buffer.GetData(data);var flagsBuffer=(ComputeBuffer)Field(backend,"flagsBuffer");var flags=new uint[scene.Capacity];flagsBuffer.GetData(flags);
        return room.Select(r=>{
            int slot=Enumerable.Range(0,scene.Capacity).Single(s=>scene.GetRenderer(s)==r);var d=data[slot];
            Need(d.identity.w==1&&flags[slot]==1&&d.emission.x==0&&d.emission.y==0&&d.emission.z==0&&cards.GetCardCount(slot)>0,"GPU room owner/material is not exact, ready or nonemissive.");
            return new GpuOwner{name=r.name,slot=slot,cards=cards.GetCardCount(slot),exact=flags[slot],identity=d.identity,diffuse=d.albedo,emission=d.emission};
        }).ToArray();
    }
    [Serializable] sealed class TimeoutReceipt {public string status="awaiting-real-readback-termination",error;public int pending;public bool ownersRetained=true;}
    void Fail(Exception ex){if(string.IsNullOrEmpty(result.error)){result.error=ex.ToString();Debug.LogError(result.error);}stopping=true;if(drainStarted<0)drainStarted=Time.realtimeSinceStartupAsDouble;support?.Close("Observation failed.");terminalCapture?.Close("Observation failed.");}
    void Finish(){
        if(finished)return;Need(pending==0&&Drained,"Cannot dispose owners while readbacks are pending.");finished=true;
        try{
            result.drained=true;result.drainSeconds=Time.realtimeSinceStartupAsDouble-drainStarted;result.uvStartsAtTop=SystemInfo.graphicsUVStartsAtTop;
            if(string.IsNullOrEmpty(result.error)){
                Need(firstTwo&&terminalTicket!=null&&terminalTicket.Succeeded&&result.frames.Where(f=>f.logical>=119).All(f=>f.finalRead&&f.historyRead),"Incomplete event observations.");
                result.terminalGpu=ReadGpu();result.terminalDrained=terminalCapture.IsDrained;
                Need(!sourceLight.enabled&&!FindObjectsByType<Light>(FindObjectsSortMode.None).Any(l=>l.isActiveAndEnabled),"An actual light remained after event.");
            }
            foreach(var f in result.frames)if(f.pixels!=null)File.WriteAllBytes(Path.Combine(outputDirectory,f.fullFile),f.pixels);
        }catch(Exception ex){if(string.IsNullOrEmpty(result.error))result.error=ex.ToString();}
        support?.Close();terminalCapture?.Close();result.status=string.IsNullOrEmpty(result.error)?"collected":"failed";
        File.WriteAllText(Path.Combine(outputDirectory,"scene-result.json"),JsonUtility.ToJson(result,true));
        if(targetCamera)targetCamera.targetTexture=null;var old=target;HybridLumenGIResourceRetirement.Retire(()=>{if(old){old.Release();Destroy(old);}});
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying=false;
#endif
    }
}
