import json,sys
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont
base=Path(sys.argv[1]);out=Path(sys.argv[2])
r=json.loads((base/'scene-result.json').read_text(encoding='utf-8-sig'))
frames=[r['frames'][119],next(f for f in r['frames'] if f['atTwo']),r['frames'][-1]]
canvas=Image.new('RGB',(1440,340),(20,20,24));draw=ImageDraw.Draw(canvas)
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',18)
small=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',16)
draw.text((12,8),'Existing sealed room | IndirectOnly | exposure 1, Reinhard + sRGB | fixed sample points circled',fill='white',font=font)
for i,f in enumerate(frames):
    a=np.fromfile(base/f['fullFile'],dtype='<f4').reshape(540,960,4)[:,:,:3]
    a=np.maximum(a,0);a=a/(1+a);a=np.where(a<=.0031308,a*12.92,1.055*a**(1/2.4)-.055)
    im=Image.fromarray(np.rint(np.clip(a,0,1)*255).astype('uint8')).resize((480,270),Image.Resampling.LANCZOS)
    canvas.paste(im,(480*i,42));draw=ImageDraw.Draw(canvas)
    for p in r['points']:
        x=480*i+(p['x']+.5)/2;y=42+(p['y']+.5)/2
        draw.ellipse((x-3,y-3,x+3,y+3),outline=(240,240,240),width=1)
    label='Before off, source 119' if i==0 else f"After off, {f['elapsed']:.6f} s"
    draw.text((480*i+12,316),label,fill='white',font=small)
canvas.save(out)
