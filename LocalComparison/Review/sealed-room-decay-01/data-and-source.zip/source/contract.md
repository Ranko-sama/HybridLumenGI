# 封闭反射空间的局部点光关断

本次仅回答原 G1 的一项核心问题：真实封闭、非零反射率空间先有可信非零间接光后，唯一光源关闭时是否消退，而不是把未知当黑。既有黑室一直未被照亮、室外仍有源；127 全源关断是开放棕墙／白地板；两节点函数收缩不含真实房间几何／atlas／gather。Astra 已同意该项有独立采用价值；不新建参考求解器、房间或验证框架。

## 固定输入

- 复用开发工程已保存 `Assets/UnifiedRelease74/Generated/Scenes/Run/Validation.unity` 中七个 `Sealed room ` Renderer：六个相交封闭实心墙体和内部 gray receiver。这个历史保存场景不在 Release122 portable ZIP 中，不能冒称 ZIP 内同版场景。当前产品 API／Renderer settings 沿用 Release122，普通 Lit 材质反射率、几何及原 SDF／charts 保留；只隔离本次房间、清除发光并禁用外部源及交互驱动，不重造几何。
- 当前普通2射线、4级滤波、960×540／半GI、DXR，GPU 计时／预算反馈保持原关闭状态，不调配额；时域累积开启、多跳 feedback=1 保持发行设置。输出为普通 Feature `IndirectOnly` 出射贡献，避免原生直接光消失被算作 GI 快速消退；不是产品默认 Final 展示和普通 Player 验收。
- 原 Point `Outside sealed room only` 移至房内 (16,2,-.5)，纯绿、intensity20、range10、bounceIntensity1，硬阴影。它是唯一活动灯；从开始环境、SH、烘焙、反射和发光均为零。前119帧照亮，119帧渲染结束后禁用该点光，无切镜、材质改变、手工清缓存、epoch重置或其他源切换。
- 该事件按**局部点光移除**分类，采用现有1秒≤5%、2秒≤1%的区域旧光均值目标，并观察2秒后至少0.5秒保持；不改用全局5秒期限放行。黑目标按关断前已知非零绿色归一，不能除以零目标或仅因有限末点未零就称自维持能量。
- 相机正交 size1.8，位置 (16,.7,-2.5)、identity 旋转、朝+Z；固定 full 像素 x=435/479/523，y=225/269/313 的9点，均为半GI中心；预期属于 gray receiver 的正面内部，不按照明值选点。其源盒 bounds x=[15.3,16.7]、y=[0,1.4]、z=[.3,1.7]。同源 Capture0 的 geometry/captureDepth/material 和末端数据独立核对这些归属；若不符，记不足，不改选点。

## 流程与采用资格

一个 Editor Play，逻辑0读取已有 Capture 支持数据并排空；其后逻辑1..119及所有响应源帧逐引擎帧连续，一 Update 一次真实请求，内部最短源间隔1/30秒。源时间用请求前的 realtime 时钟，事件时间在119帧请求结束并关灯之后；回读完成时刻单列。需要相邻引擎帧以维持真实 f-1 历史，不用跳 Update 的方式控速。

119及每个响应源帧实际异步读 Final 和该相机的产品 temporal D，仅保留9点；临时挂起上限8，不等待读回再生成下一源帧。记录 actual engine/work frame、所选后端／灯数和 history slot 对应关系。逻辑119及首个>=2秒、末帧保留整张 Final。首个>=2.6秒响应源帧做一次已有 Capture 末端支持采集后停止提交，源末点不得超过3秒；最多240请求。300秒后若原生读回仍未终止，只写 retained checkpoint，不能冒称已完成或启动新进程。

119帧必须具备 actual DXR、7个精确网格／published owners、无fallback／材质unknown；9点 Final 绿信号均>1e-4，R/B绝对值≤1e-6，temporal D有限且alpha>0。源0和末端实际 capture 的灰接收域材质、位置、有效性必须成立。七个实际GPU proxy行无发光并有卡片，物理源和环境归零；灯表接纳数119为1、响应为0。未知不归入黑或通过。历史alpha只表示有效储存估计，不能当fresh raw资格。

报告完整实际源时刻，分别给截止前／后的残留、最差点及区间保持。若没有1／2秒前样点、来源/采集失败、基线不足、未知或目标失败，按本次事实收束；不延长观察、不自动调权重／清缓存／提高配额或扩反射率矩阵。即使本次通过，也只关闭本房间、这个点光事件、这批固定域的衰减子项，不等于任意房间物理稳态、严格误差证明、G1/G3整体或平台性能放行。结果后交 Astra 采用范围审查。

准备更正附记：第一次 SealedDecay129 在进入Play前失败，保存的Renderer/Pipeline引用跨过OpenScene/资产导入后原生对象被卸载，Instantiate抛MissingReferenceException。原native1、editor-result与入口均保留，未产生房间渲染或能量结论。拟仅将资产加载移到场景及材质准备后紧邻使用，输入/物理量/帧数/阈值不变，使用独占SealedDecay129Corrected；需Astra明确允许一次准备纠正，之后如仍不足按本次事实收束。
