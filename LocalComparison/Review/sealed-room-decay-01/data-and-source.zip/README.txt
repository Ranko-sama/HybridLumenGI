Finite existing sealed-room local-light removal observation.

Original scene-result/editor-result and native exit records are unchanged.
Selected original Capture planes are included for the checks used here; unused plane paths in the unchanged complete capture receipts are intentionally not bundled. This is a compact replay of the stated checks, not a full Capture-session export.

Run (Python + NumPy):
  python source/analyze-corrected.py capture replay-output
The output directory must be fresh.

The frozen first analyzer is also retained. Its first error was the serialized Bounds field name m_Extents rather than Unity m_Extent. The corrected reader uses m_Extent and additionally enforces the already specified zero-source condition against the existing terminal native plane and post-event other channels. No metrics thresholds or sampling were relaxed.

source/contract.md is the contract actually staged for the one corrected native run. source/Editor and Scene are the executed source; the original unrendered preparation failure is in preparation-failure/. Both are observers only, not product edits.

Render source geometry is the already-saved development Validation scene, NOT a scene inside Release122 portable. The private Pipeline and Renderer settings came from portable122. Existing shared room meshes/SDF/charts were referenced, not regenerated. Source mesh vertices/indices, transforms and input materials are in scene-result.json.

Only fixed 9 points are qualified. Temporal alpha is stored validity, not fresh raw; intermediate filtered and world-cache entries were not directly observed. Native cadence is not a Player/Present/GPU-cost measurement. No asymptotic or arbitrary-room energy claim.
