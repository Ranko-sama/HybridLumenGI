$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
$project=[IO.Path]::GetFullPath('I:/Unity test/Project')
$comparison=[IO.Path]::GetFullPath('I:/Unity test/Comparison')
$owned=[IO.Path]::GetFullPath("$project/Assets/HLGIBinaryCoverage128")
$name='BinaryCoverage128Corrected'
$output=[IO.Path]::GetFullPath("$comparison/$name")
$setup=[IO.Path]::GetFullPath($output+'Setup')
$lastScene="$project/Library/LastSceneManagerSetup.txt"
function Idle {
    if(Get-Process Unity,HybridLumenGIPlayer -ErrorAction SilentlyContinue){throw 'A Unity/Player process is active. Preserve inputs.'}
}
Idle
foreach($path in @($owned,"$owned.meta",$output,$setup,"I:/Unity test/Logs/$name.log","I:/Unity test/Logs/$name-upm.log")){
    if(Test-Path -LiteralPath $path){throw "Preserve existing input/output: $path"}
}
# Confirm the APIs/traversal used by this observation are the accepted workspace
# source, rather than the withdrawn pending-page experiment. No product install.
foreach($relative in @('Runtime/HybridLumenGIHardwareBackend.cs','Runtime/HybridLumenGISoftwareTriangleBvh.cs',
    'Runtime/HybridLumenGIHitMaterialBatch.cs','Runtime/HybridLumenGIRayTexturePool.cs','Runtime/HybridLumenGIMaterialSource.cs',
    'Runtime/Resources/HybridLumenGI/HybridLumenGIHardwareTrace.hlsl','Runtime/Resources/HybridLumenGI/HybridLumenGIExactMesh.hlsl')){
    $wanted=[IO.File]::ReadAllText("$repo/$relative").Replace([string][char]13,'')
    $installed=[IO.File]::ReadAllText("$project/Assets/HybridLumenGI/$relative").Replace([string][char]13,'')
    if($wanted -cne $installed){throw "Observed API differs from accepted source: $relative"}
}
$hadSetup=Test-Path -LiteralPath $lastScene -PathType Leaf
New-Item -ItemType Directory -Path $setup | Out-Null
if($hadSetup){Copy-Item -LiteralPath $lastScene -Destination $setup}
Copy-Item -LiteralPath "$PSScriptRoot/contract.md" -Destination $setup
$created=$false
try{
    New-Item -ItemType Directory -Path "$owned/Editor" | Out-Null
    $created=$true
    Copy-Item -LiteralPath "$PSScriptRoot/BinaryCoverage128Editor.cs" -Destination "$owned/Editor"
    Copy-Item -LiteralPath "$PSScriptRoot/BinaryCoverageSoftware.compute","$PSScriptRoot/BinaryCoverageHardware.compute","$PSScriptRoot/BinaryCoverage.hlsl" -Destination $owned
    & 'I:/Unity test/Start-Unity.ps1' -Batch -KeepRunning -ProjectPath $project -LogName $name -ExecuteMethod BinaryCoverage128Editor.Run -ExtraArguments @('-binaryCoverageOutput',$output)
    $code=$LASTEXITCODE
    @{exitCode=$code;project=$project;output=$output} | ConvertTo-Json | Set-Content -LiteralPath "$setup/native-exit.json" -Encoding utf8
    if($code -ne 0){throw "Binary coverage exited $code; original output retained."}
    $result=Get-Content -Raw -LiteralPath "$output/result.json" | ConvertFrom-Json
    if($result.status -ne 'passed' -or !$result.restored){throw 'The finite observation did not pass and restore.'}
    $result | Select-Object status,restored,pagesReady,actualSoftware,actualDxr,meshCount,triangles,fallbacks
}finally{
    Idle
    if($hadSetup){Copy-Item -LiteralPath "$setup/LastSceneManagerSetup.txt" -Destination $lastScene -Force}
    elseif(Test-Path -LiteralPath $lastScene){Move-Item -LiteralPath $lastScene -Destination "$setup/generated-scene-setup.txt"}
    if($created){
        $source=Get-Item -LiteralPath $owned
        $target=[IO.Path]::GetFullPath("$setup/observer")
        if($source.FullName -ine [IO.Path]::GetFullPath("$project/Assets/HLGIBinaryCoverage128") -or
            [IO.Path]::GetDirectoryName($setup) -ine $comparison -or [IO.Path]::GetDirectoryName($target) -ine $setup -or
            $source.Attributes.HasFlag([IO.FileAttributes]::ReparsePoint) -or
            (Get-ChildItem -LiteralPath $owned -Recurse -Force -Attributes ReparsePoint | Select-Object -First 1)){throw 'Unexpected observer/archive path.'}
        Move-Item -LiteralPath $source.FullName -Destination $target
        if(Test-Path -LiteralPath "$owned.meta"){Move-Item -LiteralPath "$owned.meta" -Destination "$target.meta"}
    }
}
