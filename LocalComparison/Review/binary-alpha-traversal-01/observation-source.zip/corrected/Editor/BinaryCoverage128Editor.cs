using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using HybridLumenGI;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;
using Batch=HybridLumenGI.HybridLumenGIHitMaterialBatch;

// One static observation. Source meshes go through the production geometry
// backend and software BVH builder; no handwritten instance/UV/material tables.
public static class BinaryCoverage128Editor
{
    const string Root="Assets/HLGIBinaryCoverage128";
    const long Budget=16L*1024*1024;
    [StructLayout(LayoutKind.Sequential)] public struct U4 { public uint x,y,z,w; }
    [StructLayout(LayoutKind.Sequential)] public struct Ray { public U4 result,identity,triangle;public Vector4 diffuseT,uvBary; }
    [Serializable] public sealed class RayRow {
        public uint found,flags,representation,ownerSlot,stableId,ownerRevision,geometryRevision,instance,submesh,primitive;
        public Vector4 diffuseT,uvBary;
    }
    [Serializable] public sealed class SourceRow {
        public string name,shader;public int stableId,revision,geometryRevision;
        public Vector3[] vertices,normals;public Vector2[] uv;public int[] indices;
        public Color baseColor;public string[] keywords;public float metallic,cull,alphaClip,cutoff,alphaToMask;
        public bool identityTransform;public string filter;public int width,height,mips;public Color32[] pixels;
    }
    [Serializable] public sealed class Receipt {
        public string status="insufficient",error,device,api,unity;
        public int scenePublished,meshCount,instances,triangles,fallbacks,bvhNodes,bvhLeaves,producerUploads,consumerUploads,unknownMaterials;
        public bool inlineSupported,pagesReady,consumerReused,dispatchSubmitted,actualSoftware,actualDxr,restored;
        public string[] computeErrors;
        public SourceRow[] sources;public RayRow[] software,dxr;
        public string scope="Static ordinary Lit binary alpha; Point, linear RGBA32 8x8, no mip; front/back Cull Back; point footprint; surface query; production geometry and material APIs in Editor, not a RendererFeature/Player image or shadow/MSAA/A2C matrix.";
    }
    static readonly Receipt receipt=new Receipt();
    static readonly List<UnityEngine.Object> owned=new List<UnityEngine.Object>();
    static readonly List<Batch> batches=new List<Batch>();
    static readonly List<GraphicsBuffer> buffers=new List<GraphicsBuffer>();
    static readonly List<string> computeErrors=new List<string>();
    static SceneSetup[] prior;static bool priorEmpty,changedScene,gpuIdle=true,finishing;
    static string output;static double deadline;
    static HybridLumenGIScene scene;static HybridLumenGISurfaceCache cards;static HybridLumenGIHardwareBackend backend;
    static GraphicsBuffer nodes,leaves,softwareOutput,hardwareOutput;
    static ComputeShader software,hardware;static Batch producer;
    static HybridLumenGIProxy front,back;
    static void Need(bool value,string message){if(!value)throw new InvalidOperationException(message);}
    static T Own<T>(T obj) where T:UnityEngine.Object {owned.Add(obj);return obj;}
    static GraphicsBuffer Buffer<T>(T[] data) where T:struct {
        var buffer=new GraphicsBuffer(GraphicsBuffer.Target.Structured,data.Length,Marshal.SizeOf<T>());
        buffers.Add(buffer);buffer.SetData(data);return buffer;
    }
    static object Field(object obj,string name)=>obj.GetType().GetField(name,BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public).GetValue(obj);
    static void OnLog(string message,string stack,LogType type){
        if((type==LogType.Error||type==LogType.Exception)&&message.IndexOf("BinaryCoverage",StringComparison.OrdinalIgnoreCase)>=0)computeErrors.Add(message);
    }
    static bool Ready(Batch batch){
        var pages=(Array)Field(Field(batch,"textureLease"),"Pages");
        return pages.Length>0&&pages.Cast<object>().All(p=>p!=null&&(bool)Field(p,"Ready"));
    }
    static ComputeShader Load(string name){
        var shader=AssetDatabase.LoadAssetAtPath<ComputeShader>(Root+"/"+name+".compute");
        Need(shader!=null,"Missing observation shader: "+name);
        var errors=ShaderUtil.GetComputeShaderMessages(shader).Where(m=>m.severity==UnityEditor.Rendering.ShaderCompilerMessageSeverity.Error).ToArray();
        Need(errors.Length==0,string.Join("\n",errors.Select(m=>m.message)));return shader;
    }
    static HybridLumenGIProxy Make(string name,float size,float z,Color color,Texture2D texture){
        var mesh=Own(new Mesh{name=name+"Mesh",vertices=new[]{new Vector3(-size,-size,z),new Vector3(size,-size,z),new Vector3(size,size,z),new Vector3(-size,size,z)},
            normals=Enumerable.Repeat(Vector3.back,4).ToArray(),uv=new[]{Vector2.zero,Vector2.right,Vector2.one,Vector2.up},triangles=new[]{0,2,1,0,3,2}});
        mesh.RecalculateTangents();mesh.RecalculateBounds();
        var material=Own(new Material(Shader.Find("Universal Render Pipeline/Lit")){name=name+"Material"});
        material.SetFloat("_WorkflowMode",1);material.SetFloat("_Surface",0);material.SetFloat("_Cull",2);material.SetFloat("_Metallic",0);
        material.SetColor("_BaseColor",color);material.SetTexture("_BaseMap",texture);material.SetFloat("_AlphaClip",texture==null?0:1);
        material.SetFloat("_Cutoff",.5f);material.SetFloat("_AlphaToMask",texture==null?0:1);
        if(texture!=null){material.EnableKeyword("_ALPHATEST_ON");material.renderQueue=2450;}
        var obj=Own(new GameObject(name));obj.AddComponent<MeshFilter>().sharedMesh=mesh;
        var renderer=obj.AddComponent<MeshRenderer>();renderer.sharedMaterial=material;
        var proxy=obj.AddComponent<HybridLumenGIProxy>();proxy.SetSources(renderer,null);return proxy;
    }
    static SourceRow Describe(HybridLumenGIProxy proxy){
        var renderer=proxy.SourceRenderer;var mesh=proxy.SourceMesh;var mat=renderer.sharedMaterial;var tex=mat.GetTexture("_BaseMap") as Texture2D;
        return new SourceRow{name=renderer.name,stableId=proxy.StableId,revision=proxy.Revision,geometryRevision=proxy.GeometryContentRevision,
            vertices=mesh.vertices,normals=mesh.normals,uv=mesh.uv,indices=mesh.triangles,identityTransform=renderer.localToWorldMatrix.Equals(Matrix4x4.identity),
            shader=mat.shader.name,baseColor=mat.GetColor("_BaseColor"),keywords=mat.shaderKeywords,metallic=mat.GetFloat("_Metallic"),
            cull=mat.GetFloat("_Cull"),alphaClip=mat.GetFloat("_AlphaClip"),cutoff=mat.GetFloat("_Cutoff"),alphaToMask=mat.GetFloat("_AlphaToMask"),
            filter=tex==null?null:tex.filterMode.ToString(),width=tex==null?0:tex.width,height=tex==null?0:tex.height,
            mips=tex==null?0:tex.mipmapCount,pixels=tex==null?null:tex.GetPixels32()};
    }
    static Batch Create(Batch.Source[] sources){Need(Batch.TryCreate(sources,Budget,out var batch,out var reason),reason);batches.Add(batch);return batch;}
    public static void Run(){
        try{
            Application.logMessageReceived+=OnLog;
            var args=Environment.GetCommandLineArgs();int at=Array.IndexOf(args,"-binaryCoverageOutput");Need(at>=0&&at+1<args.Length,"Explicit output required.");
            output=Path.GetFullPath(args[at+1]);Need(!Directory.Exists(output),"Preserve existing output.");Directory.CreateDirectory(output);
            receipt.device=SystemInfo.graphicsDeviceName;receipt.api=SystemInfo.graphicsDeviceType.ToString();receipt.unity=Application.unityVersion;
            receipt.inlineSupported=HybridLumenGIHardwareBackend.IsSupported;
            Need(receipt.inlineSupported&&SystemInfo.supportsAsyncGPUReadback&&SystemInfo.supportsGraphicsFence,"Actual D3D12 inline RT, compute, fences and readback required.");
            Need(!EditorApplication.isPlayingOrWillChangePlaymode,"Expected idle Editor.");
            prior=EditorSceneManager.GetSceneManagerSetup();priorEmpty=prior.Length==0;
            for(int i=0;i<SceneManager.sceneCount;i++){
                var old=SceneManager.GetSceneAt(i);Need(!old.isDirty,"Existing scene is dirty.");
                if(string.IsNullOrEmpty(old.path)){Need(SceneManager.sceneCount==1&&old.rootCount==0,"Cannot replace unnamed nonempty scene.");priorEmpty=true;}
            }
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);changedScene=true;
            software=Load("BinaryCoverageSoftware");hardware=Load("BinaryCoverageHardware");
            var texture=Own(new Texture2D(8,8,TextureFormat.RGBA32,false,true){name="Binary8x8",filterMode=FilterMode.Point,wrapMode=TextureWrapMode.Clamp,anisoLevel=1});
            var pixels=new Color32[64];for(int y=0;y<8;y++)for(int x=0;x<8;x++)pixels[y*8+x]=new Color32(255,255,255,(byte)((x+y)%2==0?255:0));
            texture.SetPixels32(pixels);texture.Apply(false,false);
            front=Make("RedCutout",1,0,Color.red,texture);back=Make("BlueBack",2,1,Color.blue,null);
            scene=new HybridLumenGIScene();cards=new HybridLumenGISurfaceCache();backend=new HybridLumenGIHardwareBackend();
            scene.Prepare(new Vector3(0,0,-1),32,30,30,16,32);receipt.scenePublished=scene.PublishedCount;
            Need(scene.PublishedCount==2&&scene.ValidCount==2,"Expected only two published actual owners.");
            cards.Prepare(scene,new HybridLumenGISurfaceCache.Config{referencePosition=new Vector3(0,0,-1),tileResolution=16,maxResidentCards=12,patchGrid=1});
            HybridLumenGIRtasBudget.BeginFrame(Time.frameCount,HybridLumenGIRtasBudget.Settings.Default);
            Need(backend.Prepare(scene,scene.Revision,1024,cards),"Actual geometry preparation failed: "+backend.BudgetStatus);
            receipt.meshCount=backend.MeshCount;receipt.instances=backend.InstanceCount;receipt.triangles=backend.TriangleCount;receipt.fallbacks=backend.FallbackCount;
            Need(receipt.meshCount==2&&receipt.instances==2&&receipt.triangles==4&&receipt.fallbacks==0,"Geometry was omitted or fell back.");
            Need(HybridLumenGISoftwareTriangleBvh.TryBuild(backend,backend.InstanceCount,4,out var layout,out var why),why);
            receipt.bvhNodes=layout.NodeCount;receipt.bvhLeaves=layout.LeafCount;
            nodes=Buffer(layout.CopyNodes());leaves=Buffer(layout.CopyLeaves());
            softwareOutput=Buffer(new Ray[3]);hardwareOutput=Buffer(new Ray[3]);Need(Marshal.SizeOf<Ray>()==80,"Output stride differs.");
            Need(backend.TryCaptureHitMaterialSources(scene,out var sources,out why),why);
            receipt.sources=new[]{Describe(front),Describe(back)};producer=Create(sources);receipt.producerUploads=producer.TextureUploadCount;
            Need(producer.TextureUploadCount==1&&ReferenceEquals(producer.GetUploadSource(0),texture),"Expected one real checker upload.");
            using(var cmd=new CommandBuffer{name="Binary coverage original material upload"}){
                Need(producer.Record(cmd,out why),why);Need(producer.SealAfterConsumers(cmd,out why),why);
                gpuIdle=false;Graphics.ExecuteCommandBuffer(cmd);
            }
            var marker=AsyncGPUReadback.Request(softwareOutput);marker.WaitForCompletion();Need(marker.done&&!marker.hasError,"Upload queue marker failed.");gpuIdle=true;
            deadline=EditorApplication.timeSinceStartup+30;EditorApplication.update+=Tick;
        }catch(Exception ex){Finish(ex);}
    }
    static void Tick(){
        try{
            Batch.PollRetired();Need(EditorApplication.timeSinceStartup<deadline,"Material page metadata did not become ready within 30 seconds.");
            if(!Ready(producer))return;receipt.pagesReady=true;
            Need(backend.TryCaptureHitMaterialSources(scene,out var sources,out var why),why);
            var batch=Create(sources);receipt.consumerUploads=batch.TextureUploadCount;receipt.consumerReused=batch.ReusesTextureResidency;
            Need(batch.TextureUploadCount==0&&batch.ReusesTextureResidency&&Ready(batch),"Consumer did not reuse the actual ready page.");
            receipt.sources=new[]{Describe(front),Describe(back)};
            using(var cmd=new CommandBuffer{name="Binary coverage exact software and DXR"}){
                // Refresh the shared frame's quota before the still-pending native build.
                HybridLumenGIRtasBudget.BeginFrame(Time.frameCount,HybridLumenGIRtasBudget.Settings.Default);
                Need(backend.Prepare(scene,scene.Revision,1024,cards),"Current geometry not admitted.");
                Need(backend.RecordBuild(cmd)&&backend.CanDispatch,"Actual RTAS build not admitted: "+backend.BudgetStatus);
                Need(batch.Record(cmd,out why),why);receipt.unknownMaterials=batch.UnknownRecords;Need(batch.UnknownRecords==0,"Unknown material rows.");
                Dispatch(cmd,batch,software,softwareOutput,true);Dispatch(cmd,batch,hardware,hardwareOutput,false);
                Need(batch.SealAfterConsumers(cmd,out why),why);gpuIdle=false;Graphics.ExecuteCommandBuffer(cmd);receipt.dispatchSubmitted=true;
            }
            var soft=new Ray[3];var hard=new Ray[3];softwareOutput.GetData(soft);hardwareOutput.GetData(hard);gpuIdle=true;
            receipt.software=soft.Select(Row).ToArray();receipt.dxr=hard.Select(Row).ToArray();
            foreach(var shader in new[]{software,hardware})foreach(var m in ShaderUtil.GetComputeShaderMessages(shader))
                if(m.severity==UnityEditor.Rendering.ShaderCompilerMessageSeverity.Error)computeErrors.Add(m.message);
            receipt.computeErrors=computeErrors.ToArray();Need(computeErrors.Count==0,"Observer compute was invalid: "+string.Join("\n",computeErrors));
            receipt.actualSoftware=soft.All(r=>r.diffuseT.w>0&&r.diffuseT.w<=4);receipt.actualDxr=hard.All(r=>r.diffuseT.w>0&&r.diffuseT.w<=4);
            Need(receipt.actualSoftware&&receipt.actualDxr,"No valid query-written distances; submission is not execution evidence.");
            Check(receipt.software);Check(receipt.dxr);receipt.status="passed";Finish(null);
        }catch(Exception ex){Finish(ex);}
    }
    static void Dispatch(CommandBuffer cmd,Batch batch,ComputeShader shader,GraphicsBuffer target,bool softwarePath){
        int kernel=shader.FindKernel("CSObserve");Need(batch.Bind(cmd,shader,kernel,out var why),why);backend.Bind(cmd,shader,kernel);
        cmd.SetComputeIntParam(shader,"_HLGI_ProxyCount",scene.Capacity);
        cmd.SetComputeBufferParam(shader,kernel,"_HLGI_Proxies",scene.Buffer);
        cmd.SetComputeBufferParam(shader,kernel,"_HLGI_LightingPolicies",scene.LightingPolicyBuffer);
        if(softwarePath){
            cmd.SetComputeIntParam(shader,"_HLGI_SoftwareBvhNodeCount",receipt.bvhNodes);cmd.SetComputeIntParam(shader,"_HLGI_SoftwareBvhLeafCount",receipt.bvhLeaves);
            cmd.SetComputeBufferParam(shader,kernel,"_HLGI_SoftwareTriangleNodes",nodes);cmd.SetComputeBufferParam(shader,kernel,"_HLGI_SoftwareTriangleLeaves",leaves);
        }
        cmd.SetComputeBufferParam(shader,kernel,"_BinaryCoverageResults",target);cmd.DispatchCompute(shader,kernel,1,1,1);
    }
    static RayRow Row(Ray r)=>new RayRow{found=r.result.x,flags=r.result.y,representation=r.result.z,ownerSlot=r.result.w,
        stableId=r.identity.x,ownerRevision=r.identity.y,geometryRevision=r.identity.z,instance=r.identity.w,submesh=r.triangle.x,primitive=r.triangle.y,diffuseT=r.diffuseT,uvBary=r.uvBary};
    static void Check(RayRow[] rays){
        var expectedUvs=new[]{new Vector2(.875f,.40625f),new Vector2(.34375f,.40625f),new Vector2(.1875f,.4375f)};
        var expectedBary=new[]{new Vector2(.40625f,.46875f),new Vector2(.0625f,.34375f),new Vector2(.25f,.1875f)};
        for(int i=0;i<3;i++){
            var r=rays[i];var proxy=i==2?front:back;var rgb=i==2?new Vector3(.96f,0,0):new Vector3(0,0,.96f);
            Need(r.found==1&&r.stableId==(uint)proxy.StableId&&r.ownerRevision==(uint)proxy.Revision&&r.geometryRevision==(uint)proxy.GeometryContentRevision&&
                r.submesh==0&&r.primitive==(i==0?0u:1u)&&r.instance<2&&scene.GetProxy((int)r.ownerSlot)==proxy&&
                Mathf.Abs(r.diffuseT.w-(i==2?1:2))<.000002f,"Wrong source identity or distance at ray "+i);
            Need(r.representation==1&&(r.flags&(512|2048))==0&&(r.flags&1024)!=0&&(r.flags&32)!=0,"Material or UV unknown at ray "+i);
            Need(Vector3.Distance(new Vector3(r.diffuseT.x,r.diffuseT.y,r.diffuseT.z),rgb)<.00002f&&
                Vector2.Distance(new Vector2(r.uvBary.x,r.uvBary.y),expectedUvs[i])<.000002f&&
                Vector2.Distance(new Vector2(r.uvBary.z,r.uvBary.w),expectedBary[i])<.000002f,"Wrong UV, barycentrics or known diffuse at ray "+i);
        }
    }
    static void Finish(Exception error){
        if(finishing)return;finishing=true;EditorApplication.update-=Tick;Application.logMessageReceived-=OnLog;receipt.error=error?.ToString();receipt.computeErrors=computeErrors.ToArray();
        if(error!=null&&receipt.actualSoftware&&receipt.actualDxr)receipt.status="failed";
        try{
            foreach(var b in batches)b.Dispose();
            if(gpuIdle){foreach(var buffer in buffers)buffer.Dispose();backend?.Dispose();cards?.Dispose();scene?.Dispose();foreach(var obj in owned.AsEnumerable().Reverse())if(obj!=null)UnityEngine.Object.DestroyImmediate(obj);}
            if(changedScene){if(priorEmpty)EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);else EditorSceneManager.RestoreSceneManagerSetup(prior);receipt.restored=true;}
        }catch(Exception ex){receipt.status="insufficient";receipt.error=(receipt.error??"")+"\nCleanup: "+ex;}
        if(output!=null)File.WriteAllText(Path.Combine(output,"result.json"),JsonUtility.ToJson(receipt,true));
        if(receipt.error!=null)Debug.LogError(receipt.error);
        EditorApplication.Exit(receipt.status=="passed"&&receipt.restored?0:1);
    }
}
