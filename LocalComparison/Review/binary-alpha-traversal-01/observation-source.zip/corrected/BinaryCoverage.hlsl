#ifndef HLGI_BINARY_COVERAGE_OBSERVATION_INCLUDED
#define HLGI_BINARY_COVERAGE_OBSERVATION_INCLUDED

// Installed production queries and material/texture evaluation. The host binds
// its real Scene, HardwareBackend, software BVH (software only) and material batch.
// This observer neither supplies geometry tables nor reimplements coverage.
#include "Assets/HybridLumenGI/Runtime/Resources/HybridLumenGI/HybridLumenGITransport.hlsl"

// Three entries, 80 bytes each. Integer identities are preserved as uints.
struct BinaryCoverageResult
{
    uint4 result;    // found, HLGIHit.flags, representation, ownerSlot
    uint4 identity;  // stableId, ownerRevision, geometryRevision, hardwareInstance
    uint4 primitiveInfo; // original submesh, primitive local to that submesh, 0, 0
    float4 diffuseT; // verbatim materialDiffuse RGB, ray t
    float4 uvBary;   // verbatim source UV.xy, triangle barycentrics.xy
};
RWStructuredBuffer<BinaryCoverageResult> _BinaryCoverageResults;

// Front quad: z=0, xy in [-1,1], UV=(xy+1)/2; back: z=1, xy in [-2,2].
// The host authors Point/no-mip 8x8 front alpha: even (x+y) is covered.
// Expected endpoints are back t=2, back t=2, front t=1. No expectation is
// written into the result: UV is meaningful only when HLGI_HIT_UV is set;
// diffuse requires HLGI_HIT_UV_MATERIAL and no MATERIAL_UNKNOWN/QUERY_UNRESOLVED.
[numthreads(3,1,1)]
void CSObserve(uint3 dispatchId : SV_DispatchThreadID)
{
    uint i=dispatchId.x;
    if(i>=3u) return;
    float3 origin=i==0u ? float3(1.5,-.375,-1) :
        (i==1u ? float3(-.625,-.375,-1) : float3(-.625,-.125,-1));
    float3 direction=float3(0,0,1);
    HLGIHit hit;
#if defined(HLGI_INLINE_RT)
    bool found=HLGIHardwareTraceQuery(origin,direction,4,false,true,
        0xffffffffu,0xffffffffu,false,0,0,float4(origin,1),hit);
#elif defined(HLGI_SOFTWARE_TRIANGLES)
    bool found=HLGISoftwareTraceQuery(origin,direction,4,false,true,
        0xffffffffu,0xffffffffu,false,0,0,float4(origin,1),hit);
#else
    #error This observer requires one exact production backend.
#endif
    BinaryCoverageResult output;
    output.result=uint4(found?1u:0u,hit.flags,hit.representation,hit.ownerSlot);
    output.identity=uint4(hit.stableId,hit.ownerRevision,hit.geometryRevision,hit.hardwareInstance);
    output.primitiveInfo=uint4(hit.submesh,hit.primitive,0u,0u);
    output.diffuseT=float4(hit.materialDiffuse,hit.t);
    output.uvBary=float4(hit.uv,hit.barycentrics);
    _BinaryCoverageResults[i]=output;
}

#endif
