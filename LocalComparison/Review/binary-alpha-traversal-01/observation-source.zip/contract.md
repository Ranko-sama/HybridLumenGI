# 一次静态二值 alpha 的实际候选遍历

本次只关闭 T2／G4 的一个必要子问题：在已就绪、普通 Lit 二值 Point／无 mip 材质下，精确软件与真实 DXR 是否都能拒绝透明前候选，继续命中后方已知表面。旧屏幕覆盖、WARP 材质函数和旧后端运行记录没有逐射线归属；不继承撤回的 PendingMaterial123 候选或其失败结果。

运行前固定输入：两个真实可读 MeshRenderer，无其他代理，identity 变换；前板 z=0、xy=[-1,1]，后板 z=1、xy=[-2,2]，两者朝向 -Z，Cull Back，四顶点 UV=(xy+size)/(2*size)，索引 0,2,1,0,3,2。前板红色、metallic=0，linear RGBA32 8×8 白 RGB checker alpha，(x+y) 偶数 alpha=1，其余0，Point／Clamp、无 mip、cutoff=.5、alpha-test 开、作者 _AlphaToMask=1；后板不裁剪蓝色、metallic=0、无贴图。无需卡片捕获或烘焙：本合同仅查询生产精确三角及命中材质，不查询表面照明缓存。

固定射线 origins=(1.5,-.375,-1)、(-.625,-.375,-1)、(-.625,-.125,-1)，方向+Z，maxT=4，surface query，解析材质，点足迹0。独立几何预期依次：绕前板命中后板 t=2 UV=(.875,.40625)；穿前板透明 texel(1,2) 命中后板 t=2 UV=(.34375,.40625)；命中前板实心 texel(1,3) t=1 UV=(.1875,.4375)。预期漫反射分别 (.0,.0,.96)、(.0,.0,.96)、(.96,.0,.0)。距离和 UV 容差2e-6，RGB欧氏差2e-5；不靠双后端互相一致代替来源正确。

所有 mesh、原始 UV、索引、像素、材质、owner ID/revisions、返回身份/flags、barycentrics、UV及diffuse/t写 result.json。源三角序号分别0／1／1，源顺序的重心坐标分别(.40625,.46875)／(.0625,.34375)／(.25,.1875)，同为2e-6容差。几何必须由实际 Scene→SurfaceCache 材质准入→HardwareBackend→生产 SoftwareTriangleBvh 构建；两路径直接调用生产精确 Query。前后全部2 owners、2 instances、4 triangles，fallback=0；材质经过实际上传、GPU metadata回读确认 ready 后，consumer借用同页且无再次上传，UnknownRecords=0。实际 RTAS Build和dispatch必须准入；pending／unknown／实际回退不能记通过。

只有一次 Unity Editor 进程与一次固定查询组，无 Play／Player、画面、帧率、阴影、Cull矩阵、MSAA／A2C、mip／过滤／parallax扩展。上传及metadata等待最多30秒；不足或结果失败按事实收束，不自动扩场景或重试，不修改 Runtime。输出目录、原失败保留；仅归档本次自有 helper 并恢复原场景。

更正附记：第一次 BinaryCoverage128 的输出字段 `triangle` 误用了 HLSL 保留字，实际kernel编译无效，native1／零输出和日志原样保留；其中 actualSoftware／actualDxr 布尔值只由提交后盲置，不能采用。Astra 明确允许仅修复字段名的一次同输入更正 BinaryCoverage128Corrected；80B ABI、原射线／判据不变。更正入口在读回后检查迟编译消息、运行期错误及非零 query-written t，分开提交与执行资格；若仍不足，本次收束。
