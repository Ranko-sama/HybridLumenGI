One fixed all-source-off observation, no new product build.
Run with Python/NumPy: python analyze.py LightsOff127 <fresh-output-directory>
INPUT DESCRIPTION DEVIATION: the frozen text called the wall white; executed source sets wall MPB BaseColor=(.5,.25,.125,1), floor white.
Adopt actual brown-wall/white-floor fixture results only. Full frozen input/all-white-wall condition is NOT verified. Original contract remains unchanged.
history.alpha is stored-temporal validity, not raw-fresh-known. Intermediate filtered validity is not directly observed; terminal filteredD and mask are included.
Only baseline/terminal roles consumed by analysis plus the retained Final images are bundled. Full captures remain in the native directories.
