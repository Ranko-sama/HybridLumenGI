$ErrorActionPreference='Stop'
$project='I:/Unity test/Project'
$comparison=[IO.Path]::GetFullPath('I:/Unity test/Comparison')
$owned=[IO.Path]::GetFullPath("$project/Assets/LightsOff127")
$release='I:/Unity test/Comparison/PortableUnified122/HybridLumenGI-Release122-UnityProject'
$released="$release/Assets/UnifiedRelease74/Generated/Renderer.asset"
$quality="$project/ProjectSettings/QualitySettings.asset"
$lastScene="$project/Library/LastSceneManagerSetup.txt"
$name='LightsOff127'
$output=[IO.Path]::GetFullPath("$comparison/$name")
$record=[IO.Path]::GetFullPath($output+'Setup')
function Idle {
    if(Get-Process Unity,HybridLumenGIPlayer -ErrorAction SilentlyContinue){throw 'A render process is active. Preserve staged files.'}
}
Idle
foreach($p in @($owned,"$owned.meta",$output,$record,"I:/Unity test/Logs/$name.log","I:/Unity test/Logs/$name-upm.log")){
    if(Test-Path -LiteralPath $p){throw "Preserve existing input/output: $p"}
}
if(!(Test-Path -LiteralPath $released -PathType Leaf)){throw 'Release122 settings asset is missing.'}
foreach($file in @('HybridLumenGIRendererFeature.cs','HybridLumenGIValidationCapture.cs')){
    $actual=[IO.File]::ReadAllText("$project/Assets/HybridLumenGI/Runtime/$file").Replace([string][char]13,'')
    $expected=[IO.File]::ReadAllText("$release/Assets/HybridLumenGI/Runtime/$file").Replace([string][char]13,'')
    if($actual -cne $expected){throw "Installed camera/capture source differs from Release122: $file"}
}
$hadSetup=Test-Path -LiteralPath $lastScene -PathType Leaf
New-Item -ItemType Directory -Path $record | Out-Null
Copy-Item -LiteralPath $quality -Destination $record
if($hadSetup){Copy-Item -LiteralPath $lastScene -Destination $record}
Copy-Item -LiteralPath "$PSScriptRoot/selection.json" -Destination $record
$created=$false
try{
    New-Item -ItemType Directory -Path $owned | Out-Null
    $created=$true
    New-Item -ItemType Directory -Path "$owned/Editor" | Out-Null
    Copy-Item -LiteralPath "$PSScriptRoot/LightsOff127Scene.cs","$PSScriptRoot/selection.json" -Destination $owned
    Copy-Item -LiteralPath "$PSScriptRoot/LightsOff127Editor.cs" -Destination "$owned/Editor"
    Copy-Item -LiteralPath $released -Destination "$owned/Release122Renderer.asset"
    & 'I:/Unity test/Start-Unity.ps1' -Batch -KeepRunning -ProjectPath $project -LogName $name -ExecuteMethod LightsOff127Editor.Run -ExtraArguments @('-lightsOffOutput',$output)
    $nativeExit=$LASTEXITCODE
    @{exitCode=$nativeExit;output=$output;lane='GreenToOff'} | ConvertTo-Json | Set-Content -LiteralPath "$record/native-exit.json" -Encoding utf8
    if($nativeExit -ne 0){throw "GreenToOff exited $nativeExit. Original output retained."}
    $editor=Get-Content -Raw -LiteralPath "$output/editor-result.json" | ConvertFrom-Json
    $observed=Get-Content -Raw -LiteralPath "$output/scene-result.json" | ConvertFrom-Json
    if($editor.status -ne 'collected' -or !$editor.restored -or $observed.status -ne 'collected' -or $observed.lane -ne 'GreenToOff'){
        throw 'The single lights-off observation did not finish and restore.'
    }
}finally{
    Idle
    Copy-Item -LiteralPath "$record/QualitySettings.asset" -Destination $quality -Force
    if($hadSetup){Copy-Item -LiteralPath "$record/LastSceneManagerSetup.txt" -Destination $lastScene -Force}
    elseif(Test-Path -LiteralPath $lastScene){Move-Item -LiteralPath $lastScene -Destination "$record/generated-scene-setup.txt"}
    if($created){
        $source=Get-Item -LiteralPath $owned
        $destination=[IO.Path]::GetFullPath("$record/used-fixture")
        if($source.FullName -ine [IO.Path]::GetFullPath("$project/Assets/LightsOff127") -or
            [IO.Path]::GetDirectoryName($record) -ine $comparison -or [IO.Path]::GetDirectoryName($destination) -ine $record -or
            $source.Attributes.HasFlag([IO.FileAttributes]::ReparsePoint) -or
            (Get-ChildItem -LiteralPath $owned -Force -Recurse -Attributes ReparsePoint | Select-Object -First 1)){throw 'Unsafe helper archive path.'}
        Move-Item -LiteralPath $source.FullName -Destination $destination
        if(Test-Path -LiteralPath "$owned.meta"){Move-Item -LiteralPath "$owned.meta" -Destination "$destination.meta"}
    }
}
