using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using HybridLumenGI;
using UnityEngine;
using UnityEngine.Rendering;

[DefaultExecutionOrder(1000)]
public sealed class ReflectedColor134Host : MonoBehaviour
{
    public HybridLumenGIValidationSequence sequence;
    public Camera targetCamera;
    public HybridLumenGIRendererFeature feature;
    public RenderPipelineAsset expectedPipeline;
    public string outputDirectory, lane;
    public int requestedFinalLogical = -1;
    const BindingFlags Private = BindingFlags.Instance | BindingFlags.NonPublic;
    const double MinimumSourceInterval = 1.0 / 30.0;
    static readonly FieldInfo Logical = typeof(HybridLumenGIValidationSequence).GetField("logicalFrame", Private);
    static readonly FieldInfo Pending = typeof(HybridLumenGIValidationSequence).GetField("pending", Private);
    static readonly FieldInfo Output = typeof(HybridLumenGIValidationSequence).GetField("output", Private);
    static readonly FieldInfo Settings = typeof(HybridLumenGIRendererFeature).GetField("settings", Private);
    static readonly int BaseColor = Shader.PropertyToID("_BaseColor");
    static readonly Color Blue = new Color(.05f, .15f, .8f, 1);

    [Serializable] public sealed class LegacyRun
    {
        public string status, lastError, expectedBackend, renderPath;
        public int renderedFrames, failures, backendMismatches, firstEngineFrame, firstRenderedGiFrame, capturesWritten;
    }
    [Serializable] sealed class LegacyFrame
    {
        public int logicalFrame, engineFrame, giFrame;
        public bool diagnosticFresh;
        public string reportedBackend;
    }
    [Serializable] public sealed class SourceFrame
    {
        public int logicalFrame, engineFrame, workFrame = -1, giFrame = -1, ticketIndex = -1;
        public double sourceSeconds, eventElapsed = -1, previousSourceGap = -1, renderReturnedSeconds;
        public Color wallColor;
        public Vector3 cameraPosition;
        public Quaternion cameraRotation;
        public bool returned, terminal;
        public HybridLumenGIRendererFeature.CameraDiagnostics diagnostics;
    }
    [Serializable] public sealed class CaptureRecord
    {
        public int logicalFrame, engineFrame, workFrame;
        public string receiptPath, failure;
        public bool complete, succeeded;
        public HybridLumenGIValidationCapture.Receipt receipt;
    }
    [Serializable] public sealed class Series
    {
        public string lane, status = "failed";
        public string sourceClock = "Time.realtimeSinceStartupAsDouble in the matching beginCamera callback, after same-Update pacing; not readback completion";
        public string quantity = "filteredD and its existing validity mask; valid history is not a current raw/fresh-known certificate";
        public double minimumSourceInterval = MinimumSourceInterval, eventSeconds = -1;
        public int eventAfterLogical = 119, eventEngineFrame = -1, finalLogical = -1;
        public List<SourceFrame> frames = new List<SourceFrame>();
        public List<CaptureRecord> tickets = new List<CaptureRecord>();
    }
    [Serializable] public sealed class Result
    {
        public string status = "failed", error = "", lane, captureDirectory, framesFile, runFile, seriesFile;
        public string actualFeatureJson, actualSettingsJson;
        public string legacyMeaning = "Intentional bounded prefix ending no later than239; original720 gate remains failed, not completed";
        public string sourceArchive = "ValidationPackageV209/project-archive/Assets/ValidationPackageV201/Generated; original camera/five lights; temporary Sequence freezes door at ApplyFrame0 and suppresses ordinary HDR";
        public string observation = "Existing Capture only filteredD/validity for119..final; no new reference or fresh-raw observation";
        public string captureCapacityMeaning = "121 pending/512MiB is a bounded observation ownership limit, not a product GPU memory budget";
        public int renderedFrames, receiptCount, ticketCount, finalLogical = -1, requestedFinalLogical = -1;
        public int eventEngineFrame = -1, eventAfterLogical = 119, firstBlueLogicalFrame;
        public double eventSeconds = -1, finalEventElapsed = -1, elapsedSeconds;
        public Color originalColor, before0Color, at119PreColor, finalColor;
        public bool eventSeen, referenceDrained, legacyReadbacksDrained, allCapturesSucceeded, wallRestored;
        public LegacyRun legacy;
    }

    readonly Result result = new Result();
    readonly Series series = new Series();
    readonly List<HybridLumenGIValidationCapture.Ticket> tickets = new List<HybridLumenGIValidationCapture.Ticket>();
    HybridLumenGIValidationCapture.Session capture;
    MeshRenderer wall;
    MaterialPropertyBlock originalBlock, currentBlock, slotBlock;
    object readyPipeline;
    int stableUpdates, returnedCount;
    bool began, stopRequested, stopping, finished, checkpoint;
    double started, lastSourceSeconds = -1;

    static void Need(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
    void Error(Exception e)
    {
        result.error += (result.error.Length == 0 ? "" : "\n") + e;
        stopRequested = true;
    }
    Color EffectiveColor()
    {
        wall.GetPropertyBlock(currentBlock);
        return currentBlock.HasProperty(BaseColor) ? currentBlock.GetColor(BaseColor) : wall.sharedMaterial.GetColor(BaseColor);
    }
    void ApplyBlue()
    {
        wall.GetPropertyBlock(currentBlock);
        currentBlock.SetColor(BaseColor, Blue);
        wall.SetPropertyBlock(currentBlock); // Ordinary public MPB input; no MarkDirty.
    }
    void Start()
    {
        started = Time.realtimeSinceStartupAsDouble;
        Application.runInBackground = true;
        result.lane = series.lane = lane; result.requestedFinalLogical = requestedFinalLogical;
        result.firstBlueLogicalFrame = lane == "BlueFromStart" ? 0 : 120;
        try {
            Need(sequence != null && targetCamera != null && feature != null && expectedPipeline != null, "Archived references missing.");
            Need(Path.IsPathRooted(outputDirectory) && Directory.Exists(outputDirectory), "Editor output directory missing.");
            Need(lane == "RedToBlue" || lane == "BlueFromStart", "Unknown lane.");
            Need(lane != "BlueFromStart" || (requestedFinalLogical >= 120 && requestedFinalLogical <= 239), "BlueFromStart requires event lane finalLogical.");
            Need(!targetCamera.enabled && sequence.enabled && sequence.CaptureStatus == "not-started", "Expected cold explicit camera capture.");
            Need(Logical != null && Pending != null && Output != null && Settings != null, "Existing private sequence API unavailable.");
            Need(GraphicsSettings.currentRenderPipeline == expectedPipeline, "Active pipeline is not the archived pipeline.");
            var settings = (HybridLumenGIRendererFeature.Settings)Settings.GetValue(feature);
            Need(settings != null, "Original Settings object missing.");
            // Pass construction retains this exact object. Never replace it with a deserialized clone.
            settings.raysPerPixel = 2; settings.filterIterations = 4;
            settings.preferHardwareTracing = true; settings.debugView = HybridLumenGIRendererFeature.DebugView.IndirectOnly;
            result.actualFeatureJson = JsonUtility.ToJson(feature, true);
            result.actualSettingsJson = JsonUtility.ToJson(settings, true);
            File.WriteAllText(Path.Combine(outputDirectory, "actual-feature.json"), result.actualFeatureJson);
            File.WriteAllText(Path.Combine(outputDirectory, "actual-settings.json"), result.actualSettingsJson);
            var walls = targetCamera.gameObject.scene.GetRootGameObjects()
                .SelectMany(o => o.GetComponentsInChildren<MeshRenderer>(true)).Where(r => r.name == "Red wall").ToArray();
            Need(walls.Length == 1 && walls[0].sharedMaterials.Length == 1 && walls[0].sharedMaterial != null,
                "Expected the unique one-slot Red wall.");
            wall = walls[0];
            originalBlock = new MaterialPropertyBlock(); currentBlock = new MaterialPropertyBlock(); slotBlock = new MaterialPropertyBlock();
            wall.GetPropertyBlock(slotBlock, 0);
            Need(slotBlock.isEmpty, "Slot override would mask the renderer MPB.");
            wall.GetPropertyBlock(originalBlock); result.originalColor = EffectiveColor();
            if (lane == "BlueFromStart") ApplyBlue();
            RenderPipelineManager.beginCameraRendering += BeforeCamera;
        } catch (Exception e) { Error(e); }
    }
    void BeforeCamera(ScriptableRenderContext context, Camera camera)
    {
        if (!ReferenceEquals(camera, targetCamera) || !began || stopping || finished) return;
        try {
            int logical = (int)Logical.GetValue(sequence);
            Need(logical == series.frames.Count && logical <= 239, "Repeated/skipped source or source beyond the fixed239 limit.");
            Need(logical == 0 || Time.frameCount == series.frames[logical - 1].engineFrame + 1, "Source engine frames are not adjacent.");
            Need(logical < 120 || result.eventSeen, "The119 post-source event was not applied before120.");
            // Stay inside this Update. Returning to a later engine frame would break source history.
            double remaining = MinimumSourceInterval - (Time.realtimeSinceStartupAsDouble - lastSourceSeconds);
            if (lastSourceSeconds >= 0 && remaining > 0) Thread.Sleep(Math.Min(34, (int)Math.Ceiling(remaining * 1000)));
            double source = Time.realtimeSinceStartupAsDouble;
            var row = new SourceFrame { logicalFrame = logical, engineFrame = Time.frameCount, sourceSeconds = source,
                previousSourceGap = lastSourceSeconds < 0 ? -1 : source - lastSourceSeconds,
                eventElapsed = result.eventSeen ? source - result.eventSeconds : -1,
                wallColor = EffectiveColor(), cameraPosition = camera.transform.position, cameraRotation = camera.transform.rotation };
            series.frames.Add(row); lastSourceSeconds = source;
            if (logical == 0) result.before0Color = row.wallColor;
            if (logical >= 119) {
                row.ticketIndex = tickets.Count;
                tickets.Add(capture.Request(logical, Time.frameCount));
            }
            if (logical >= 120 && (lane == "RedToBlue" ? row.eventElapsed >= 2.6 : logical == requestedFinalLogical)) {
                row.terminal = true; result.finalLogical = series.finalLogical = logical;
            }
            if (logical == 239 && !row.terminal) {
                result.finalLogical = series.finalLogical = logical;
                throw new InvalidOperationException("Reached the hard239 source limit without the required terminal source; no light-off frame240 will be rendered.");
            }
        } catch (Exception e) { Error(e); }
    }
    void RecordReturnedSource()
    {
        if (returnedCount == series.frames.Count) return;
        Need(series.frames.Count == returnedCount + 1, "More than one source submitted in one Host update.");
        var row = series.frames[returnedCount];
        Need(sequence.RenderedFrames == row.logicalFrame + 1 && Time.frameCount == row.engineFrame, "Source returned without its matching sequence receipt.");
        row.renderReturnedSeconds = Time.realtimeSinceStartupAsDouble;
        var matches = feature.GetDiagnostics().Where(d => d.camera == targetCamera.name).ToArray();
        Need(matches.Length == 1, "Missing or ambiguous target-camera diagnostics.");
        row.diagnostics = matches[0]; row.giFrame = matches[0].frame; row.workFrame = matches[0].transportRecordedWorkFrame;
        Need(row.diagnostics.hardwareBackend && row.diagnostics.transportRecordedEngineFrame == row.engineFrame && row.workFrame == row.logicalFrame,
            "Source did not record matching DXR transport diagnostics.");
        row.returned = true; returnedCount++;
        if (row.logicalFrame == 119) {
            Need(!result.eventSeen, "The119 event was repeated.");
            result.at119PreColor = EffectiveColor();
            if (lane == "RedToBlue") ApplyBlue();
            // In the blue control this is only a time marker at the same source boundary.
            result.eventSeconds = series.eventSeconds = Time.realtimeSinceStartupAsDouble;
            result.eventEngineFrame = series.eventEngineFrame = Time.frameCount;
            result.eventSeen = true;
        }
        if (row.terminal || row.logicalFrame == 239) stopRequested = true;
    }
    void Update()
    {
        if (finished) return;
        try {
            if (stopping) { Drain(); return; }
            if (!began) {
                if (stopRequested) return;
                if (Time.realtimeSinceStartupAsDouble - started > 300) throw new TimeoutException("Pipeline did not become ready; no GI warmup submitted.");
                if (!RenderPipeline.SupportsRenderRequest(targetCamera, new RenderPipeline.StandardRequest())) return;
                object current = RenderPipelineManager.currentPipeline;
                if (current == null || !ReferenceEquals(current, readyPipeline)) { readyPipeline = current; stableUpdates = 0; return; }
                if (++stableUpdates < 2) return;
                Need(GraphicsSettings.currentRenderPipeline == expectedPipeline, "Archived pipeline changed before Begin.");
                // Only the existing D/validity capture is temporarily enabled by the runner.
                capture = HybridLumenGIValidationCapture.Begin(targetCamera, feature, Path.Combine(outputDirectory, "signals"), 121, 512L * 1024 * 1024);
                began = true; sequence.BeginCapture();
            }
            RecordReturnedSource();
            if (!stopRequested && sequence.CaptureStatus != "running") throw new InvalidOperationException("Sequence stopped before the selected terminal source: " + sequence.CaptureStatus);
            if (!stopRequested && Time.realtimeSinceStartupAsDouble - started > 300) throw new TimeoutException("Bounded source sequence did not complete.");
        } catch (Exception e) { Error(e); }
    }
    void LateUpdate()
    {
        if (finished || stopping || !stopRequested) return;
        // Sequence.Update(-500)/StandardRequest returned; original Finish(false) retains the720 failed-prefix state.
        stopping = true;
        try { if (sequence != null) sequence.enabled = false; } catch (Exception e) { Error(e); }
        finally {
            if (targetCamera != null) targetCamera.enabled = false;
            RenderPipelineManager.beginCameraRendering -= BeforeCamera;
            capture?.Seal();
        }
        Drain();
    }
    bool LegacyDrained()
    {
        if (sequence == null || Pending == null || Output == null) return !began;
        return ((IList)Pending.GetValue(sequence)).Count == 0 && Output.GetValue(sequence) == null && sequence.ReferenceCaptureDrained;
    }
    void Drain()
    {
        if (finished) return;
        result.referenceDrained = capture == null || capture.IsDrained;
        result.legacyReadbacksDrained = LegacyDrained();
        if (!result.referenceDrained || !result.legacyReadbacksDrained) {
            if (!checkpoint && Time.realtimeSinceStartupAsDouble - started > 300) {
                checkpoint = true; result.error += "\nReadbacks have not terminated; owners remain alive and polling continues.";
                File.WriteAllText(Path.Combine(outputDirectory, "retained-checkpoint.json"), JsonUtility.ToJson(result, true));
            }
            return;
        }
        Finish();
    }
    void Finish()
    {
        if (finished) return; finished = true;
        try {
            result.renderedFrames = sequence != null ? sequence.RenderedFrames : 0;
            result.captureDirectory = sequence != null ? sequence.OutputDirectory : null;
            result.seriesFile = Path.Combine(outputDirectory, "series.json");
            if (wall != null) result.finalColor = EffectiveColor();
            result.ticketCount = tickets.Count; result.allCapturesSucceeded = true;
            foreach (var t in tickets) {
                series.tickets.Add(new CaptureRecord { logicalFrame = t.Result.logicalFrame, engineFrame = t.Result.engineFrame,
                    workFrame = t.Result.workFrame, receiptPath = t.ReceiptPath, failure = t.Failure,
                    complete = t.IsComplete, succeeded = t.Succeeded, receipt = t.Result });
                result.allCapturesSucceeded &= t.Succeeded;
            }
            if (!string.IsNullOrEmpty(result.captureDirectory)) {
                result.runFile = Path.Combine(result.captureDirectory, "run.json"); result.framesFile = Path.Combine(result.captureDirectory, "frames.jsonl");
                result.legacy = JsonUtility.FromJson<LegacyRun>(File.ReadAllText(result.runFile));
                var lines = File.ReadAllLines(result.framesFile); result.receiptCount = lines.Length;
                Need(lines.Length == series.frames.Count, "Source clock records and legacy receipts differ.");
                for (int i = 0; i < lines.Length; i++) {
                    var f = JsonUtility.FromJson<LegacyFrame>(lines[i]); var row = series.frames[i];
                    Need(f.logicalFrame == i && f.engineFrame == row.engineFrame && f.giFrame == row.giFrame && row.returned &&
                        f.diagnosticFresh && f.reportedBackend == "reported-hardware", "Unexpected source receipt/backend at " + i);
                    Need(i == 0 || (f.engineFrame == series.frames[i - 1].engineFrame + 1 && f.giFrame == series.frames[i - 1].giFrame + 1),
                        "Source receipt continuity differs.");
                }
            }
            Need(result.finalLogical >= 120 && result.finalLogical <= 239 && result.renderedFrames == result.finalLogical + 1 && result.receiptCount == result.renderedFrames,
                "Bounded prefix did not end on its selected finalLogical.");
            Need(result.eventSeen && result.eventEngineFrame == series.frames[119].engineFrame, "Event is not bound to the returned119 source.");
            result.finalEventElapsed = series.frames[result.finalLogical].eventElapsed;
            Need(lane != "RedToBlue" || result.finalEventElapsed >= 2.6, "Event lane lacks its2.6-second terminal source.");
            Need(lane != "BlueFromStart" || result.finalLogical == requestedFinalLogical, "Control did not end at the event lane finalLogical.");
            Need(result.legacy != null && result.legacy.status == "failed" && result.legacy.failures == 0 && result.legacy.backendMismatches == 0,
                "Expected intentional failed-prefix with no actual source failures/backend mismatches.");
            Need(result.ticketCount == result.finalLogical - 118 && result.allCapturesSucceeded, "Every119..final source needs its own completed D ticket.");
            for (int i = 0; i < tickets.Count; i++) {
                var t = tickets[i]; var row = series.frames[i + 119];
                Need(t.Result.logicalFrame == row.logicalFrame && t.Result.engineFrame == row.engineFrame && t.Result.workFrame == row.workFrame &&
                    t.Result.cameraInstanceId == targetCamera.GetInstanceID() && t.Result.featureInstanceId == feature.GetInstanceID() &&
                    t.Result.readbacksCompleted && t.Result.retainedBytes == 0, "Capture/source association incomplete at " + row.logicalFrame);
            }
            if (result.error.Length == 0) result.status = "collected";
        } catch (Exception e) { Error(e); }
        finally {
            result.elapsedSeconds = Time.realtimeSinceStartupAsDouble - started;
            capture?.Dispose(); // Reached only after real Capture/legacy drain.
            try {
                if (wall != null && originalBlock != null) { wall.SetPropertyBlock(originalBlock.isEmpty ? null : originalBlock); result.wallRestored = true; }
            } catch (Exception e) { result.status = "failed"; Error(e); }
            series.status = result.status;
            try {
                File.WriteAllText(Path.Combine(outputDirectory, "series.json"), JsonUtility.ToJson(series, true));
                File.WriteAllText(Path.Combine(outputDirectory, "host-result.json"), JsonUtility.ToJson(result, true));
            } finally {
#if UNITY_EDITOR
                UnityEditor.EditorApplication.isPlaying = false;
#endif
            }
        }
    }
    void OnDestroy() { RenderPipelineManager.beginCameraRendering -= BeforeCamera; }
}
