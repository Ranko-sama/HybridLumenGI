$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
$project=[IO.Path]::GetFullPath('I:/Unity test/Project')
$runtime="$project/Assets/HybridLumenGI/Runtime"
$comparison=[IO.Path]::GetFullPath('I:/Unity test/Comparison')
$original="$project/Assets/ValidationPackageV201"
$observer="$project/Assets/HLGIReflectedColor134"
$archive="$comparison/ValidationPackageV209/project-archive/Assets/ValidationPackageV201"
$parent="$comparison/ReflectedColor134"
$setup="$parent/Setup"
$quality="$project/ProjectSettings/QualitySettings.asset"
$lastScene="$project/Library/LastSceneManagerSetup.txt"
$map="$comparison/ArchivedColor133Setup/used-original/import-map.json"
$python='C:/Users/Administrator/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
$names=@('HybridLumenGIValidationSequence.cs','HybridLumenGIValidationCapture.cs')
function Idle {
    if(Get-Process Unity,HybridLumenGIPlayer -ErrorAction SilentlyContinue){throw 'Live Unity/Player owns these resources; preserve them and wait.'}
}
function Fresh([string]$path){if(Test-Path -LiteralPath $path){throw "Preserve existing source/output: $path"}}
function Text([string]$path){return [IO.File]::ReadAllText($path).Replace([string][char]13,'')}
Idle
foreach($p in @($parent,$original,"$original.meta",$observer,"$observer.meta")){Fresh $p}
foreach($lane in @('RedToBlue','BlueFromStart')){
    Fresh "I:/Unity test/Logs/ReflectedColor134$lane.log"
    Fresh "I:/Unity test/Logs/ReflectedColor134$lane-upm.log"
}
foreach($p in @($map,"$PSScriptRoot/ReflectedColor134Editor.cs","$PSScriptRoot/ReflectedColor134Host.cs")){
    if(!(Test-Path -LiteralPath $p -PathType Leaf)){throw "Required existing input/observer missing: $p"}
}
foreach($name in @($names+'HybridLumenGIRendererFeature.cs')){
    if((Text "$runtime/$name") -cne (Text "$repo/Runtime/$name")){throw "Installed implementation differs: $name"}
}
$hadScene=Test-Path -LiteralPath $lastScene -PathType Leaf
New-Item -ItemType Directory -Path "$setup/original" | Out-Null
Copy-Item -LiteralPath $quality -Destination "$setup/original"
if($hadScene){Copy-Item -LiteralPath $lastScene -Destination "$setup/original"}
foreach($name in $names){Copy-Item -LiteralPath "$runtime/$name" -Destination "$setup/original"}
Copy-Item -LiteralPath "$PSScriptRoot/contract.md" -Destination $setup
& $python "$PSScriptRoot/prepare.py" $runtime "$setup/prepared"
if($LASTEXITCODE -ne 0){throw 'Existing observer anchors no longer apply; no source was installed.'}
$finalLogical=-1
foreach($lane in @('RedToBlue','BlueFromStart')){
    Idle
    Fresh $original;Fresh "$original.meta";Fresh $observer;Fresh "$observer.meta"
    $output="$parent/$lane"
    Fresh $output
    $createdOriginal=$false;$createdObserver=$false
    try{
        New-Item -ItemType Directory -Path $original | Out-Null;$createdOriginal=$true
        Copy-Item -LiteralPath "$archive/Generated","$archive/Generated.meta","$archive/ValidationPackageV2Host.cs","$archive/ValidationPackageV2Host.cs.meta" -Destination $original -Recurse
        # Reuse the already-established original GUID map from133; no new source scan.
        Copy-Item -LiteralPath $map -Destination "$original/import-map.json"
        New-Item -ItemType Directory -Path "$observer/Editor" -Force | Out-Null;$createdObserver=$true
        Copy-Item -LiteralPath "$PSScriptRoot/ReflectedColor134Editor.cs" -Destination "$observer/Editor"
        Copy-Item -LiteralPath "$PSScriptRoot/ReflectedColor134Host.cs" -Destination $observer
        foreach($name in $names){Copy-Item -LiteralPath "$setup/prepared/$name" -Destination "$runtime/$name" -Force}
        $arguments=@('-reflectedColorOutput',$output,'-reflectedColorLane',$lane)
        if($lane -eq 'BlueFromStart'){$arguments+=@('-finalLogical',[string]$finalLogical)}
        & 'I:/Unity test/Start-Unity.ps1' -Batch -KeepRunning -ProjectPath $project -LogName "ReflectedColor134$lane" `
            -ExecuteMethod ReflectedColor134Editor.Run -ExtraArguments $arguments
        $code=$LASTEXITCODE
        @{lane=$lane;exitCode=$code;sourceArchive=$archive;output=$output} | ConvertTo-Json |
            Set-Content -LiteralPath "$setup/$lane-exit.json" -Encoding utf8
        if($code -ne 0){throw "Observation $lane exited $code; preserve the first failure. Do not start another lane/retry."}
        $r=Get-Content -LiteralPath "$output/result.json" -Raw | ConvertFrom-Json
        if($r.status -ne 'collected' -or !$r.restored){throw "Incomplete $lane observation; preserve results."}
        $h=Get-Content -LiteralPath "$output/host-result.json" -Raw | ConvertFrom-Json
        if($lane -eq 'RedToBlue'){
            $finalLogical=[int]$h.finalLogical
            if($finalLogical -lt 120 -or $finalLogical -gt 239){throw 'Event final frame missing/outside original light interval; no control launch.'}
        }
        [pscustomobject]@{lane=$lane;status=$r.status;restored=$r.restored;finalLogical=$h.finalLogical}
    }finally{
        Idle
        foreach($name in $names){
            $present=Text "$runtime/$name"
            if($present -cne (Text "$setup/prepared/$name") -and $present -cne (Text "$setup/original/$name")){
                throw "Unexpected edit in $name; preserve backups and do not overwrite it."
            }
            Copy-Item -LiteralPath "$setup/original/$name" -Destination "$runtime/$name" -Force
        }
        Copy-Item -LiteralPath "$setup/original/QualitySettings.asset" -Destination $quality -Force
        if($hadScene){Copy-Item -LiteralPath "$setup/original/LastSceneManagerSetup.txt" -Destination $lastScene -Force}
        elseif(Test-Path -LiteralPath $lastScene){Move-Item -LiteralPath $lastScene -Destination "$setup/$lane-generated-scene-setup.txt"}
        foreach($item in @(@{path=$original;created=$createdOriginal;name="$lane-original"},@{path=$observer;created=$createdObserver;name="$lane-observer"})){
            if(!$item.created){continue}
            $source=Get-Item -LiteralPath $item.path
            $destination=[IO.Path]::GetFullPath((Join-Path $setup $item.name))
            if($source.FullName -ine [IO.Path]::GetFullPath($item.path) -or
                [IO.Path]::GetDirectoryName($source.FullName) -ine [IO.Path]::GetFullPath("$project/Assets") -or
                [IO.Path]::GetDirectoryName($destination) -ine [IO.Path]::GetFullPath($setup) -or
                $source.Attributes.HasFlag([IO.FileAttributes]::ReparsePoint) -or
                (Get-ChildItem -LiteralPath $source.FullName -Recurse -Force -Attributes ReparsePoint | Select-Object -First 1) -or
                (Test-Path -LiteralPath $destination) -or (Test-Path -LiteralPath "$destination.meta")){
                throw 'Unexpected observer/archive path; preserve resources.'
            }
            Move-Item -LiteralPath $source.FullName -Destination $destination
            if(Test-Path -LiteralPath "$($item.path).meta"){Move-Item -LiteralPath "$($item.path).meta" -Destination "$destination.meta"}
        }
    }
}
