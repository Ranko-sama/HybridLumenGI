"""Reuse the exact existing109 observer-only changes, no product transport edit."""
import argparse
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('runtime',type=Path);p.add_argument('output',type=Path);a=p.parse_args();a.output.mkdir(exist_ok=False,parents=True)
def once(s,old,new):
    if s.count(old)!=1:raise ValueError('Expected one existing observer anchor: '+old[:90])
    return s.replace(old,new)
def between(s,first,last,replacement):
    if s.count(first)!=1 or s.count(last)!=1:raise ValueError('Ambiguous existing observer section')
    i=s.index(first);j=s.index(last,i);return s[:i]+replacement+s[j:]
seq=(a.runtime/'HybridLumenGIValidationSequence.cs').read_text(encoding='utf-8-sig')
seq=once(seq,'door.ApplyFrame(logicalFrame);','door.ApplyFrame(0);')
seq=once(seq,'if (!IsCaptureFrame(logicalFrame, captureEvery)) return;','if (logicalFrame >= 0) return; // Existing109 D-only observation, no ordinary HDR.')
(a.output/'HybridLumenGIValidationSequence.cs').write_text(seq,encoding='utf-8')
cap=(a.runtime/'HybridLumenGIValidationCapture.cs').read_text(encoding='utf-8-sig')
cap=between(cap,'                var planes = new List<Plane>();','                AddPass(graph, ticket, planes.ToArray(), false);',
'''                var planes = new List<Plane>();
                planes.Add(Reserve(graph, ticket, support.filteredD, "filteredD", "before-hlgi-composite-after-filter", true, true, false));
''')
cap=once(cap,'AddPass(graph, ticket, planes.ToArray(), false);','AddPass(graph, ticket, planes.ToArray(), false, cameraColor);')
cap=once(cap,'AddPass(graph, ticket, new[] { Reserve(graph, ticket, cameraColor, "cameraAfterHLGI", "after-hlgi-composite-before-transparents", true, false, true) }, true);','AddPass(graph, ticket, Array.Empty<Plane>(), true, cameraColor);')
cap=once(cap,'Plane[] planes, bool after)','Plane[] planes, bool after, TextureHandle cameraColor)')
cap=once(cap,'data.ticket = ticket; data.planes = planes; data.after = after;','data.ticket = ticket; data.planes = planes; data.after = after;\n                builder.UseTexture(cameraColor, AccessFlags.Read);')
(a.output/'HybridLumenGIValidationCapture.cs').write_text(cap,encoding='utf-8')
