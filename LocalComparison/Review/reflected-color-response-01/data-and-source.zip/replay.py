import importlib.util,json,sys
from pathlib import Path
base=Path(__file__).resolve().parent
out=Path(sys.argv[1]).resolve() if len(sys.argv)==2 else base/'replayed'
out.mkdir(parents=True,exist_ok=False)
spec=importlib.util.spec_from_file_location('existing134',base/'analyze.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.REFERENCE=base/'source-domain';m.OLD=base/'original119'
r=m.analyze(base/'raw',out)
(out/'result.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
print(r['status'])
