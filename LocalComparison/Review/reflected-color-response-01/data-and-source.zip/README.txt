ReflectedColor134: current Runtime / original red-wall BaseColor -> blue event.

Overall result: insufficient-control-stability. Floor can be adopted as a finite
independent subdomain; White's blue-history control exceeds its predeclared
stability limits. Small pair differences do NOT qualify White recovery.
Do not extend the control, drop early sources, widen ROIs or adjust thresholds.

Offline replay (Python3.10+, numpy, pillow; no Unity/GPU/reference integration):
  python replay.py fresh-output
The output directory must not exist. This replays the same fixed source ROIs,
pre-event known mask and independent control/cadence qualification.

raw/: original two-lane D readbacks, source times/colors and terminal receipts.
source-domain/: pre-existing geometric owner grid/validity, NOT a new MC run.
original119/: old projection metadata used for the original ROI alignment.
inputs/: the directly reused original source assets, not a standalone project.
source/: observer/runner, contract and existing109 D-only source patch generator.
observer-original/ and observer-prepared/: original and temporary two observation
files; transport/temporal/material computation was not edited. The installed
files and Editor scene/Quality were restored after the two terminal runs.

The first parser result is retained in record/analysis-initial.json: strict
float32 equality rejected the ordinary MPB GetColor roundtrip. The final parser
allows1e-7 only for requested-blue input interpretation, and requires actual
blue values identical across every source and both histories. It does not relax
the White control or response thresholds. No GPU retry occurred.
Filtered validity is not fresh-raw certification; the original720 protocol is
an incomplete prefix. No physical truth, old-red photon fraction, ordinary
Player/Present/performance or fullG3 claim.
